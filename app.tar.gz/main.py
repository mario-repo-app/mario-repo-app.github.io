"""
Álbum familiar — PWA (Flet, build estático con Pyodide)
Publicar: flet publish main.py --app-name "Álbum" --app-short-name "Álbum"
Ejecutar en escritorio: flet run main.py
=========================================================

Adaptado a partir de `main Android.py` (v3.5). Es la versión de SOLO LECTURA
para la familia — la edición sigue haciéndose con `main Windows.py` en modo
producción, tal cual, en el PC de siempre.

QUÉ CAMBIA RESPECTO A `main Android.py` (resumen, detalle en el plan de
migración del proyecto):

1. Se elimina toda la detección/rutas específicas de Android (`IS_ANDROID`,
   HOME de la sandbox, migración desde caché antigua).
2. Los datos (Fotos.db + Fotos/ + Miniaturas/ + Manual.pdf) ya no residen en
   una carpeta de la app: se persisten en el almacenamiento privado del
   navegador (IDBFS, el sistema de archivos de Emscripten respaldado por
   IndexedDB) montado y sincronizado DESDE PYTHON con `pyodide_js` — este
   patrón se validó en un prototipo aparte antes de escribir este archivo.
3. La importación de ZIP ya NO usa el `FilePicker` de Flet (se quitó: nunca
   llegó a abrir el diálogo nativo en Safari/iPadOS, un fallo conocido y sin
   arreglo del propio framework — ver el plan de migración, 5-sexdecies).
   En su lugar, `recibir_zip_arrastrado()` recibe los bytes ya leídos desde
   JavaScript (arrastrar-y-soltar, o el botón HTML "Elegir carpeta con las
   partes ZIP" inyectado por `habilitar_arrastrar_zip.py`) y llama a
   `_procesar_zip()`, que extrae y, tras extraer, llama a
   `guardar_en_navegador()` para persistir el cambio en IndexedDB (no-op
   fuera de Pyodide).
4. Se elimina `ft.Share` (sin soporte fiable multiplataforma en navegador
   estático). "Compartir imagen" pasa a ser "Descargar imagen", usando
   `FilePicker.save_file(src_bytes=...)`.
5. Se quita el panel de diagnóstico de almacenamiento a bajo nivel
   (rutas de sandbox de Android) por no ser aplicable en navegador.
6. Cuando el código se ejecuta FUERA de Pyodide (p. ej. `flet run` en tu
   propio PC durante el desarrollo), se usa una carpeta local normal en vez
   de IDBFS, para poder iterar y probar sin necesidad de un navegador real.
7. Las rutas de archivo (fotos, miniaturas) se convierten a una cadena
   `data:<mime>;base64,...` antes de pasarlas a `ft.Image` cuando se
   ejecuta dentro de Pyodide, con `img_src()` — ver el comentario junto a
   esa función para el porqué (bytes en crudo funcionaba en Windows/
   Android pero no en un iPad real).

Todo lo demás (esquema de la base de datos, colación NOCASE_ES, galería,
filtros, agrupación, tarjetas, diálogo de detalle, visor a pantalla
completa) es el mismo código que ya tenías, solo re-cableado a las nuevas
rutas de almacenamiento.
"""
VERSION = '3.7'

import sys
import os
import threading
import unicodedata
import io
import zipfile
import base64
import asyncio

import sqlite3
from pathlib import Path
from typing import Optional

import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)

import flet as ft

try:
    from PIL import Image as PILImage
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

# ─────────────────────────────────────────────────────────────
# DETECCIÓN DE ENTORNO: navegador (Pyodide) vs desarrollo local
# ─────────────────────────────────────────────────────────────
# Pyodide fija sys.platform a "emscripten"; es la forma estándar de saber
# si el código está corriendo dentro del navegador (build estático de
# `flet build web`) o en un `flet run` normal en tu PC.
IS_PYODIDE = (sys.platform == "emscripten")

# Estas rutas se inicializan dentro de main()
BASE_DIR    = None
DB_PATH     = None
PHOTOS_DIR  = None
THUMBS_DIR  = None
MANUAL_PATH = None

image_index_cache = {"signature": None, "files": {}}
thumb_index_cache = {"signature": None, "files": {}}

# ─────────────────────────────────────────────────────────────
# PERSISTENCIA EN EL NAVEGADOR (IDBFS orquestado desde Python)
# ─────────────────────────────────────────────────────────────
# Validado en un prototipo aparte: pyodide_js da acceso, desde Python, al
# mismo objeto FS de Emscripten que usa el propio Pyodide. No hace falta
# ningún JavaScript adicional en la página — todo el montaje y la
# sincronización se hacen aquí.
async def _syncfs(populate: bool):
    if not IS_PYODIDE:
        return
    import pyodide_js
    from pyodide.ffi import create_once_callable
    import asyncio

    fut = asyncio.get_event_loop().create_future()

    def _cb(err=None):
        # En éxito, "err" llega como null de JS; puede aparecer como un
        # proxy en vez de None real, por eso se comprueba con bool().
        if err:
            fut.set_exception(Exception(str(err)))
        else:
            fut.set_result(None)

    pyodide_js.FS.syncfs(populate, create_once_callable(_cb))
    await fut


async def montar_almacenamiento_persistente():
    """Monta /persist como IDBFS y trae lo que hubiera de una visita
    anterior (populate=True). Se llama una vez, al arrancar la app."""
    if not IS_PYODIDE:
        return
    import pyodide_js
    from pyodide.ffi import to_js

    pyodide_js.FS.mkdirTree("/persist")
    pyodide_js.FS.mount(pyodide_js.FS.filesystems.IDBFS, to_js({}), "/persist")
    await _syncfs(populate=True)


async def guardar_en_navegador():
    """Vuelca a IndexedDB los cambios hechos en /persist (tras importar
    un ZIP). En desarrollo local (fuera de Pyodide) no hace falta: ya se
    escribe directamente en disco."""
    await _syncfs(populate=False)


# ─────────────────────────────────────────────────────────────
# BASE DE DATOS  (sin cambios respecto a main Android.py)
# ─────────────────────────────────────────────────────────────
def _normaliza_orden(s: str) -> str:
    """Quita acentos/diacríticos y pasa a minúsculas para comparar."""
    s = unicodedata.normalize("NFKD", s or "")
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return s.casefold()


def _collate_nocase_es(a: str, b: str) -> int:
    """Colación alfabética insensible a mayúsculas/minúsculas Y a acentos."""
    a_norm = _normaliza_orden(a)
    b_norm = _normaliza_orden(b)
    if a_norm < b_norm:
        return -1
    if a_norm > b_norm:
        return 1
    return 0


def open_conn() -> sqlite3.Connection:
    global DB_PATH
    if DB_PATH is None:
        raise RuntimeError("DB_PATH no inicializado — open_conn() llamado antes de main()")

    DB_PATH.parent.mkdir(parents=True, exist_ok=True)

    c = sqlite3.connect(str(DB_PATH))
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys = ON")
    c.create_collation("NOCASE_ES", _collate_nocase_es)
    return c


def init_db():
    with open_conn() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS Epoca (
            epoca TEXT PRIMARY KEY
        );
        CREATE TABLE IF NOT EXISTS Lugares (
            lugar TEXT PRIMARY KEY
        );
        CREATE TABLE IF NOT EXISTS Personas (
            nom TEXT PRIMARY KEY
        );
        CREATE TABLE IF NOT EXISTS Fotos (
            foto      INTEGER PRIMARY KEY,
            epoca     TEXT REFERENCES Epoca(epoca)   ON UPDATE CASCADE ON DELETE SET NULL,
            lugar     TEXT REFERENCES Lugares(lugar) ON UPDATE CASCADE ON DELETE SET NULL,
            Nota      TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS Imagenes (
            indice INTEGER PRIMARY KEY AUTOINCREMENT,
            nom    TEXT    NOT NULL REFERENCES Personas(nom) ON UPDATE CASCADE ON DELETE CASCADE,
            imagen INTEGER NOT NULL REFERENCES Fotos(foto)   ON UPDATE CASCADE ON DELETE CASCADE,
            UNIQUE(nom, imagen)
        );

        CREATE INDEX IF NOT EXISTS idx_imagenes_imagen ON Imagenes(imagen);
        CREATE INDEX IF NOT EXISTS idx_fotos_epoca ON Fotos(epoca);
        CREATE INDEX IF NOT EXISTS idx_fotos_lugar ON Fotos(lugar);
        """)


def Q(query: str, params=()) -> list:
    with open_conn() as db:
        return [dict(r) for r in db.execute(query, params).fetchall()]


def X(query: str, params=()):
    with open_conn() as db:
        db.execute(query, params)


# ─────────────────────────────────────────────────────────────
# IMAGEN UTILS  (sin cambios respecto a main Android.py)
# ─────────────────────────────────────────────────────────────
def find_img(fid: int, photos_dir: str) -> Optional[str]:
    folder = Path(photos_dir)
    if not folder.exists():
        return None
    for p in folder.iterdir():
        if p.is_file() and p.stem == str(fid) and p.suffix.lower() in IMAGE_EXTENSIONS:
            return str(p)
    return None


def invalidate_thumb_index():
    thumb_index_cache["signature"] = None
    thumb_index_cache["files"] = {}


def get_thumb_index() -> dict:
    if THUMBS_DIR is None or not THUMBS_DIR.exists():
        thumb_index_cache["signature"] = None
        thumb_index_cache["files"] = {}
        return thumb_index_cache["files"]

    try:
        signature = (str(THUMBS_DIR.resolve()), THUMBS_DIR.stat().st_mtime_ns)
    except OSError:
        signature = (str(THUMBS_DIR), None)

    if thumb_index_cache["signature"] == signature:
        return thumb_index_cache["files"]

    files = {}
    try:
        for p in THUMBS_DIR.iterdir():
            if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS:
                files.setdefault(p.stem, str(p))
    except OSError:
        files = {}

    thumb_index_cache["signature"] = signature
    thumb_index_cache["files"] = files
    return files


def find_thumb(fid: int) -> Optional[str]:
    return get_thumb_index().get(str(fid))


def find_original(fid: int) -> Optional[str]:
    return find_img(fid, PHOTOS_DIR)


def invalidate_image_index():
    image_index_cache["signature"] = None
    image_index_cache["files"] = {}


def create_thumbnail(fid: int):
    """Se mantiene por si algún día se añade edición también aquí, pero
    en la app de solo-lectura no se llama: las miniaturas ya vienen
    hechas dentro del ZIP que exporta la app de producción."""
    if not PIL_AVAILABLE:
        return
    src = find_original(fid)
    if not src:
        return
    thumb_path = THUMBS_DIR / f"{fid}.webp"
    try:
        with PILImage.open(src) as im:
            im.thumbnail((THUMB_SIZE, THUMB_SIZE))
            im.save(thumb_path, "WEBP", quality=75)
        invalidate_thumb_index()
    except Exception as ex:
        print(f"Error creando miniatura {fid}: {ex}")


def image_filename_hint(fid: int) -> str:
    return f"{fid}.jpg / .jpeg / .png / .webp"


# ─────────────────────────────────────────────────────────────
# img_src(): convertir una ruta de archivo en algo que ft.Image
# pueda pintar de verdad dentro del navegador
# ─────────────────────────────────────────────────────────────
# Dentro de Pyodide, una ruta como "/persist/album/Fotos/3.jpg" es interna
# del sistema de archivos VIRTUAL de Python (el propio Pyodide/Emscripten).
# El renderizador Flutter que dibuja la interfaz en el navegador no tiene
# ninguna forma de "pedir" esa ruta como si fuera una URL real — por eso
# antes las fichas de la Galería y la ficha de detalle se veían vacías
# aunque el archivo existiera de verdad y los datos (época, notas) se
# leyeran bien (eso es solo Python leyendo SQLite, sin pasar por el
# navegador).
#
# Primer intento: pasar los bytes en crudo a `ft.Image(src=...)` (Flet lo
# admite — ver el propio tipo de `Image.src`, `Union[str, bytes]`). Eso
# arregló el problema en Windows y Android, pero en un iPad real las
# fotos seguían sin verse (aunque "Descargar" sí funcionaba, así que los
# bytes se leían bien y sí llegaban al navegador -- el problema estaba
# específicamente en cómo se pintan). La sospecha más probable: en este
# despliegue concreto (Pyodide corriendo en un Web Worker, comunicándose
# con el hilo principal por `postMessage`, no el cliente estándar de Flet
# por WebSocket) el camino de "bytes en crudo" para `src` está mucho menos
# probado que el de una URL/cadena de texto, y WebKit/Safari en iOS tiene
# antecedentes conocidos de comportarse de forma distinta a Chromium con
# transferencias binarias grandes entre un Worker y el hilo principal.
#
# Arreglo: en vez de bytes en crudo, se codifica la imagen como una cadena
# `data:<mime>;base64,<datos>` -- un formato explícitamente documentado
# también por Flet para `src` ("base64 strings, with or without `data:`
# prefixes"), y que viaja como texto normal por cualquier canal (JSON,
# msgpack, postMessage) exactamente igual en todos los navegadores, sin
# depender de ningún transporte binario especial. Es el mismo mecanismo
# que lleva usándose de forma universal para incrustar imágenes en HTML
# desde hace más de una década, así que es la opción más robusta frente a
# rarezas de una plataforma en concreto.
#
# Fuera de Pyodide (escritorio, `flet run`) se sigue devolviendo la ruta
# tal cual, exactamente como hasta ahora — ahí Flet sí tiene acceso directo
# al disco real y no hace falta ningún cambio de comportamiento.
_MIME_POR_EXTENSION = {
    ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
    ".bmp": "image/bmp",
    ".gif": "image/gif",
}


def img_src(path: Optional[str]):
    if not path:
        return None
    if not IS_PYODIDE:
        return path
    try:
        datos = Path(path).read_bytes()
    except OSError as ex:
        print(f"img_src(): no se pudo leer {path}: {ex}")
        return None
    mime = _MIME_POR_EXTENSION.get(Path(path).suffix.lower(), "application/octet-stream")
    b64 = base64.b64encode(datos).decode("ascii")
    return f"data:{mime};base64,{b64}"


# ─────────────────────────────────────────────────────────────
# CONSTANTES DE DISEÑO
# ─────────────────────────────────────────────────────────────
PRIMARY = ft.Colors.INDIGO_800
SURFACE  = ft.Colors.WHITE
GREY_BG  = ft.Colors.GREY_50
TAG_BLUE = ft.Colors.BLUE_700
TAG_GRN  = ft.Colors.GREEN_700
IMAGE_EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif")
THUMB_SIZE = 220


def mk_dropdown(on_change_fn=None, **kwargs) -> ft.Dropdown:
    dd = ft.Dropdown(**kwargs)
    if on_change_fn is not None:
        dd.on_select = on_change_fn
    return dd


# ═════════════════════════════════════════════════════════════
# APP PRINCIPAL
# ═════════════════════════════════════════════════════════════
async def main(Page: ft.Page):
    Page.horizontal_alignment = ft.CrossAxisAlignment.STRETCH
    Page.vertical_alignment = ft.MainAxisAlignment.START
    Page.title = "Álbum"
    # Ruta con "/" inicial, tal como la documenta Flet — necesita
    # "assets/fonts/AlexBrush-Regular.ttf" junto a main.py (ver LEEME.md).
    Page.fonts = {"AlbumRetro": "/fonts/AlexBrush-Regular.ttf"}
    Page.padding = 0
    # IMPORTANTE: forzar SIEMPRE el tema claro. Si no se fija, Flet sigue
    # el modo del sistema operativo/navegador (ft.ThemeMode.SYSTEM es el
    # valor por defecto) — así que en cualquier dispositivo con modo
    # oscuro activado (Windows, Android...) el fondo de la página y el
    # fondo por defecto de los diálogos (AlertDialog) pasan a los grises
    # oscuros/negros del tema oscuro de Material, aunque el resto de la
    # app esté diseñada en claro. Esto explica tanto el fondo negro de
    # Galería/Ajustes como el gris oscuro de la ficha de detalle, y
    # también por qué el aspecto cambiaba entre dispositivos: cada uno
    # seguía su propio modo de sistema en vez de un aspecto fijo por la
    # app. Al fijar LIGHT aquí, el aspecto queda igual en todos los
    # dispositivos, tengan o no el modo oscuro activado.
    Page.theme_mode = ft.ThemeMode.LIGHT
    Page.bgcolor = SURFACE
    Page.theme = ft.Theme(visual_density=ft.VisualDensity.COMPACT)

    picker = ft.FilePicker()
    Page.services.append(picker)

    # Controles de progreso de la importación (se referencian desde
    # _procesar_zip() y desde settings_page más abajo). Ya no hay un botón
    # "Importar ZIP" de Flet -- se quitó junto con el FilePicker que lo
    # respaldaba (ver más abajo) porque el propio selector nativo de Flet
    # nunca llegó a abrir el diálogo en Safari/iPadOS (fallo conocido del
    # framework, ver 5-sexdecies del plan de migración), mientras que el
    # botón HTML "Elegir carpeta con las partes ZIP" (inyectado por
    # habilitar_arrastrar_zip.py, visible solo en esta pestaña) sí importa
    # de forma fiable en los tres tipos de dispositivo de la familia,
    # incluido un pendrive completo de golpe en iPad -- así que pasa a ser
    # la única vía "de botón", junto con arrastrar-y-soltar.
    import_hint_text = ft.Text(
        "Para importar el álbum (o añadir una parte más), toca "
        "«📁 Elegir carpeta con las partes ZIP» arriba de esta pantalla "
        "y elige la carpeta con el/los .zip -- o arrastra los .zip "
        "directamente sobre esta página.",
        size=12, color=ft.Colors.BLUE_GREY_500)
    import_progress_bar = ft.ProgressBar(width=300, value=0, visible=False)
    import_progress_text = ft.Text("", size=12, color=ft.Colors.BLUE_GREY_600)

    _status = ft.Text("Iniciando...", size=16, color=ft.Colors.BLUE_700)
    Page.add(_status)
    Page.update()

    def set_status(msg, color=ft.Colors.BLUE_700):
        _status.value = msg
        _status.color = color
        Page.update()

    def show_fatal(ex):
        import traceback
        Page.add(ft.Column([
            ft.Text("ERROR DE INICIO", size=20, color=ft.Colors.RED_700, weight=ft.FontWeight.BOLD),
            ft.Text(str(ex), size=13, selectable=True, color=ft.Colors.RED_900),
            ft.Text(traceback.format_exc(), size=11, selectable=True, color=ft.Colors.GREY_700),
        ], scroll=ft.ScrollMode.AUTO, expand=True))
        Page.update()

    try:
        global BASE_DIR, DB_PATH, PHOTOS_DIR, THUMBS_DIR, MANUAL_PATH
        set_status("Configurando almacenamiento...")

        if IS_PYODIDE:
            set_status("Conectando con el almacenamiento del navegador...")
            await montar_almacenamiento_persistente()
            BASE_DIR = Path("/persist/album")
        else:
            # Desarrollo local (flet run, sin navegador): una carpeta normal.
            BASE_DIR = Path(os.getcwd()) / "FotosFamiliares"

        DB_PATH     = BASE_DIR / "Fotos.db"
        PHOTOS_DIR  = BASE_DIR / "Fotos"
        THUMBS_DIR  = BASE_DIR / "Miniaturas"
        MANUAL_PATH = BASE_DIR / "Manual.pdf"
        BASE_DIR.mkdir(parents=True, exist_ok=True)
        PHOTOS_DIR.mkdir(parents=True, exist_ok=True)
        THUMBS_DIR.mkdir(parents=True, exist_ok=True)

    except Exception as _e:
        show_fatal(_e)
        return

    set_status("Iniciando base de datos...")
    try:
        init_db()
    except Exception as _e:
        show_fatal(_e)
        return

    set_status("Construyendo interfaz...")

    photos_dir = [str(PHOTOS_DIR)]

    def get_image_index() -> dict:
        folder = Path(photos_dir[0])
        if not folder.exists():
            image_index_cache["signature"] = None
            image_index_cache["files"] = {}
            return image_index_cache["files"]
        try:
            signature = (str(folder.resolve()), folder.stat().st_mtime_ns)
        except OSError:
            signature = (str(folder), None)
        if image_index_cache["signature"] == signature:
            return image_index_cache["files"]
        files = {}
        try:
            for p in folder.iterdir():
                if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS:
                    files.setdefault(p.stem, str(p))
        except OSError:
            files = {}
        image_index_cache["signature"] = signature
        image_index_cache["files"] = files
        return files

    def find_gallery_img(fid: int) -> Optional[str]:
        thumb = find_thumb(fid)
        if thumb:
            return thumb
        return get_image_index().get(str(fid))

    def snack(msg: str, color=ft.Colors.GREEN_700):
        # NUEVO: el botón HTML "Elegir carpeta con las partes ZIP"
        # (inyectado por habilitar_arrastrar_zip.py) vive anclado fijo al
        # borde INFERIOR de la pantalla, POR ENCIMA del <canvas> donde
        # Flet dibuja toda la interfaz -- incluido el propio SnackBar, que
        # con su comportamiento por defecto (behavior=FIXED) también se
        # pega al borde inferior de la página. Al coincidir ambos en la
        # misma franja, el aviso ("ZIP importado correctamente", "Las N
        # partes se importaron correctamente"...) quedaba tapado detrás
        # del botón de carpeta justo después de importar -- que es
        # exactamente cuando se sigue viendo la pestaña Ajustes, la única
        # donde ese botón está visible (ver _notificar_pagina_activa()).
        # Arreglo: SnackBar en modo FLOATING con margen inferior generoso
        # (120 px cubre con holgura la altura del botón + su padding +
        # el hueco de la barra de gestos/home en un iPhone con isla,
        # el caso más alto) para que el aviso "flote" por encima del
        # botón en vez de solaparse con él -- sin tocar la posición del
        # propio botón, que vive fuera del árbol de controles de Flet y
        # no se puede mover desde aquí.
        Page.show_dialog(ft.SnackBar(
            content=ft.Text(msg, color=ft.Colors.WHITE),
            bgcolor=color, duration=2500,
            behavior=ft.SnackBarBehavior.FLOATING,
            margin=ft.Margin.only(left=20, right=20, bottom=120)))

    def open_dlg(dlg):
        Page.show_dialog(dlg)

    def close_dlg(dlg):
        Page.pop_dialog()

    # ── Núcleo compartido de importación ──────────────────────────
    # Antes lo compartían el selector "Importar ZIP" de Flet y las vías
    # HTML (arrastrar-y-soltar, elegir carpeta) -- ahora que se quitó el
    # selector de Flet (nunca llegó a abrir el diálogo nativo en
    # Safari/iPadOS, fallo conocido del framework, ver 5-sexdecies del
    # plan de migración), lo llaman únicamente `recibir_zip_arrastrado()`
    # más abajo, tanto para lo soltado sobre la página como para lo
    # elegido con el botón HTML "Elegir carpeta con las partes ZIP".
    #
    # Distingue dos casos, para poder repartir la colección en varias
    # partes con `exportar_zip_familia.py --max-zip-mb` (ver 5-undecies:
    # un ZIP único de varios cientos de MB cuelga y cierra la pestaña del
    # navegador al cargarlo entero en memoria):
    #   - Importación COMPLETA: el ZIP trae Fotos.db -> limpia todo lo
    #     anterior y lo sustituye, como una importación desde cero.
    #   - PARTE ADICIONAL: el ZIP no trae Fotos.db -> añade sus fotos y
    #     miniaturas a las que ya hubiera, sin borrar nada. Así se pueden
    #     importar todas las partes una detrás de otra, en cualquier
    #     orden, siempre que en algún momento se incluya la que trae la
    #     base de datos.
    async def _procesar_zip(zip_origen, prefijo="", avisar_exito=True):
        import asyncio, time

        import_progress_bar.visible = True
        import_progress_bar.value = 0
        import_progress_text.value = f"{prefijo}Abriendo el ZIP..."
        Page.update()
        await asyncio.sleep(0)

        try:
            with zipfile.ZipFile(zip_origen) as z:
                nombres = z.namelist()
                es_importacion_completa = "Fotos.db" in nombres

                if es_importacion_completa:
                    # Limpiar destino antes de copiar (si no, las fotos
                    # eliminadas del ZIP se quedarían acumuladas).
                    if PHOTOS_DIR.exists():
                        for f in PHOTOS_DIR.iterdir():
                            if f.is_file():
                                f.unlink()
                    if THUMBS_DIR.exists():
                        for f in THUMBS_DIR.iterdir():
                            if f.is_file():
                                f.unlink()

                # IMPORTANTE: en el navegador todo corre en un único hilo
                # (Pyodide/WASM). Un bucle que descomprime y escribe miles
                # de archivos seguidos, sin ceder el control nunca, congela
                # la pestaña entera — parece que la app se ha quedado
                # colgada aunque siga trabajando. Por eso aquí se cede el
                # control (`await asyncio.sleep(0)`) y se actualiza una
                # barra de progreso periódicamente, para que la interfaz
                # siga respondiendo y quede claro que sigue en marcha.
                entradas = [i for i in z.infolist() if not i.is_dir()]
                total = len(entradas)
                ultimo_update = time.monotonic()

                for idx, info in enumerate(entradas, start=1):
                    nombre = info.filename
                    datos = z.read(info)

                    if nombre == "Fotos.db":
                        DB_PATH.write_bytes(datos)
                    elif nombre == "Manual.pdf":
                        MANUAL_PATH.write_bytes(datos)
                    elif nombre.startswith("Fotos/"):
                        (PHOTOS_DIR / Path(nombre).name).write_bytes(datos)
                    elif nombre.startswith("Miniaturas/"):
                        (THUMBS_DIR / Path(nombre).name).write_bytes(datos)

                    # Ceder el control en cada archivo (barato) pero solo
                    # repintar la interfaz cada ~150 ms (Page.update() sí
                    # tiene coste, no conviene hacerlo miles de veces).
                    ahora = time.monotonic()
                    if ahora - ultimo_update > 0.15 or idx == total:
                        import_progress_bar.value = idx / total if total else 1
                        import_progress_text.value = f"{prefijo}Importando fotos... {idx}/{total}"
                        Page.update()
                        ultimo_update = ahora
                    await asyncio.sleep(0)

            invalidate_image_index()
            invalidate_thumb_index()

            import_progress_text.value = f"{prefijo}Guardando en el navegador (esto puede tardar unos segundos)..."
            Page.update()
            await asyncio.sleep(0)

            # Persistir en IndexedDB para que sobreviva a cerrar el navegador.
            await guardar_en_navegador()

            refresh_dropdowns()
            refresh_gallery()
            refresh_stats()

            # `avisar_exito=False` cuando hay varias partes (llamado en
            # bucle desde recibir_zip_arrastrado(), más abajo): en ese caso
            # es recibir_zip_arrastrado() quien muestra un único snack de
            # resumen al final, en vez de uno por cada parte.
            if avisar_exito:
                if es_importacion_completa:
                    snack("ZIP importado correctamente")
                else:
                    snack(f"Parte adicional importada correctamente ({total} archivos añadidos)")

            return True

        except Exception as ex:
            snack(f"Error al importar {prefijo}el ZIP: {ex}" if prefijo else f"Error al importar: {ex}",
                  ft.Colors.RED_500)
            return False

        finally:
            import_progress_bar.visible = False
            import_progress_text.value = ""
            Page.update()

    # ── Arrastrar y soltar / elegir carpeta con el/los ZIP(s) ────────
    # El selector de archivos nativo de Flet no consigue abrir el diálogo
    # de "elegir archivo" en Safari/iPadOS (fallo conocido de Flet, no de
    # esta app — ver plan de migración, 5-sexdecies). El script aparte
    # `habilitar_arrastrar_zip.py` parchea el build publicado
    # (python.js/python-worker.js/index.html) para que, al soltar uno o
    # varios ZIPs sobre la página —desde iPadOS 11 se pueden seleccionar
    # y arrastrar juntos varios archivos de la app Archivos en un mismo
    # gesto— JavaScript los procese TODOS DENTRO DEL PROPIO WORKER, uno
    # detrás de otro (nunca a la vez): por cada archivo, lee sus bytes
    # (`await file.arrayBuffer()`), llama a esta función y ESPERA a que
    # termine (incluida la escritura a IndexedDB) antes de leer el
    # siguiente — así nunca hay más de un ZIP entero en memoria, ni en
    # JavaScript ni en Python (el bucle en sí está en python-worker.js,
    # dentro de habilitar_arrastrar_zip.py).
    #
    # Esta función tiene que existir con este nombre exacto Y quedar
    # registrada en el espacio de nombres global que ve Pyodide desde
    # JavaScript (`pyodide.globals`) — NO basta con definirla aquí dentro,
    # porque Flet ejecuta main.py con `runpy.run_module(...)`, que le da
    # su propio espacio de nombres, distinto del que expone
    # `pyodide.globals` a JavaScript. Por eso se registra explícitamente
    # más abajo, vía el módulo `js` que expone Pyodide — exactamente el
    # mismo patrón que describe el plan de migración en 5-sexdecies.
    #
    # `indice`/`total`: JavaScript ya ordenó los archivos soltados (por
    # nombre, poniendo primero el que sigue la convención "..._parte1_de_
    # N..." de exportar_zip_familia.py, que es el que trae Fotos.db) y
    # avisa aquí de qué posición ocupa cada uno, para poder mostrar
    # "[Parte X/N]" y un único resumen al final en vez de un aviso por
    # archivo. Devuelve True/False: JavaScript corta el bucle si devuelve
    # False (error), en vez de seguir intentando los archivos siguientes.
    _lote_arrastrado = {"total": 0, "ok": 0}

    async def recibir_zip_arrastrado(datos_js, nombre_js="", indice=1, total=1):
        if not IS_PYODIDE:
            return False
        try:
            # Los bytes llegan desde JavaScript como un Uint8Array; según
            # cómo los convierta Pyodide al llamar a esta función pueden
            # aparecer ya como bytes/memoryview, o como un JsProxy que
            # necesita `.to_py()` primero — se contemplan ambos casos.
            if isinstance(datos_js, (bytes, bytearray, memoryview)):
                datos = bytes(datos_js)
            else:
                to_py = getattr(datos_js, "to_py", None)
                convertido = to_py() if callable(to_py) else datos_js
                datos = bytes(convertido)
        except Exception as ex:
            print(f"recibir_zip_arrastrado(): no se pudieron leer los bytes recibidos "
                  f"({nombre_js!r}): {ex}")
            snack(f"No se pudo leer el archivo arrastrado: {ex}", ft.Colors.RED_500)
            return False

        if indice <= 1:
            _lote_arrastrado["total"] = total
            _lote_arrastrado["ok"] = 0

        prefijo = f"[Parte {indice}/{total}] " if total > 1 else ""
        ok = await _procesar_zip(io.BytesIO(datos), prefijo=prefijo, avisar_exito=(total == 1))
        if ok:
            _lote_arrastrado["ok"] += 1

        if total > 1 and indice >= total:
            partes_ok = _lote_arrastrado["ok"]
            if partes_ok == total:
                snack(f"Las {total} partes se importaron correctamente")
            elif partes_ok > 0:
                snack(f"Se importaron {partes_ok} de {total} partes — revisa el error de arriba",
                      ft.Colors.ORANGE_700)

        return bool(ok)

    if IS_PYODIDE:
        try:
            import js as _js
            _js.pyodide.globals["recibir_zip_arrastrado"] = recibir_zip_arrastrado
        except Exception as ex:
            print(f"No se pudo registrar recibir_zip_arrastrado() para arrastrar-y-soltar: {ex}")

    def _notificar_pagina_activa(nombre):
        """Avisa a JavaScript (hilo principal) qué pestaña está activa ahora
        ("galeria" o "ajustes"). Lo usa el botón HTML "Elegir carpeta con las
        partes ZIP" (inyectado por habilitar_arrastrar_zip.py, fuera del árbol
        de controles de Flet) para mostrarse solo en Ajustes: Flet dibuja toda
        la interfaz en un único <canvas> con CanvasKit, sin un nodo del DOM
        por control, así que ese botón no puede vivir "dentro" de settings_page
        ni ocultarse/mostrarse como un control más de Flet -- se posiciona con
        CSS por fuera y necesita que Python le diga cuándo tocan mostrarlo.
        Esto va del Worker de Python al hilo principal por postMessage (la
        dirección contraria a recibir_zip_arrastrado, que va de JS a Python);
        python.js, parcheado por habilitar_arrastrar_zip.py, reenvía el
        mensaje como un evento 'album-page-change' que el HTML inyectado
        escucha. Es solo notificación de estado -- no abre ningún diálogo ni
        depende de ningún gesto del usuario, así que no le afecta la
        restricción de "gesto directo" que sí condiciona, por ejemplo, a
        _save_file_con_reintento() más abajo (el botón HTML de carpeta
        abre su selector con un listener nativo de JavaScript, sin pasar
        por Python en absoluto)."""
        if not IS_PYODIDE:
            return
        try:
            import js as _js2
            from pyodide.ffi import to_js
            _js2.postMessage(to_js({"__albumPage": nombre}, dict_converter=_js2.Object.fromEntries))
        except Exception as ex:
            print(f"No se pudo notificar el cambio de pestaña a JavaScript: {ex}")

    # ── Descargar (sustituye a Share; misma protección ante el
    #    TimeoutException de arranque de FilePicker que ya tenía la
    #    importación de ZIP antes de pasar a las vías HTML) ──
    async def _save_file_con_reintento(file_name: str, src_bytes: bytes):
        import asyncio
        try:
            await picker.save_file(file_name=file_name, src_bytes=src_bytes)
            return True
        except Exception as ex:
            print(f"save_file() falló en el primer intento ({ex}); reintentando...")
            await asyncio.sleep(0.5)
            try:
                await picker.save_file(file_name=file_name, src_bytes=src_bytes)
                return True
            except Exception as ex2:
                snack(
                    "No se pudo abrir el diálogo de guardar. Vuelve a "
                    "pulsar el botón — a veces falla la primera vez que "
                    "se usa tras abrir la app.",
                    ft.Colors.ORANGE_700,
                )
                print(f"save_file() falló también en el reintento: {ex2}")
                return False

    async def descargar_manual(e):
        if not MANUAL_PATH or not MANUAL_PATH.exists():
            snack("Manual no encontrado. Importa un ZIP que lo incluya.", ft.Colors.RED_500)
            return
        try:
            await _save_file_con_reintento("Manual.pdf", MANUAL_PATH.read_bytes())
        except Exception as ex:
            snack(f"Error al descargar el manual:\n{ex}", ft.Colors.RED_500)

    # ── Tarjeta de foto ───────────────────────────────────────────
    def make_card(foto: dict, on_tap) -> ft.Container:
        fid = foto["foto"]
        src = find_gallery_img(fid)
        card_width = _CARD_W
        img_size = card_width

        if src:
            img_w = ft.Container(
                width=img_size, height=img_size,
                content=ft.Stack([
                    ft.Image(src=img_src(src), fit=ft.BoxFit.CONTAIN, width=img_size, height=img_size),
                    ft.Container(
                        alignment=ft.Alignment.BOTTOM_CENTER,
                        content=ft.Container(
                            width=img_size,
                            bgcolor=ft.Colors.with_opacity(0.72, ft.Colors.BLACK),
                            padding=ft.Padding.only(top=4, bottom=4),
                            content=ft.Text(f"#{fid}", size=11, weight=ft.FontWeight.BOLD,
                                             color=ft.Colors.WHITE, text_align=ft.TextAlign.CENTER),
                        ),
                    ),
                ]),
            )
        else:
            img_w = ft.Container(
                width=186, height=186, bgcolor=ft.Colors.BLUE_GREY_100,
                content=ft.Column(
                    [ft.Icon(ft.Icons.PHOTO, size=36, color=ft.Colors.BLUE_GREY_400),
                     ft.Text("Imagen no encontrada", size=11, color=ft.Colors.BLUE_GREY_500),
                     ft.Text(image_filename_hint(fid), size=9, color=ft.Colors.BLUE_GREY_400)],
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER))

        badges = []
        if foto.get("epoca"):
            badges.append(ft.Container(
                content=ft.Text(foto["epoca"][:14], size=9, color=ft.Colors.WHITE),
                bgcolor=TAG_BLUE, padding=ft.Padding.only(left=5, right=5, top=2, bottom=2), border_radius=4))
        if foto.get("lugar"):
            badges.append(ft.Container(
                content=ft.Text(foto["lugar"][:20], size=9, color=ft.Colors.WHITE),
                bgcolor=TAG_GRN, padding=ft.Padding.only(left=6, right=6, top=1, bottom=1), border_radius=4))

        nota_text = (foto.get("Nota") or "").strip()

        return ft.Container(
            width=card_width, border_radius=10, bgcolor=SURFACE,
            border=ft.Border.all(1.5, ft.Colors.BLUE),
            on_click=lambda e: on_tap(foto), ink=True,
            content=ft.Column([
                img_w,
                ft.Container(
                    padding=ft.Padding.only(left=8, right=8, top=5, bottom=6),
                    content=ft.Column([
                        ft.Column(controls=badges, spacing=3, tight=True) if badges else ft.Container(height=0),
                        ft.Text(nota_text[:40] if nota_text else " ", size=9,
                                color=ft.Colors.GREY_700 if nota_text else ft.Colors.TRANSPARENT,
                                max_lines=1, no_wrap=True, overflow=ft.TextOverflow.ELLIPSIS),
                    ], spacing=4, tight=True),
                ),
            ], spacing=0, tight=True),
        )

    # ── Visor fullscreen con zoom y pan ───────────────────────────
    # `src` que llega aquí ya viene resuelto por el llamador (cadena
    # data:...;base64,... dentro de Pyodide, ruta tal cual en escritorio)
    # vía img_src().
    async def show_fullscreen(src, fid: int, on_close_extra=None):
        old_appbar = Page.appbar
        Page.appbar = None
        fullscreen_layer = ft.Container(expand=True, bgcolor=ft.Colors.BLACK)

        def close_fs(e):
            Page.overlay.remove(fullscreen_layer)
            Page.appbar = old_appbar
            Page.update()
            if on_close_extra is not None:
                on_close_extra()

        fullscreen_layer.content = ft.SafeArea(
            expand=True,
            content=ft.Stack(expand=True, controls=[
                ft.Container(
                    expand=True, bgcolor=ft.Colors.BLACK, alignment=ft.Alignment.CENTER,
                    content=ft.InteractiveViewer(
                        min_scale=1, max_scale=8, boundary_margin=200,
                        pan_enabled=True, scale_enabled=True,
                        content=ft.Image(src=src, fit=ft.BoxFit.CONTAIN),
                    ),
                ),
                ft.Container(left=12, bottom=12,
                             content=ft.Text(f"Foto #{fid}", color=ft.Colors.WHITE70, size=14)),
                ft.Container(top=8, right=8,
                             content=(close_btn := ft.IconButton(
                                 icon=ft.Icons.CLOSE, icon_color=ft.Colors.WHITE, on_click=close_fs))),
            ]),
        )
        Page.overlay.append(fullscreen_layer)
        Page.update()
        await close_btn.focus()

    # ── Diálogo detalle ("Compartir" -> "Descargar") ──────────────
    def show_detail(foto: dict):
        fid = foto["foto"]
        src = find_original(fid)
        personas = Q("SELECT nom FROM Imagenes WHERE imagen=? ORDER BY nom COLLATE NOCASE_ES", (fid,))

        is_vertical = False
        if src and PIL_AVAILABLE:
            try:
                with PILImage.open(src) as im:
                    w, h = im.size
                    is_vertical = h > w
            except Exception:
                pass

        def info_row(icon, label, val):
            if not val:
                return ft.Container(height=0)
            return ft.Row([
                ft.Icon(icon, size=15, color=ft.Colors.BLUE_GREY_400),
                ft.Text(f"{label}:", size=13, weight=ft.FontWeight.W_600,
                        color=ft.Colors.BLUE_GREY_600, width=82),
                ft.Text(str(val), size=13, expand=True, selectable=True, color=ft.Colors.GREY_800),
            ], spacing=6, vertical_alignment=ft.CrossAxisAlignment.START)

        chips = [
            ft.Container(
                content=ft.Text(p["nom"], size=12, color=ft.Colors.BLUE_800),
                bgcolor=ft.Colors.BLUE_50, padding=ft.Padding.only(left=8, right=8, top=4, bottom=4),
                border_radius=16, border=ft.Border.all(1, ft.Colors.BLUE_200))
            for p in personas
        ]

        dlg_ref = [None]

        def on_close(e):
            close_dlg(dlg_ref[0])

        async def descargar_imagen(e):
            if not src:
                snack("Imagen no encontrada", ft.Colors.RED_500)
                return
            try:
                await _save_file_con_reintento(Path(src).name, Path(src).read_bytes())
            except Exception as ex:
                snack(f"Error al descargar:\n{ex}", ft.Colors.RED_500)

        # La ficha en sí (fondo, imagen) se pinta con img_src(src): cadena
        # data:...;base64,... dentro de Pyodide, ruta tal cual en
        # escritorio (ver img_src()).
        _detail_img_src = img_src(src)

        # Ancho real disponible en pantalla, con un margen de seguridad de
        # 64 px frente al padding interno que añade por defecto el
        # AlertDialog de Flet (ver plan de migración, 5-quaterdecies: con
        # solo 40 px de margen la imagen todavía asomaba unos pocos
        # píxeles por el borde en un Android real). El diseño "foto al
        # lado de los datos" (vertical_content) solo se usa cuando sobra
        # ancho de verdad (>=640 px); si no, se apila -- imagen arriba,
        # datos debajo -- que es lo que cabe en cualquier móvil sin
        # desbordar, tal como ya se hacía con las fotos horizontales.
        _page_width = Page.width or 400
        _SAFETY_MARGIN = 64
        _available_width = max(_page_width - _SAFETY_MARGIN, 260)
        _usar_lado_a_lado = is_vertical and _available_width >= 640
        _dialog_width = min(_available_width, 700 if _usar_lado_a_lado else 560)

        # Ancho de la imagen en el diseño apilado: nunca más ancha que el
        # propio diálogo (con el mismo margen de seguridad ya aplicado).
        _horizontal_img_w = max(_dialog_width - 40, 200)
        # Ancho de la imagen en el diseño lado a lado: como mucho 320 px
        # (el tamaño original) o el 45% del diálogo si hay menos sitio.
        _vertical_img_w = min(320, int(_dialog_width * 0.45))

        horizontal_content = ft.Column([
            ft.Container(alignment=ft.Alignment.CENTER, height=320, border_radius=8,
                         clip_behavior=ft.ClipBehavior.HARD_EDGE,
                         content=ft.Image(src=_detail_img_src, width=_horizontal_img_w, height=300,
                                          fit=ft.BoxFit.CONTAIN)),
            info_row(ft.Icons.ACCESS_TIME, "Época", foto.get("epoca")),
            info_row(ft.Icons.SELL, "Tipo", foto.get("lugar")),
            info_row(ft.Icons.STICKY_NOTE_2, "Nota", foto.get("Nota")),
            ft.Row([ft.Icon(ft.Icons.PEOPLE, size=15, color=ft.Colors.BLUE_GREY_400),
                    ft.Text("Personas:", size=13, weight=ft.FontWeight.W_600,
                            color=ft.Colors.BLUE_GREY_600)], spacing=6) if chips else ft.Container(height=0),
            ft.Row(controls=chips, spacing=6, wrap=True) if chips else ft.Container(height=0),
        ], spacing=7, scroll=ft.ScrollMode.AUTO)

        vertical_content = ft.Row([
            ft.Container(border_radius=10, alignment=ft.Alignment.CENTER,
                         clip_behavior=ft.ClipBehavior.HARD_EDGE,
                         content=ft.Image(src=_detail_img_src, width=_vertical_img_w, height=500,
                                          fit=ft.BoxFit.CONTAIN)),
            ft.Container(expand=True, padding=10, content=ft.Column([
                info_row(ft.Icons.ACCESS_TIME, "Época", foto.get("epoca")),
                info_row(ft.Icons.SELL, "Tipo", foto.get("lugar")),
                info_row(ft.Icons.STICKY_NOTE_2, "Nota", foto.get("Nota")),
                ft.Row([ft.Icon(ft.Icons.PEOPLE, size=15, color=ft.Colors.BLUE_GREY_400),
                        ft.Text("Personas:", size=13, weight=ft.FontWeight.W_600,
                                color=ft.Colors.BLUE_GREY_600)], spacing=6) if chips else ft.Container(height=0),
                ft.Row(controls=chips, spacing=6, wrap=True) if chips else ft.Container(height=0),
            ], spacing=7, scroll=ft.ScrollMode.AUTO)),
        ])

        if not src:
            content_block = ft.Container(
                height=220, bgcolor=ft.Colors.BLUE_GREY_100, border_radius=10, alignment=ft.Alignment.CENTER,
                content=ft.Column([
                    ft.Icon(ft.Icons.PHOTO_LIBRARY, size=56, color=ft.Colors.BLUE_GREY_300),
                    ft.Text(f"Sin imagen ({image_filename_hint(fid)})", size=12, color=ft.Colors.BLUE_GREY_400),
                ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER))
        else:
            content_block = vertical_content if _usar_lado_a_lado else horizontal_content

        async def _abrir_imagen_fs(img_bytes_or_path, fid):
            close_dlg(dlg_ref[0])
            await show_fullscreen(img_bytes_or_path, fid)

        dlg = ft.AlertDialog(
            title=ft.Row([
                ft.Icon(ft.Icons.PHOTO, color=PRIMARY, size=22),
                ft.Text(f"  Foto #{fid}", weight=ft.FontWeight.BOLD, expand=True, size=17),
                ft.IconButton(ft.Icons.CLOSE, icon_size=20, on_click=on_close),
            ]),
            bgcolor=SURFACE,
            content=ft.Container(width=_dialog_width, height=620,
                                  clip_behavior=ft.ClipBehavior.HARD_EDGE, content=content_block),
            actions=[
                ft.TextButton("Descargar", icon=ft.Icons.DOWNLOAD, disabled=(not bool(src)),
                              on_click=descargar_imagen),
                ft.TextButton("Abrir imagen", icon=ft.Icons.OPEN_IN_NEW, disabled=(not bool(src)),
                              on_click=lambda e: Page.run_task(_abrir_imagen_fs, _detail_img_src, fid)),
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )
        dlg_ref[0] = dlg
        open_dlg(dlg)

    # ═══════════════════════════════════════════════════════════
    # PÁGINA: GALERÍA
    # ═══════════════════════════════════════════════════════════
    # NUEVO respecto a main Android.py: en vez de un número fijo de
    # columnas (_COLS=3) con tarjetas estiradas al ancho disponible
    # (lo que en pantallas anchas agranda mucho la imagen y se nota que
    # es una miniatura de baja resolución), se usa un ancho de tarjeta
    # FIJO — igual que ya hace `main Windows.py` — y una fila que se
    # ajusta sola (`wrap=True`): el número de tarjetas por línea sale
    # solo de cuánto ancho hay disponible, sin necesidad de detectar el
    # tipo de dispositivo ni recalcular nada al redimensionar la
    # ventana. En un móvil caben 2-3 por línea, en una tablet 4-5, en
    # un portátil/PC bastantes más (en una pantalla ancha, más de 8) —
    # y las miniaturas se ven nítidas en todos los casos porque nunca
    # se estiran más allá de su tamaño natural.
    _GAL_SPACING = 10
    # Bajado de 176 a 150: en un Huawei P30 Pro (viewport CSS más estrecho
    # que un móvil "de referencia" tipo 390-414px) 176 dejaba solo una
    # ficha por línea -- con dos fichas de 176 + 10 de separación + los
    # 24 de relleno lateral de la Galería (12+12) hacían falta 386px de
    # ancho, que no siempre hay. 150 deja sitio de sobra para 2 en la
    # inmensa mayoría de móviles, sin perder nitidez (sigue muy por
    # debajo de THUMB_SIZE, 220, así que la miniatura se ve igual de
    # nítida, solo un poco más pequeña).
    _CARD_W = 150

    def _gallery_layout():
        # NUEVO: cuántas fichas de _CARD_W caben, con _GAL_SPACING entre
        # ellas, en el ancho disponible de la Galería (el ancho de página
        # menos el relleno lateral de gallery_col, 12+12 más abajo), y
        # cuánto sobra a los lados de una fila completa con ese número de
        # fichas ("margen"). Se usa para partir cada grupo en filas "a
        # mano" (ver _refresh_gallery_impl).
        #
        # OJO -- probado y descartado: centrar solo las filas completas
        # con alignment=CENTER y dejar las incompletas con alignment=START
        # parecía la forma obvia de hacerlo, pero el propio ft.Row (aunque
        # solo tenga unas pocas fichas) reclama para sí todo el ancho
        # disponible -- así que con alignment=START la primera ficha caía
        # exactamente en el borde izquierdo (margen 0), mientras que con
        # alignment=CENTER caía "margen" píxeles más adentro: dos filas,
        # dos puntos de arranque distintos para la primera ficha, que es
        # justo el desajuste que se veía. La solución es aplicar el MISMO
        # margen izquierdo fijo a todas las filas -- completas o no -- en
        # vez de dejar que cada una decida su propio punto de partida.
        ancho_disponible = (Page.width or 400) - 24
        cols = max(int((ancho_disponible + _GAL_SPACING) // (_CARD_W + _GAL_SPACING)), 1)
        ancho_fila_completa = cols * _CARD_W + (cols - 1) * _GAL_SPACING
        margen = max(int((ancho_disponible - ancho_fila_completa) // 2), 0)
        return cols, margen

    gallery_col = ft.ListView(expand=1, spacing=10, padding=ft.Padding.only(left=12, right=12, top=0, bottom=10))

    f_ep = mk_dropdown(label="Época", options=[ft.dropdown.Option("Todo")], value="Todo", expand=True,
                        dense=True, text_size=12, label_style=ft.TextStyle(size=16), menu_height=480)
    f_lu = mk_dropdown(label="Tipo", options=[ft.dropdown.Option("Todo")], value="Todo", expand=True,
                        dense=True, text_size=12, label_style=ft.TextStyle(size=16), menu_height=480)
    f_pe = mk_dropdown(label="Persona", options=[ft.dropdown.Option("Todo")], value="Todo", expand=True,
                        dense=True, text_size=12, label_style=ft.TextStyle(size=16), menu_height=480)
    f_group = mk_dropdown(label="Agrupar por", options=[
        ft.dropdown.Option("epoca", "Época"),
        ft.dropdown.Option("tipo", "Tipo"),
        ft.dropdown.Option("persona", "Persona"),
    ], value="epoca", expand=True, dense=True, text_size=12, label_style=ft.TextStyle(size=16))

    f_txt = ft.TextField(hint_text="Buscar por número, nota, época, tipo o persona", dense=True,
                          border_radius=8, prefix_icon=ft.Icons.SEARCH, expand=True, height=42,
                          text_size=11, content_padding=10)

    count_text = ft.Text("", size=12, color=ft.Colors.GREY_600)

    def empty_gallery(filters_active: bool) -> ft.Container:
        title = "No hay fotos con esos filtros" if filters_active else "Todavía no hay fotos"
        subtitle = ("Prueba a borrar la búsqueda o cambia época, tipo o persona." if filters_active else
                    "Importa el ZIP que te haya pasado el administrador del álbum, en la pestaña Ajustes.")
        return ft.Container(
            expand=True, alignment=ft.Alignment.CENTER, padding=ft.Padding.only(left=24, right=24, top=24, bottom=24),
            content=ft.Column([
                ft.Icon(ft.Icons.PHOTO_LIBRARY_OUTLINED, size=54, color=ft.Colors.BLUE_GREY_200),
                ft.Text(title, size=18, weight=ft.FontWeight.BOLD, color=ft.Colors.BLUE_GREY_700),
                ft.Text(subtitle, size=13, color=ft.Colors.GREY_500, text_align=ft.TextAlign.CENTER),
            ], tight=True, spacing=8, horizontal_alignment=ft.CrossAxisAlignment.CENTER))

    ORDER_BY = {
        "epoca": "COALESCE(f.epoca, '') COLLATE NOCASE_ES ASC, f.foto DESC",
        "tipo": "COALESCE(f.lugar, '') COLLATE NOCASE_ES ASC, COALESCE(f.epoca, '') COLLATE NOCASE_ES ASC, f.foto DESC",
        "persona": "COALESCE(i.nom, '') COLLATE NOCASE_ES ASC, COALESCE(f.epoca, '') COLLATE NOCASE_ES ASC, f.foto DESC",
    }
    GROUP_ICONS = {"epoca": ft.Icons.ACCESS_TIME, "tipo": ft.Icons.SELL, "persona": ft.Icons.PERSON}

    def group_title(valor: str, total: int):
        if not valor:
            valor = "(Sin valor)"
        icono = GROUP_ICONS.get(f_group.value, ft.Icons.LABEL)
        texto_contador = f"{total} foto{'s' if total != 1 else ''}"
        return ft.Container(
            margin=ft.Margin.only(left=0, right=0, top=14, bottom=8), border_radius=8, bgcolor=PRIMARY,
            padding=ft.Padding.only(left=12, right=10, top=8, bottom=8),
            content=ft.Row(controls=[
                ft.Row(controls=[
                    ft.Icon(icono, size=16, color=ft.Colors.WHITE),
                    ft.Text(valor, size=14, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE,
                            max_lines=1, overflow=ft.TextOverflow.ELLIPSIS),
                ], spacing=6, expand=True),
                ft.Container(bgcolor=ft.Colors.with_opacity(0.22, ft.Colors.WHITE), border_radius=20,
                             padding=ft.Padding.only(left=9, right=9, top=2, bottom=2),
                             content=ft.Text(texto_contador, size=11, weight=ft.FontWeight.W_600, color=ft.Colors.WHITE)),
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN, vertical_alignment=ft.CrossAxisAlignment.CENTER))

    # ARREGLADO: build_groups() paginaba por número de FOTOS (recibía ya
    # `fotos_visibles`, la porción de `fotos` recortada a _visible_limit["n"]
    # en _refresh_gallery_impl, y la agrupaba entera). Con "Época"/"Tipo"
    # eso es correcto porque cada foto genera siempre UNA ficha, en un
    # único grupo. Pero con "Persona" una misma foto puede generar VARIAS
    # fichas -- una por cada persona con la que sale --, así que agrupar
    # tal cual un lote de _BATCH_SIZE fotos podía materializar de golpe
    # muchas más de _BATCH_SIZE fichas (justo el problema de memoria en
    # iPad que el lote por tandas se creó para evitar -- ver el aviso
    # junto a _BATCH_SIZE, unas líneas más abajo). Y como la foto se
    # cortaba ANTES de mirar sus personas, las fotos de una misma persona
    # podían quedar repartidas de forma incoherente entre lotes -- algunas
    # ya visibles, otras "pendientes" sin ningún indicio de que lo
    # estaban -- y pulsar "Cargar más fotos" podía no añadir ninguna ficha
    # nueva a la pantalla (todas las fotos del lote siguiente resultaban
    # ser de personas cuyo grupo ya estaba completo, o el lote se gastaba
    # en fotos que generan muy pocas fichas) mientras el contador de
    # "restantes" sí bajaba, porque contaba FOTOS, no fichas.
    #
    # Ahora build_groups() recibe TODAS las fotos filtradas (sin recortar)
    # más el `limite` de fichas a mostrar, y es ella quien decide cuántas
    # fotos necesita mirar para completar ese lote de fichas -- así el
    # límite por lote acota de verdad lo que se dibuja (con cualquier
    # modo de agrupar), y "restantes" queda en la misma unidad (fichas)
    # que lo que el botón realmente añade.
    def build_groups(fotos, limite):
        grupos = {}
        if not fotos:
            return grupos, 0

        if f_group.value == "persona":
            ids = [f["foto"] for f in fotos]
            persona_filtrada = f_pe.value
            if persona_filtrada == "Todo":
                persona_filtrada = None
            LOTE = 500
            tags_by_foto = {}
            for i in range(0, len(ids), LOTE):
                trozo = ids[i:i + LOTE]
                placeholders = ",".join("?" * len(trozo))
                for r in Q(
                        f"SELECT imagen, nom FROM Imagenes WHERE imagen IN ({placeholders}) ORDER BY nom COLLATE NOCASE_ES",
                        trozo):
                    tags_by_foto.setdefault(r["imagen"], []).append(r["nom"])

            # Una entrada de `fichas` por cada ficha que de verdad se va a
            # dibujar.
            fichas = []
            for f in fotos:
                noms = tags_by_foto.get(f["foto"], [])
                if not noms:
                    fichas.append(("Sin personas", f))
                    continue
                acompanantes = [n for n in noms if n != persona_filtrada]
                if persona_filtrada and not acompanantes:
                    fichas.append(("Solo/a o con desconocidos", f))
                else:
                    for n in acompanantes:
                        fichas.append((n, f))

            # IMPORTANTE: se ordenan las fichas explícitamente en Python por
            # (persona, época, foto) ANTES de cortar por `limite`, en vez de
            # confiar en el orden con el que llegó `fotos` desde SQL.
            #
            # `fotos` viene de "SELECT DISTINCT f.* ... ORDER BY
            # COALESCE(i.nom, ...)": la columna de orden (i.nom) no forma
            # parte de la lista DISTINCT, así que para cada foto el motor
            # puede elegir cualquiera de sus filas de Imagenes para decidir
            # su posición -- el resultado no se corresponde de forma fiable
            # con "agrupado por persona", y nada garantiza que sea estable
            # entre dos llamadas idénticas (menos aún comparando el SQLite
            # nativo con el SQLite WASM de Pyodide del navegador). Cortar
            # `fichas` según ese orden reparte las fotos de cada persona de
            # forma dispersa por todo el listado (de ahí los recuentos por
            # persona más bajos de lo esperado) y, si el orden cambia entre
            # una petición y la siguiente, el segundo lote deja de ser un
            # superconjunto limpio del primero (de ahí que "Cargar 60 fotos
            # más" añadiera muchas menos de 60 fichas nuevas).
            #
            # Ordenando aquí, en Python, con una clave que no depende en
            # absoluto de SQL, el resultado es determinista: cada lote de
            # `limite` fichas completa primero a las personas anteriores
            # alfabéticamente antes de empezar con la siguiente, y pedir un
            # `limite` mayor siempre añade una extensión exacta del lote
            # anterior.
            fichas.sort(key=lambda t: (t[0] or "", t[1].get("epoca") or "", t[1]["foto"]))

            visibles = fichas[:limite]
            restantes = len(fichas) - len(visibles)
            for nombre, foto in visibles:
                grupos.setdefault(nombre, []).append(foto)
            for lista in grupos.values():
                lista.sort(key=lambda f: f.get("epoca") or "")
            return grupos, restantes

        fotos_visibles = fotos[:limite]
        restantes = len(fotos) - len(fotos_visibles)
        for f in fotos_visibles:
            if f_group.value == "epoca":
                clave = f.get("epoca") or "(Sin época)"
            elif f_group.value == "tipo":
                clave = f.get("lugar") or "(Sin tipo)"
            else:
                pers = Q("SELECT nom FROM Imagenes WHERE imagen=? ORDER BY nom COLLATE NOCASE_ES LIMIT 1", (f["foto"],))
                clave = pers[0]["nom"] if pers else "Sin personas"
            grupos.setdefault(clave, []).append(f)
        return grupos, restantes

    def refresh_dropdowns():
        current_ep, current_lu, current_pe = f_ep.value, f_lu.value, f_pe.value

        def opts(rows, key):
            return [ft.dropdown.Option(key="Todo", text="Todo")] + [
                ft.dropdown.Option(key=r[key], text=r[key]) for r in rows]

        f_ep.options.clear()
        f_ep.options = opts(Q("SELECT epoca FROM Epoca ORDER BY epoca COLLATE NOCASE_ES"), "epoca")
        f_lu.options.clear()
        f_lu.options = opts(Q("SELECT lugar FROM Lugares ORDER BY lugar COLLATE NOCASE_ES"), "lugar")
        f_pe.options.clear()
        f_pe.options = opts(Q("SELECT nom FROM Personas ORDER BY nom COLLATE NOCASE_ES"), "nom")

        ep_keys = [o.key for o in f_ep.options]
        lu_keys = [o.key for o in f_lu.options]
        pe_keys = [o.key for o in f_pe.options]
        f_ep.value = current_ep if current_ep in ep_keys else "Todo"
        f_lu.value = current_lu if current_lu in lu_keys else "Todo"
        f_pe.value = current_pe if current_pe in pe_keys else "Todo"

    _gallery_lock = threading.Lock()
    _gallery_gen = {"n": 0}

    # NUEVO: carga por lotes (ver plan de migración, 5-septendecies). Antes
    # se construían TODAS las fichas de golpe, con su imagen ya leída y
    # decodificada -- con álbumes de mil y pico fotos eso agota el límite
    # de memoria por pestaña del navegador en iPad (motor WebKit, mucho
    # más estricto que en Android/Windows), y las fotos dejan de verse
    # -- ni un error, solo un hueco vacío -- incluso en el visor de una
    # sola foto suelta. Ahora solo se construyen (y decodifican) como
    # mucho _BATCH_SIZE fotos a la vez.
    #
    # NUEVO (5-quadragies): probé a sustituir el botón "Cargar más fotos"
    # por una carga automática al hacer scroll (gallery_col.on_scroll),
    # pero se descartó -- ver el aviso completo junto a la definición de
    # `_cargar_mas()` más abajo: rompía por completo el poder abrir
    # cualquier ficha después del primer scroll. El límite por lote SÍ se
    # mantiene (sigue sin construirse el álbum entero de golpe): es lo
    # que evita agotar la memoria del navegador en iPad, así que quitar
    # el límite del todo reintroduciría el problema original de
    # 5-septendecies con álbumes grandes -- solo cambió, y solo una vez
    # (ver más abajo), cómo se pide el siguiente lote.
    _BATCH_SIZE = 60
    _visible_limit = {"n": _BATCH_SIZE}

    def refresh_gallery(reset_limit=True):
        if reset_limit:
            _visible_limit["n"] = _BATCH_SIZE
        _gallery_gen["n"] += 1
        my_gen = _gallery_gen["n"]
        with _gallery_lock:
            _refresh_gallery_impl(my_gen, reset_limit)

    def _refresh_gallery_impl(my_gen, reset_limit=True):
        get_image_index()
        ep, lu, pe = f_ep.value, f_lu.value, f_pe.value
        if ep == "Todo": ep = None
        if lu == "Todo": lu = None
        if pe == "Todo": pe = None

        txt = (f_txt.value or "").strip()
        order_by = ORDER_BY.get(f_group.value, ORDER_BY["epoca"])
        cond, params = [], []
        if ep:
            cond.append("f.epoca=?"); params.append(ep)
        if lu:
            cond.append("f.lugar=?"); params.append(lu)
        if pe:
            cond.append("EXISTS(SELECT 1 FROM Imagenes i WHERE i.imagen=f.foto AND i.nom=?)"); params.append(pe)
        if txt:
            cond.append("(CAST(f.foto AS TEXT) LIKE ? OR COALESCE(f.Nota, '') LIKE ? OR "
                         "COALESCE(f.epoca, '') LIKE ? OR COALESCE(f.lugar, '') LIKE ? OR COALESCE(i.nom, '') LIKE ?)")
            params.extend([f"%{txt}%"] * 5)

        where = "WHERE " + " AND ".join(cond) if cond else ""
        fotos = Q(f"SELECT DISTINCT f.* FROM Fotos f LEFT JOIN Imagenes i ON i.imagen=f.foto {where} ORDER BY {order_by}", params)
        filters_active = bool(ep or lu or pe or txt)

        if my_gen != _gallery_gen["n"]:
            return

        # NUEVO (5-quadragies): antes esto se ejecutaba SIEMPRE que la
        # lista ya tuviera contenido -- vaciar gallery_col y llamar a
        # .update() antes de rellenarlo nuevo. Eso es justo lo que hacía
        # que pulsar "Cargar más fotos" (o ahora, hacer scroll) devolviera
        # al principio de la lista: un ft.ListView vacío no tiene nada
        # que desplazar, así que Flutter fija su posición de scroll a 0
        # en ese instante -- y como justo después se rellena con las
        # fotos ya cargadas MÁS el lote nuevo, el resultado visible es
        # "la pantalla salta al principio". Solo tiene sentido vaciar así
        # cuando el CONJUNTO de fotos a mostrar cambia de verdad (nuevo
        # filtro, nueva búsqueda, recarga inicial) -- ahí sí queremos
        # saltar al principio de los nuevos resultados. Cuando lo único
        # que pasa es que se amplía el lote visible sobre el MISMO
        # resultado filtrado (reset_limit=False, disparado por el scroll
        # cerca del final), no hay que vaciar nada: la lista pasa
        # directamente de "N tarjetas" a "N + lote tarjetas" sin pasar
        # nunca por cero, y el scroll se queda exactamente donde estaba.
        if reset_limit and gallery_col.controls:
            gallery_col.controls = []
            gallery_col.update()

        if my_gen != _gallery_gen["n"]:
            return

        if not fotos:
            gallery_col.controls = [empty_gallery(filters_active)]
        else:
            # Solo se materializan (con imagen decodificada, vía make_card)
            # como mucho _visible_limit["n"] FICHAS del resultado filtrado
            # -- el resto se cuenta pero no se construye todavía. Con
            # "Época"/"Tipo" una ficha es siempre una foto, pero con
            # "Persona" una misma foto puede generar varias fichas -- por
            # eso ahora es build_groups() quien decide cuántas fotos
            # necesita mirar para completar el lote de FICHAS pedido, en
            # vez de cortar aquí por número de fotos (ver el aviso junto a
            # build_groups()).
            limite = _visible_limit["n"]
            grupos, restantes = build_groups(fotos, limite)
            # NUEVO: antes esto era un único ft.Row(wrap=True) por grupo, que
            # Flutter partía solo en líneas según el ancho disponible -- pero
            # todas las líneas comparten la misma alineación en un Wrap, así
            # que no había forma de centrar solo las filas completas y dejar
            # la última (si queda incompleta) pegada a la izquierda como el
            # resto. Por eso ahora se calcula cuántas fichas caben por fila y
            # cuánto margen sobra a los lados de una fila completa
            # (_gallery_layout(), a partir del ancho de página en este
            # instante), y se parte cada grupo en filas ya hechas a mano, TODAS
            # con ese mismo margen izquierdo fijo -- da igual que salgan
            # completas o no (ver el porqué, y la alternativa descartada, en
            # el comentario de _gallery_layout()). Así la primera ficha de
            # cualquier fila arranca siempre en el mismo punto, y de paso las
            # filas completas quedan centradas (mismo hueco a la izquierda de
            # la primera ficha que a la derecha de la última). Como el ancho
            # de página solo se consulta aquí -- al reconstruir la Galería, no
            # en cada redimensionado de la ventana --, si se cambia el tamaño
            # de la ventana sin disparar una recarga (cambiar filtro, buscar,
            # "Cargar más fotos"...) el reparto por filas no se vuelve a
            # calcular hasta la próxima vez que sí se reconstruya.
            cols, margen = _gallery_layout()
            controls = []
            for nombre, lista in grupos.items():
                controls.append(group_title(nombre, len(lista)))
                cards = [make_card(f, show_detail) for f in lista]
                filas = []
                for i in range(0, len(cards), cols):
                    tanda = cards[i:i + cols]
                    fila = ft.Row(controls=tanda, spacing=_GAL_SPACING, alignment=ft.MainAxisAlignment.START)
                    filas.append(ft.Container(padding=ft.Padding.only(left=margen), content=fila)
                                  if margen else fila)
                controls.append(ft.Column(controls=filas, spacing=_GAL_SPACING))

            if restantes > 0:
                siguiente_lote = min(_BATCH_SIZE, restantes)

                # NUEVO (5-quadragies) -- Y REVERTIDO EN LA MISMA RONDA:
                # aquí hubo, brevemente, una versión que quitaba este botón
                # y cargaba el siguiente lote sola al detectar scroll cerca
                # del final (gallery_col.on_scroll). Se probó porque
                # pedías, como alternativa válida, que al hacer scroll
                # aparecieran todas las fotos sin necesidad de un botón --
                # pero en cuanto se publicó apareció un problema nuevo y
                # más grave: tras el primer scroll, dejaba de poder abrirse
                # NINGUNA ficha de foto, en toda la Galería. Sospecha
                # razonada (sin poder confirmarla con un navegador real
                # desde aquí, la limitación de siempre con esta app): un
                # ListView de Flutter puede disparar el evento de scroll
                # decenas de veces por segundo durante un gesto, y cada
                # aviso viajaba hasta Python (por el puente Worker <->
                # hilo principal, la misma vía ya señalada como frágil en
                # el plan de migración -- 5-sexdecies, 5-unvicies) y desde
                # ahí podía disparar una reconstrucción completa de la
                # lista (Page.update()) en pleno gesto -- lo bastante para
                # dejar descolocado el reconocimiento de toques de
                # Flutter, incluso en tarjetas que ya estaban antes del
                # scroll y no habían cambiado. Al no poder reproducir ni
                # depurar esto en un navegador real desde este entorno, la
                # decisión más segura es volver al botón de toda la vida
                # -- que nunca tuvo este problema -- y quedarnos solo con
                # el arreglo bueno de esta ronda: que pulsarlo ya no manda
                # de vuelta al principio de la lista (ver el comentario
                # junto al vaciado condicional de gallery_col, más arriba).
                def _cargar_mas(e):
                    _visible_limit["n"] += _BATCH_SIZE
                    refresh_gallery(reset_limit=False)

                controls.append(ft.Container(
                    alignment=ft.Alignment.CENTER,
                    padding=ft.Padding.only(top=10, bottom=20),
                    content=ft.ElevatedButton(
                        f"Cargar {siguiente_lote} fotos más ({restantes} restantes)",
                        icon=ft.Icons.EXPAND_MORE, on_click=_cargar_mas)))

            gallery_col.controls = controls

        n = len(fotos)
        count_text.value = f"{n} foto{'s' if n != 1 else ''}"
        if filters_active:
            count_text.value += f" encontrada{'s' if n != 1 else ''}"

        if my_gen != _gallery_gen["n"]:
            return
        Page.update()

    f_ep.on_select = lambda e: refresh_gallery()
    f_lu.on_select = lambda e: refresh_gallery()
    f_pe.on_select = lambda e: refresh_gallery()
    f_group.on_select = lambda e: refresh_gallery()

    # NOTA: aquí NO se puede usar threading.Timer (como hacía una versión
    # anterior) para retrasar la búsqueda mientras el usuario teclea:
    # Timer.start() intenta arrancar un hilo real del sistema operativo,
    # y Pyodide corre en un WebAssembly de un solo hilo -- eso hacía
    # saltar "can't start new thread" en cuanto se escribía algo en el
    # cuadro de búsqueda dentro del navegador (en escritorio, con hilos
    # de verdad disponibles, no habría dado ningún problema). El
    # equivalente que sí funciona en un entorno de un solo hilo es una
    # tarea `asyncio` que espera con `await asyncio.sleep(...)` sin
    # bloquear nada -- el mismo patrón de "ceder el control" que ya usa
    # el resto de la app (ver _procesar_zip). Un contador de generación
    # descarta las búsquedas que quedan obsoletas si se sigue tecleando
    # antes de que termine la espera.
    _search_gen = {"n": 0}

    def _debounced_text_search(e):
        _search_gen["n"] += 1
        mi_generacion = _search_gen["n"]

        async def _esperar_y_buscar():
            await asyncio.sleep(0.35)
            if mi_generacion == _search_gen["n"]:
                refresh_gallery()

        Page.run_task(_esperar_y_buscar)

    f_txt.on_change = _debounced_text_search

    def clear_filters(e):
        f_ep.value = "Todo"; f_lu.value = "Todo"; f_pe.value = "Todo"; f_txt.value = ""
        refresh_gallery()

    # NOTA: ft.Column no acepta "bgcolor" en esta versión de Flet (solo
    # ft.Container lo tiene) — por eso el fondo blanco se aplica aquí
    # envolviendo la columna en un Container, en vez de pasarlo
    # directamente al Column como se probó en un primer intento.
    gallery_page = ft.Container(
        expand=True, bgcolor=SURFACE,
        content=ft.Column([
            ft.Container(
                bgcolor=GREY_BG, padding=ft.Padding.only(left=12, right=12, top=10, bottom=10),
                content=ft.Column([
                    ft.Row([f_txt], spacing=8),
                    ft.Container(height=6),
                    ft.ResponsiveRow([
                        ft.Container(f_ep, col={"xs": 4}),
                        ft.Container(f_lu, col={"xs": 4}),
                        ft.Container(f_pe, col={"xs": 4}),
                        ft.Container(f_group, col={"xs": 6}),
                        ft.Container(ft.TextButton("Todas", icon=ft.Icons.FILTER_ALT_OFF, on_click=clear_filters,
                                                    style=ft.ButtonStyle(color=ft.Colors.BLUE_GREY_400)), col={"xs": 6}),
                    ]),
                    count_text,
                ], spacing=6)),
            ft.Divider(height=1),
            gallery_col,
        ], spacing=0, expand=True))

    # ═══════════════════════════════════════════════════════════
    # PÁGINA: AJUSTES  (Importar ZIP + estadísticas + manual)
    # ═══════════════════════════════════════════════════════════
    stats_row = ft.Row([], spacing=6, alignment=ft.MainAxisAlignment.SPACE_BETWEEN)

    def refresh_stats():
        get_image_index()
        total_fotos = Q("SELECT COUNT(*) n FROM Fotos")[0]["n"]
        data = [
            (total_fotos, "Fotos", ft.Icons.PHOTO_LIBRARY, ft.Colors.BLUE_600),
            (Q("SELECT COUNT(*) n FROM Epoca")[0]["n"], "Épocas", ft.Icons.ACCESS_TIME, ft.Colors.ORANGE_600),
            (Q("SELECT COUNT(*) n FROM Lugares")[0]["n"], "Tipos", ft.Icons.SELL, ft.Colors.PURPLE_600),
            (Q("SELECT COUNT(*) n FROM Personas")[0]["n"], "Personas", ft.Icons.PEOPLE, ft.Colors.GREEN_600),
        ]
        page_width = Page.width or 360
        card_width = int((page_width - 80) / 4)
        stats_row.controls = [
            ft.Container(width=card_width, border_radius=10, bgcolor=SURFACE,
                         border=ft.Border.all(1, ft.Colors.GREY_200),
                         padding=ft.Padding.only(left=12, right=12, top=12, bottom=12),
                         content=ft.Column([
                             ft.Icon(ic, color=col, size=24),
                             ft.Text(str(n), size=16, weight=ft.FontWeight.BOLD, color=col),
                             ft.Text(lb, size=10, color=ft.Colors.GREY_600),
                         ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=3))
            for n, lb, ic, col in data
        ]
        Page.update()

    try:
        import importlib.metadata
        flet_ver = importlib.metadata.version("flet")
    except Exception:
        flet_ver = "desconocida"

    settings_page = ft.Container(
        padding=ft.Padding.only(left=20, right=20, top=20, bottom=20), expand=True, bgcolor=SURFACE,
        content=ft.Column([
            ft.Text("Estadísticas", size=16, weight=ft.FontWeight.BOLD, color=ft.Colors.BLUE_GREY_700),
            stats_row,
            ft.Divider(height=18),
            import_hint_text,
            ft.Column([import_progress_bar, import_progress_text], spacing=4),
            ft.ElevatedButton("Descargar manual", icon=ft.Icons.MENU_BOOK, on_click=descargar_manual),
            ft.Divider(height=18),
            ft.Text(f"Álbum {VERSION} © Mario Jato 2026\nHecho en Flet {flet_ver} con la ayuda de IA",
                     size=12, color=ft.Colors.GREY_500),
            # Hueco reservado al final: el botón HTML "Elegir carpeta con
            # las partes ZIP" (inyectado por habilitar_arrastrar_zip.py,
            # visible solo en esta pestaña) está anclado fijo en la parte
            # de ABAJO de la pantalla, por encima de la barra de
            # gestos/home -- si aquí hubiera contenido de sobra como para
            # hacer scroll hasta el final, este texto de copyright podría
            # quedar tapado debajo de ese botón. Este espacio en blanco
            # (altura aproximada de esa barra: botón + sombra + margen de
            # seguridad) evita que eso llegue a pasar.
            ft.Container(height=70),
        ], spacing=12, scroll=ft.ScrollMode.AUTO))

    # ═══════════════════════════════════════════════════════════
    # NAVEGACIÓN PRINCIPAL  (sin cambios)
    # ═══════════════════════════════════════════════════════════
    pages_list = [gallery_page, settings_page]
    body = ft.Container(expand=True, content=gallery_page, bgcolor=SURFACE)

    _nav_defs = [("Galería", ft.Icons.PHOTO_LIBRARY), ("Ajustes", ft.Icons.SETTINGS)]
    _nav_btns = []
    _nav_sel = [0]

    def _build_nav_btn(idx, label, icon, selected):
        col = ft.Colors.WHITE if selected else ft.Colors.BLUE_100
        return ft.Container(
            border_radius=10, padding=ft.Padding.only(left=12, right=12, top=8, bottom=8),
            bgcolor=ft.Colors.with_opacity(0.12, ft.Colors.WHITE) if selected else ft.Colors.TRANSPARENT,
            on_click=lambda e, i=idx: _select_nav(i), ink=True,
            content=ft.Row(spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER, controls=[
                ft.Icon(icon, size=24, color=col),
                ft.Text(label, size=15, color=col, weight=ft.FontWeight.W_600 if selected else ft.FontWeight.W_500),
            ]))

    def _select_nav(idx):
        try:
            _nav_sel[0] = idx
            for i, btn in enumerate(_nav_btns):
                sel = (i == idx)
                col = ft.Colors.WHITE if sel else ft.Colors.BLUE_200
                col_stack = btn.content.controls
                col_stack[0].color = col
                col_stack[1].color = col
                col_stack[1].weight = ft.FontWeight.W_600 if sel else ft.FontWeight.NORMAL
                btn.bgcolor = ft.Colors.with_opacity(0.15, ft.Colors.WHITE) if sel else ft.Colors.TRANSPARENT
            body.content = pages_list[idx]
            if idx == 1:
                refresh_stats()
            _notificar_pagina_activa("ajustes" if idx == 1 else "galeria")
            Page.update()
        except Exception as ex:
            snack(f"Error al cambiar de pestaña:\n{ex}", ft.Colors.RED_500)

    for i, (lbl, ico) in enumerate(_nav_defs):
        _nav_btns.append(_build_nav_btn(i, lbl, ico, i == 0))

    Page.appbar = ft.AppBar(
        title=ft.Text("Álbum", font_family="AlbumRetro", size=34, color="#F4E7C5"),
        center_title=False, automatically_imply_leading=False, title_spacing=12, toolbar_height=60,
        bgcolor=PRIMARY,
        actions=[
            ft.Row(spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER, controls=[
                _nav_btns[0],
                ft.Container(width=1, height=28, bgcolor=ft.Colors.WHITE24),
                _nav_btns[1],
            ]),
            ft.Container(width=9),
        ],
    )

    Page.controls.clear()
    Page.add(ft.SafeArea(avoid_intrusions_top=False, content=body, expand=True))
    # Aviso inicial: arrancamos siempre en "galeria" (pages_list[0]), pero se
    # notifica igualmente para que el botón HTML de "elegir carpeta" (oculto
    # por defecto en el HTML inyectado) quede sincronizado desde el primer
    # momento, sin depender de que ambos lados coincidan "por casualidad".
    _notificar_pagina_activa("galeria")

    set_status("Cargando datos...")
    try:
        refresh_dropdowns()
        refresh_gallery()
        refresh_stats()
    except Exception as _e:
        show_fatal(_e)


if __name__ == "__main__":
    ft.run(main)
#!/usr/bin/env python3
"""
fix_pyodide_cdn.py -- arregla el micropip corrupto que trae Flet 0.85.3
=========================================================================

QUÉ PROBLEMA RESUELVE ESTE SCRIPT
----------------------------------
Al publicar Álbum con Flet 0.85.3, la app se quedaba bloqueada en
"Working" (el título de la pestaña del navegador) tanto en Windows como
en Android -- es decir, en TODOS los dispositivos, no solo el iPad que
motivó el cambio a esta versión de Flet.

Investigando el `python.js` que genera `flet publish` con Flet 0.85.3,
encontré que -- a diferencia de la 0.86.5, que usaba siempre la copia
local de Pyodide que ya viene dentro de `dist/pyodide/` -- la 0.85.3, por
defecto, va a buscar Pyodide a un CDN externo
(`cdn.jsdelivr.net`) en cada visita, aunque la copia local esté ahí sin
usarse. Si la red del dispositivo no puede llegar a ese CDN concreto (o
tarda demasiado), la app se queda esperando para siempre sin mostrar
ningún error -- exactamente el síntoma que describiste.

El arreglo "obvio" es publicar con la opción `--no-cdn` (fuerza a usar
la copia local, igual que hacía por defecto la 0.86.5). Pero al
probarlo encontré un SEGUNDO fallo, este sí un error real de
empaquetado del propio Flet 0.85.3: el archivo de micropip que trae
`dist/pyodide/micropip-0.8.0-py3-none-any.whl` NO es un archivo .whl de
verdad -- es, literalmente, una página de error "404 Not Found" de 379
bytes, guardada por error como si fuera el paquete. Lo confirmé
comparando el hash del archivo contra el que declara el propio paquete
`flet_web` de PyPI (coinciden) -- así que no es un problema de mi
entorno de pruebas, es un fallo real en el paquete `flet_web==0.85.3`
que descargará cualquiera que instale esa versión.

Este script sustituye ese archivo corrupto por un micropip 0.9.0 real
(el mismo que Pyodide 0.27.7 espera, descargado de PyPI) y corrige la
ficha `pyodide-lock.json` para que apunte al archivo correcto con su
hash real.

CÓMO USARLO
-----------
1. Publica con la opción `--no-cdn` (importante, sin ella este arreglo
   no sirve de nada porque la app ni siquiera mira la copia local):

       flet publish main.py --no-cdn

2. Deja este script (`fix_pyodide_cdn.py`) y el archivo que lo acompaña
   (`micropip-0.9.0-py3-none-any.whl`) EN LA MISMA CARPETA, junto a
   `fix_icons.py` y `habilitar_arrastrar_zip.py`.

3. Ejecuta, en este orden, después de cada `flet publish --no-cdn`:

       python fix_icons.py --icon assets/icon.png --dist dist --main main.py
       python fix_pyodide_cdn.py --dist dist
       python habilitar_arrastrar_zip.py --dist dist

   (el orden entre fix_icons/fix_pyodide_cdn/habilitar_arrastrar_zip no
   importa entre sí -- tocan archivos distintos -- pero los tres deben
   ir después de `flet publish`).

VERIFICADO
----------
- Reproducido en un navegador real (Chromium automatizado, sirviendo la
  carpeta dist/ igual que la sirve GitHub Pages): con el micropip
  corrupto sin arreglar, `flet publish --no-cdn` falla con
  "shutil.ReadError: ... is not a zip file". Con este script aplicado,
  Pyodide y micropip cargan correctamente ("Loaded micropip, packaging"
  en la consola) y la app pasa a instalar el paquete `flet` desde PyPI
  -- el mismo paso que ya hacía con la 0.86.5 y que siempre necesitó
  conexión a internet normal (a diferencia del paso de Pyodide, que
  ahora ya no depende de ningún CDN externo).
- Confirmado, comparando el hash SHA-256 del archivo corrupto contra el
  que declara el propio paquete `flet_web-0.85.3.dist-info/RECORD` de
  PyPI, que la corrupción viene de fábrica en el paquete -- no es un
  fallo de instalación local, así que este script hará falta en
  cualquier equipo que instale flet==0.85.3, no solo en el tuyo.

TERCER PROBLEMA (el que arregla la versión de hoy del script)
----------------------------------------------------------------
Con los dos arreglos de arriba ya aplicados, me mandaste el archivo de
errores de la consola de tu navegador (Error.txt) y confirmó que
Pyodide y micropip ya cargan bien en local -- pero apareció un TERCER
fallo, distinto, que es el que de verdad te tenía bloqueado en
"Working" en la publicación real:

    Failed to find a valid digest in the 'integrity' attribute for
    resource '.../pyodide/pillow-10.2.0-....whl' ... The resource has
    been blocked.
    python-worker.js: Failed to load Pillow, msgpack, six

`flet publish --no-cdn` solo copia a `dist/pyodide/` los dos archivos
mínimos que hacen falta para arrancar Pyodide (micropip y packaging).
Pero tu app necesita, además, tres paquetes "nativos" de Pyodide que
Álbum instala en cuanto arranca: `Pillow` (la trae tu `requirements.txt`),
y `msgpack` + `six` (los necesita el propio Flet para su protocolo
interno). Como esos tres NO están copiados en `dist/pyodide/`, y con
`--no-cdn` Pyodide 0.27.7 (la versión que usa Flet 0.85.3) busca
absolutamente todo -- también estos tres -- en esa misma carpeta local,
el navegador pide un archivo que no existe, tu propio servidor (GitHub
Pages) responde con una página de error genérica en su lugar, y esa
respuesta no coincide con el hash que Pyodide esperaba -- de ahí el
mensaje de "integrity". Es literalmente el mismo tipo de fallo silencioso
que el CDN externo del primer problema, solo que ahora contra tu propio
dominio en vez de contra jsdelivr.

Comprobé, comparando con una publicación real hecha con Flet 0.86.5 (tu
versión actual, que sí te funciona en Windows/Android), que esa versión
NO tiene este problema por una razón interesante: trae una versión más
nueva de Pyodide que, por dentro, ya distingue dos direcciones distintas
-- una para el motor de Pyodide en sí (que si la sirves en local, la
busca en local, sin tocar ningún CDN) y otra, aparte, solo para paquetes
sueltos como Pillow, que sigue yendo a jsdelivr automáticamente si
no encuentra el archivo al lado. Pyodide 0.27.7 (la que trae 0.85.3) es
más antigua y no tiene esa separación: para ella solo existe "un sitio"
donde buscarlo todo, y `--no-cdn` apunta ese único sitio a tu carpeta
local, sin ningún plan de respaldo.

**Arreglo de hoy:** en vez de intentar copiar los propios archivos de
Pillow/msgpack/six a tu `dist/` (son archivos especiales, compilados
para correr dentro del navegador -- no son los mismos que instalarías
con `pip install pillow` normal, y no los encontré en ningún sitio
descargable desde este entorno de trabajo, ver más abajo), este script
ahora también revisa `pyodide-lock.json` paquete por paquete: los que sí
están copiados en tu `dist/pyodide/` (micropip, packaging) los deja
exactamente como están -- se siguen sirviendo en local, que es lo que de
verdad arregló el problema original de "Working" en Windows/Android. Los
que NO están copiados (Pillow, msgpack, six, y cualquier otro que
pudiera hacer falta en el futuro si cambias `requirements.txt`) los
reescribe para que apunten directamente a la dirección completa de
jsdelivr, replicando a mano, para Flet 0.85.3, el mismo comportamiento
de "doble ruta" que la 0.86.5 ya trae de serie.

LO QUE NO HE PODIDO COMPROBAR
------------------------------
No he podido ver la app renderizada de verdad en un navegador con
acceso a internet normal desde este entorno (aquí solo tengo acceso a
PyPI, no a los CDN de Google/jsDelivr) -- así que el paso final,
"la app ya no se queda en Working y se ve la Galería", te toca
confirmarlo a ti tras publicar con estos tres scripts.

Tampoco he podido descargar yo mismo los archivos reales de
Pillow/msgpack/six compilados para Pyodide -- son archivos especiales
(no wheels normales de PyPI) que solo están en el propio CDN de
jsdelivr o en un paquete de casi 400 MB en GitHub, ninguno de los dos
accesible desde este entorno de trabajo. Por eso el arreglo de hoy no
copia esos tres archivos a tu carpeta (como sí hace con micropip), sino
que los deja apuntando a jsdelivr -- así que, a diferencia del arreglo
de micropip (100% local, cero dependencia de red), estos tres paquetes
concretos SÍ necesitan que tu navegador pueda llegar a jsdelivr.net la
primera vez que abras la app (luego quedan cacheados). Si tu red no
llega a jsdelivr, este síntoma concreto (fallo al cargar Pillow/msgpack/
six) podría repetirse -- pero ya no bloquearía el arranque del motor de
Pyodide en sí, que es la parte que antes fallaba en TODOS los
dispositivos.
"""

import argparse
import hashlib
import json
import sys
import zipfile
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
BUNDLED_WHEEL = SCRIPT_DIR / "micropip-0.9.0-py3-none-any.whl"
JSDELIVR_TEMPLATE = "https://cdn.jsdelivr.net/pyodide/v{version}/full/{file_name}"


def is_valid_wheel(path: Path) -> bool:
    """Un .whl es, por definición, un zip. Si no se puede abrir como
    zip, es que está corrupto (como el 404 guardado por error de
    Flet 0.85.3) o no existe."""
    if not path.exists():
        return False
    try:
        with zipfile.ZipFile(path) as z:
            return z.testzip() is None
    except (zipfile.BadZipFile, OSError):
        return False


def find_micropip_files(pyodide_dir: Path):
    return sorted(pyodide_dir.glob("micropip-*-py3-none-any.whl"))


def fix_micropip(dist_dir: Path) -> bool:
    pyodide_dir = dist_dir / "pyodide"
    lock_path = pyodide_dir / "pyodide-lock.json"

    if not pyodide_dir.is_dir():
        print(f"  AVISO: no encontré '{pyodide_dir}' -- ¿publicaste con "
              f"--no-cdn? Sin esa opción, Flet no copia una carpeta "
              f"pyodide/ utilizable y este script no tiene nada que "
              f"arreglar aquí (la app usará el CDN externo en su lugar, "
              f"que es precisamente lo que puede quedarse en 'Working' "
              f"si la red no llega hasta él).")
        return False

    if not lock_path.exists():
        print(f"  ERROR: no encontré {lock_path.name} dentro de "
              f"{pyodide_dir} -- ¿esta versión de Flet cambió la "
              f"estructura de la carpeta pyodide/? Avisa con este "
              f"mensaje si ves esto.")
        return False

    if not BUNDLED_WHEEL.exists():
        print(f"  ERROR: falta '{BUNDLED_WHEEL.name}' junto a este "
              f"script. Tiene que estar en la misma carpeta que "
              f"fix_pyodide_cdn.py -- vuelve a copiar los dos archivos "
              f"juntos.")
        return False

    existing = find_micropip_files(pyodide_dir)
    broken = [p for p in existing if not is_valid_wheel(p)]
    already_good = [p for p in existing if is_valid_wheel(p)]

    if already_good and not broken:
        print(f"  {pyodide_dir.name}/{already_good[0].name}: ya es un "
              f".whl válido, no toco nada.")
        return True

    # Quita cualquier micropip corrupto que hubiera (el "404 Not Found"
    # de 379 bytes de Flet 0.85.3, u otro resto de una versión previa).
    for p in broken:
        print(f"  {p.name}: no es un .whl válido (probablemente el "
              f"'404 Not Found' que trae Flet 0.85.3 por error) -- "
              f"lo sustituyo.")
        p.unlink()

    dest = pyodide_dir / BUNDLED_WHEEL.name
    dest.write_bytes(BUNDLED_WHEEL.read_bytes())
    sha256 = hashlib.sha256(dest.read_bytes()).hexdigest()
    version = BUNDLED_WHEEL.name.split("-")[1]  # "micropip-0.9.0-py3-..." -> "0.9.0"

    lock = json.loads(lock_path.read_text(encoding="utf-8"))
    entry = lock.get("packages", {}).get("micropip")
    if entry is None:
        print(f"  ERROR: '{lock_path.name}' no tiene una entrada "
              f"'micropip' -- ¿formato distinto en esta versión de "
              f"Flet? Avisa con este mensaje si ves esto.")
        return False

    entry["file_name"] = dest.name
    entry["version"] = version
    entry["sha256"] = sha256
    lock_path.write_text(json.dumps(lock), encoding="utf-8")

    print(f"  {pyodide_dir.name}/{dest.name}: copiado el .whl real "
          f"({dest.stat().st_size:,} bytes) y corregido "
          f"pyodide-lock.json (sha256 actualizado).")
    return True


def fix_missing_packages(dist_dir: Path) -> bool:
    """Para cada paquete "nativo" que Pyodide pueda necesitar (Pillow,
    msgpack, six, o cualquier otro que aparezca en el futuro si cambias
    requirements.txt) y que `flet publish --no-cdn` NO copió a
    `dist/pyodide/` (solo copia micropip y packaging), reescribe su
    entrada en `pyodide-lock.json` para que apunte a la dirección
    completa de jsdelivr en vez de a un nombre de archivo relativo --
    así Pyodide 0.27.7 (que busca todo en un único sitio, sin el
    "plan B" automático que ya trae la versión más nueva que usa Flet
    0.86.5) sabe ir a buscarlo fuera cuando no está en local, en vez de
    pedirle a tu propio dominio un archivo que no existe."""
    pyodide_dir = dist_dir / "pyodide"
    lock_path = pyodide_dir / "pyodide-lock.json"

    if not pyodide_dir.is_dir() or not lock_path.exists():
        # fix_micropip() ya habrá avisado de esto si hace falta.
        return False

    lock = json.loads(lock_path.read_text(encoding="utf-8"))
    version = lock.get("info", {}).get("version")
    if not version:
        print(f"  AVISO: '{lock_path.name}' no trae 'info.version' -- no "
              f"puedo construir la URL de jsdelivr con seguridad, no toco "
              f"los paquetes que falten. Avisa con este mensaje si ves "
              f"esto.")
        return False

    packages = lock.get("packages", {})
    pointed_to_cdn = []
    already_local = []
    already_cdn = []

    for name, entry in packages.items():
        file_name = entry.get("file_name", "")
        if not file_name:
            continue
        if file_name.startswith("http://") or file_name.startswith("https://"):
            already_cdn.append(name)
            continue
        if (pyodide_dir / file_name).exists():
            already_local.append(name)
            continue
        entry["file_name"] = JSDELIVR_TEMPLATE.format(
            version=version, file_name=file_name
        )
        pointed_to_cdn.append(f"{name} ({file_name})")

    if pointed_to_cdn:
        lock_path.write_text(json.dumps(lock), encoding="utf-8")
        # pyodide-lock.json describe TODO el catálogo de paquetes de
        # Pyodide (cientos), no solo los que usa Álbum -- la inmensa
        # mayoría no se llegarán a pedir nunca. Para no inundar la
        # consola, solo se listan por nombre los que sí sabemos que tu
        # app necesita; el resto se resume en un total.
        conocidos = {"pillow", "msgpack", "six"}
        pointed_names = {item.split(" ")[0] for item in pointed_to_cdn}
        destacados = [n for n in pointed_names if n in conocidos]
        print(f"  pyodide-lock.json: {len(pointed_to_cdn)} entradas (de "
              f"{len(packages)} en total en el catálogo de Pyodide) "
              f"apuntadas a jsdelivr por no estar copiadas en local -- "
              f"la inmensa mayoría no las llega a pedir nunca tu app, "
              f"solo se usan si de verdad se importan.")
        if destacados:
            print(f"  De esas, las que Álbum sí usa: "
                  f"{', '.join(sorted(destacados))}.")
        print(f"  (Estas SÍ necesitarán que el navegador llegue a "
              f"jsdelivr.net la primera vez que se usen; el resto -- "
              f"{len(already_local)} paquete(s), incluido micropip -- "
              f"sigue sirviéndose en local, sin depender de ningún CDN.)")
    else:
        print(f"  pyodide-lock.json: no hay paquetes pendientes de "
              f"apuntar a jsdelivr (ya estaban todos en local o ya "
              f"apuntaban fuera de una ejecución anterior de este "
              f"script).")

    return True


def main():
    parser = argparse.ArgumentParser(
        description="Arregla el micropip corrupto que trae Flet 0.85.3 "
                    "al publicar con --no-cdn, y apunta a jsdelivr los "
                    "paquetes nativos (Pillow, msgpack, six...) que "
                    "--no-cdn no copia a dist/pyodide/."
    )
    parser.add_argument("--dist", default="dist",
                         help="Carpeta dist/ generada por 'flet publish "
                              "--no-cdn' (por defecto: dist)")
    args = parser.parse_args()

    dist_dir = Path(args.dist)
    if not dist_dir.is_dir():
        print(f"ERROR: no existe la carpeta '{dist_dir}'. Ejecuta este "
              f"script desde la carpeta de tu proyecto, después de "
              f"'flet publish main.py --no-cdn'.")
        sys.exit(1)

    print(f"Revisando {dist_dir}/pyodide/ ...")
    ok_micropip = fix_micropip(dist_dir)
    ok_packages = fix_missing_packages(dist_dir)
    sys.exit(0 if (ok_micropip and ok_packages) else 1)


if __name__ == "__main__":
    main()
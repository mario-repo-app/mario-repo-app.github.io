"""
Arreglar los iconos (y la versión) tras `flet publish`
========================================

`flet publish` (a diferencia de `flet build web`) NO usa `assets/icon.png`
para generar los iconos de la PWA: deja los iconos genéricos de Flet tal
cual en la carpeta `dist/icons/` y en `dist/favicon.png`. Lo comprobé
leyendo el código de `flet_cli`: la función que rellena `manifest.json`
solo toca el nombre/descripción/colores, nunca los iconos.

Este script sustituye esos iconos por defecto por los tuyos, a partir de
un icono cuadrado (`assets/icon.png`), generando cada tamaño que pide
`manifest.json`.

Iconos "maskable" (v2): los iconos `icon-maskable-*.png` no se generan
igual que los demás. La especificación de manifest de PWA permite que el
sistema operativo recorte estos iconos con su propia forma (círculo,
superelipse...) y solo garantiza visible el 80% central ("zona segura").
Si se les deja el fondo transparente del icono normal, el sistema rellena
esa transparencia con su propio color de repuesto al aplicar la máscara
-en Windows, normalmente blanco- y eso se ve como un borde/orla blanca
alrededor del icono, aunque el PNG tenga el canal alfa "correcto". Por
eso, para los maskable, este script compone el logo (reducido, para que
quede dentro de la zona segura) sobre un fondo sólido opaco -el color de
marca del álbum, `--bg-color`- en vez de dejarlo transparente.

De paso, todos los redimensionados (maskable o no) se hacen premultiplicando
el canal alfa antes de aplicar el filtro de reescalado (Lanczos) y
deshaciendo la premultiplicación después. Sin esto, Pillow interpola los
canales de color y el alfa por separado, y si los píxeles totalmente
transparentes del icono original tienen un RGB "de fondo" claro (blanco es
lo más habitual al exportar desde muchos editores), ese blanco se filtra
hacia los píxeles opacos vecinos al reescalar, dejando un halo blanquecino
en los bordes del logo -sutil, pero visible en tamaños pequeños.

Versionado de iconos en manifest.json (v3): Chrome (y navegadores similares)
solo vuelven a descargar un icono de un PWA ya instalado cuando detectan que
`manifest.json` "cambió" -y ese chequeo se basa en el propio texto del
manifest (URLs, tamaños...), no en si el contenido del PNG referenciado es
distinto byte a byte. Como cada `flet publish` + `fix_icons.py` reescribe
los PNG pero con el mismo nombre de archivo de siempre (`icon-maskable-512.
png`...), Chrome puede seguir dando por bueno el icono que descargó la
primera vez que instalaste la app, aunque el archivo en el servidor ya sea
el correcto -esto explica por ejemplo que, tras aplicar el fondo sólido de
los maskable, el archivo se vea bien al abrirlo directamente pero la app
recién reinstalada lo siga mostrando con bordes blancos. Para evitarlo,
este script añade `?v=<hash>` (un hash corto del contenido del PNG) a la
URL de cada icono dentro de `manifest.json`; así, cada vez que el
contenido cambia de verdad, la URL también cambia, y ningún navegador
puede confundir "mismo nombre" con "mismo contenido".

Sin transparencia real en ningún icono "de sistema" (v4): con una imagen de
origen real se vio que, incluso ya con fondo sólido en los maskable, el
icono del escritorio en Windows seguía saliendo con las esquinas blancas.
La causa que se manejó en ese momento: Chrome usa el icono normal
(`icon-512.png`/`icon-192.png`), no el maskable, para generar el `.ico` del
acceso directo de escritorio -y ese icono normal sí seguía teniendo
transparencia real en las esquinas (aunque "limpia"), que Chrome aplanaría
sobre blanco al convertir a `.ico`. Arreglo de entonces: todos los iconos
"de sistema" (normal, maskable y apple-touch-icon) compuestos sobre fondo
sólido opaco, sin dejar ni un píxel transparente.

Vuelta atrás parcial, con las esquinas redondeadas del icono normal (v5):
tras seguir viendo esquinas blancas incluso con la v4, se probó a instalar
en un perfil de Chrome totalmente nuevo (sin ningún residuo de las muchas
rondas de prueba anteriores) -y ahí el icono ya salió bien, con fondo
sólido en vez de blanco. Eso reveló que buena parte (quizás toda) de las
esquinas blancas que se seguían viendo eran restos acumulados en el perfil
de pruebas, no un fallo real del icono normal con transparencia. Con eso
sobre la mesa, y para recuperar el aspecto redondeado que sí se ve en
Android (donde el sistema aplica su propia máscara sobre el icono
maskable), `icon-192.png`/`icon-512.png` vuelven a generarse con
transparencia real -en vez de fondo sólido-, pero esta vez limpiando a
fondo el origen: cualquier píxel con alfa por debajo de un umbral
(`ALPHA_LIMPIEZA`) se fuerza a (0,0,0,0) del todo, en vez de solo atenuarlo
con la premultiplicación del apartado anterior. Es la manera de curarse en
salud frente al ruido de color que puede llevar el `assets/icon.png` de
origen (ver más abajo) sin perder la forma redondeada. El maskable y el
apple-touch-icon SIGUEN con fondo sólido -es lo correcto para ambos por
diseño de sus respectivas plataformas, no una solución de compromiso.

Campo "version" en manifest.json (v6): igual que con los iconos, comprobé
leyendo `flet_cli`/`flet_web` que `flet publish` NUNCA escribe un campo
"version" en `manifest.json` -ni hay ninguna opción de línea de comandos
ni de `pyproject.toml` para ello (eso solo existe para `flet build`, que
sigue un camino totalmente distinto, vía Flutter/pubspec.yaml, y no es lo
que usa este proyecto). El propio manifest.json de fábrica de Flet no trae
ese campo. "version" SÍ es un campo estándar del manifest de aplicación
web (no todos los navegadores lo usan igual, pero Windows con Edge/Chrome
lo lee para mostrar la versión de una PWA instalada, por ejemplo al
desinstalarla desde Configuración > Aplicaciones) -por eso, sin este
script, quedaba vacío y el sistema mostraba algún valor de repuesto ("1.0")
en vez de la versión real de la app. Este script añade/actualiza ese campo
leyéndolo automáticamente de `VERSION = '...'` en `main.py`, para no tener
que mantenerlo por duplicado en dos sitios -si alguna vez se quiere fijar
a mano (o `main.py` no está en la ruta por defecto), se puede pasar con
`--version`/`--main`.

Campo "orientation" en manifest.json (v7): investigando por qué la app no
gira de vertical a horizontal en Android (aunque sí lo hace en iOS con el
mismo `main.py`), leyendo `flet_web/web/manifest.json` -la plantilla que
copia `flet publish` antes de generar la app- encontré que trae de fábrica
"orientation": "natural". Ese campo, cuando la PWA está instalada
(display: standalone), bloquea la orientación al valor natural del
dispositivo -en un móvil, vertical- e impide rotar a horizontal. Revisando
`flet_web/patch_index.py` confirmé que `patch_manifest_json()` (la función
que `flet publish` usa para tocar el manifest.json) nunca toca ni
"orientation" ni "version": solo escribe name/short_name/description/
background_color/theme_color. Chrome/Android hace cumplir ese bloqueo de
forma estricta en una PWA instalada; Safari/iOS es históricamente mucho
más laxo con el manifest y en la práctica lo ignora -de ahí que el mismo
main.py y el mismo manifest.json solo den problema en Android. Este script
cambia "orientation" a "any" (sin restricción) para que la app y el visor
de imágenes puedan rotar libremente en cualquier plataforma; no hace falta
ninguna opción nueva porque no hay ambigüedad que resolver (a diferencia
del icono o la versión, aquí el valor correcto es siempre el mismo).

Uso (después de `flet publish`, con la carpeta `dist/` ya generada):

    pip install pillow          # si no lo tienes ya
    python fix_icons.py

Por defecto asume `assets/icon.png` como origen, `dist/` como destino y
`main.py` (junto a este script) para leer la versión; si usas otras rutas,
o quieres cambiar el color de fondo de los iconos maskable (por defecto,
el índigo 800 del tema de la app), o fijar la versión a mano:

    python fix_icons.py --icon "ruta\\a\\tu\\icono.png" --dist "ruta\\a\\dist" --bg-color 283593 --version 2.1
"""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    print("Este script necesita Pillow: pip install pillow")
    sys.exit(1)

# (ruta relativa dentro de dist/, tamaño en píxeles, fracción del lienzo que
# ocupa el logo -None significa "deja transparencia real y forma redondeada,
# no compongas sobre fondo sólido"-)
ICON_TARGETS = [
    ("icons/icon-192.png", 192, None),
    ("icons/icon-512.png", 512, None),
    ("icons/icon-maskable-192.png", 192, 0.70),
    ("icons/icon-maskable-512.png", 512, 0.70),
    ("icons/apple-touch-icon-192.png", 192, 0.94),
    ("favicon.png", 32, None),
]

# Color de fondo por defecto para los iconos con fondo sólido (maskable y
# apple-touch-icon): el índigo 800 que usa la app (PRIMARY =
# ft.Colors.INDIGO_800 en main_pwa_v1.py).
DEFAULT_BG_COLOR = "283593"

# Cualquier píxel con un alfa igual o por debajo de este umbral se limpia a
# (0,0,0,0) del todo -ver "Vuelta atrás parcial..." al principio del
# archivo-. 16 sobre 255 (~6% de opacidad) es generoso: sin esto, un
# `assets/icon.png` con ruido de color en su zona "transparente" (frecuente
# en imágenes con el fondo quitado por IA) puede dejar un resto visible en
# los iconos con transparencia real, aunque la premultiplicación ya reduzca
# mucho ese ruido al reescalar.
ALPHA_LIMPIEZA = 16

# Fracción del lienzo que ocupa el logo en un icono maskable. La
# especificación garantiza visible el 80% central; se usa algo menos (70%)
# para dejar un margen de seguridad frente a máscaras más agresivas
# (algunos launchers recortan más que el mínimo de la especificación). Los
# iconos con fondo sólido que no son maskable (apple-touch-icon) usan una
# fracción bastante más alta (ver ICON_TARGETS), casi a sangre, porque no
# van a sufrir ningún recorte por máscara.


def limpiar_ruido_alfa(im: "Image.Image", umbral: int = ALPHA_LIMPIEZA) -> "Image.Image":
    """Fuerza a (0,0,0,0) cualquier píxel con alfa <= `umbral`, eliminando
    del todo el ruido de color que pueda quedar en la zona "transparente"
    del icono de origen -en vez de solo atenuarlo, como hace la
    premultiplicación por sí sola-."""
    im = im.convert("RGBA")
    out = Image.new("RGBA", im.size)
    out.putdata([(0, 0, 0, 0) if a <= umbral else (r, g, b, a) for r, g, b, a in im.getdata()])
    return out


def _premultiply(im: "Image.Image") -> "Image.Image":
    """Multiplica RGB por el alfa (0-255) para evitar halos de color al reescalar."""
    im = im.convert("RGBA")
    out = Image.new("RGBA", im.size)
    out.putdata([(r * a // 255, g * a // 255, b * a // 255, a) for r, g, b, a in im.getdata()])
    return out


def _unpremultiply(im: "Image.Image") -> "Image.Image":
    """Deshace `_premultiply` tras el reescalado."""
    out = Image.new("RGBA", im.size)
    pixels = []
    for r, g, b, a in im.getdata():
        if a == 0:
            pixels.append((0, 0, 0, 0))
        else:
            pixels.append((min(255, r * 255 // a), min(255, g * 255 // a), min(255, b * 255 // a), a))
    out.putdata(pixels)
    return out


def resize_sin_halo(im: "Image.Image", size: int) -> "Image.Image":
    """Reescala una imagen RGBA a (size, size) sin dejar halo de color en los bordes."""
    return _unpremultiply(_premultiply(im).resize((size, size), Image.LANCZOS))


def hex_a_rgb(hex_color: str):
    hex_color = hex_color.strip().lstrip("#")
    if len(hex_color) != 6:
        print(f"Color de fondo inválido: {hex_color!r}. Usa un hex de 6 dígitos, ej. 283593.")
        sys.exit(1)
    return tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))


def make_opaque(im: "Image.Image", size: int, bg_rgb, fill_fraction: float) -> "Image.Image":
    """Compone el logo, reducido a `fill_fraction` del lienzo, sobre un fondo sólido
    opaco -sin dejar ni un píxel transparente en el resultado final-.

    Usa `Image.alpha_composite` (composición "over" correcta) en vez de
    `Image.paste(..., mask=...)`: paste con máscara mezcla el canal alfa con
    la misma fórmula que los de color, así que un píxel del logo a medio
    camino (borde antialiaseado, alfa≈128) deja el resultado en alfa≈191 en
    vez de 255 -casi opaco, pero no del todo-. `alpha_composite` sí
    garantiza opacidad total en cada píxel cuando el fondo ya lo es.
    """
    canvas = Image.new("RGBA", (size, size), bg_rgb + (255,))
    logo_size = max(1, int(size * fill_fraction))
    logo = resize_sin_halo(im, logo_size)
    offset = ((size - logo_size) // 2, (size - logo_size) // 2)
    logo_layer = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    logo_layer.paste(logo, offset)  # sin máscara: coloca el logo tal cual, con su propio alfa
    return Image.alpha_composite(canvas, logo_layer)


def leer_version(main_path: Path) -> "str | None":
    """Extrae el valor de `VERSION = '...'` de main.py, sin importarlo (no
    hace falta ejecutar la app para saber su versión, y main.py tiene
    dependencias -flet, etc.- que igual ni están instaladas aquí)."""
    if not main_path.exists():
        return None
    texto = main_path.read_text(encoding="utf-8")
    m = re.search(r"""^VERSION\s*=\s*['"]([^'"]+)['"]""", texto, re.MULTILINE)
    return m.group(1) if m else None


def fix_icons(icon_path: Path, dist_dir: Path, bg_rgb, main_path: Path, version_override: "str | None"):
    if not icon_path.exists():
        print(f"No encuentro {icon_path}. Pásame la ruta correcta con --icon.")
        sys.exit(1)
    if not dist_dir.exists():
        print(f"No encuentro la carpeta {dist_dir}. Ejecuta antes `flet publish` "
              f"o pásame la ruta correcta con --dist.")
        sys.exit(1)

    file_hashes = {}  # rel_path (con "/") -> hash corto del contenido ya escrito

    with Image.open(icon_path) as im:
        if im.width != im.height:
            print(f"Aviso: {icon_path} no es cuadrado ({im.width}x{im.height}); "
                  f"los iconos pueden verse deformados. Lo ideal es una imagen cuadrada.")
        im = limpiar_ruido_alfa(im)

        for rel_path, size, fill_fraction in ICON_TARGETS:
            target = dist_dir / rel_path
            if not target.parent.exists():
                print(f"Aviso: no existe la carpeta {target.parent}, me la salto.")
                continue
            if fill_fraction is None:
                resized = resize_sin_halo(im, size)
                etiqueta = " (con transparencia)"
            else:
                resized = make_opaque(im, size, bg_rgb, fill_fraction)
                etiqueta = f" (fondo sólido, logo al {int(fill_fraction * 100)}%)"
            resized.save(target, "PNG")
            file_hashes[rel_path] = hashlib.sha1(target.read_bytes()).hexdigest()[:10]
            print(f"  Escrito {target} ({size}x{size}){etiqueta}")

    manifest_path = dist_dir / "manifest.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        cambiado = False

        # Detalle cosmético: el manifest.json trae de fábrica una descripción
        # genérica de Flet ("Flet - the fastest way to build Flutter apps in
        # Python"); la cambiamos por algo propio del álbum si sigue así.
        if "Flet" in (manifest.get("description") or ""):
            manifest["description"] = "Álbum de fotos familiar"
            cambiado = True

        # Versionado: añade "?v=<hash>" a cada icono del manifest cuyo
        # contenido acabamos de regenerar, para forzar a los navegadores a
        # detectar el cambio (ver nota "Versionado de iconos" al principio).
        for entry in manifest.get("icons", []):
            src = entry.get("src", "")
            base = src.split("?", 1)[0]
            file_hash = file_hashes.get(base)
            if file_hash is None:
                continue
            new_src = f"{base}?v={file_hash}"
            if entry.get("src") != new_src:
                entry["src"] = new_src
                cambiado = True

        # Campo "version" (v6): flet publish nunca lo escribe -ver el
        # docstring-. Se toma de --version si se indicó; si no, se lee
        # automáticamente de VERSION en main.py.
        version = version_override or leer_version(main_path)
        if version:
            if manifest.get("version") != version:
                manifest["version"] = version
                cambiado = True
            print(f"  Versión: {version}"
                  + (" (de --version)" if version_override else f" (leída de {main_path})"))
        else:
            print(f"Aviso: no he podido determinar la versión (ni --version ni "
                  f"VERSION en {main_path}); dejo manifest.json sin ese campo.")

        # Campo "orientation" (v7): el manifest.json de fábrica de Flet trae
        # "orientation": "natural", que BLOQUEA la PWA instalada a la
        # orientación natural del dispositivo -en un móvil, vertical- sin
        # dejar rotar a horizontal. Chrome/Android sí hace cumplir ese
        # bloqueo en una PWA instalada (display: standalone); Safari/iOS es
        # bastante más laxo con el manifest y, en la práctica, lo ignora -de
        # ahí que solo se note en Android, nunca en iOS, con el mismo
        # main.py y el mismo manifest.json. Se cambia a "any" (sin
        # restricción) para que gire libremente en cualquier plataforma; la
        # propia app ya adapta su layout al ancho real (ver ORDER_BY /
        # _CARD_W / _dialog_width en main.py), así que no hay motivo para
        # bloquear la orientación.
        if manifest.get("orientation") != "any":
            manifest["orientation"] = "any"
            cambiado = True
        print(f"  Orientación: any (sin bloqueo)")

        if cambiado:
            manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
            print(f"  Actualizado {manifest_path} (descripción, versión de iconos, versión de la app y/o orientación)")
        else:
            print(f"  {manifest_path}: sin cambios necesarios")
    else:
        print(f"Aviso: no encuentro {manifest_path}, no he podido versionar los iconos ni la versión ahí.")

    print("\nListo. Vuelve a subir el contenido de dist/ a GitHub (los archivos de "
          "icons/, favicon.png y manifest.json habrán cambiado).")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--icon", type=Path, default=Path("assets/icon.png"),
                         help="Icono cuadrado de origen (por defecto: assets/icon.png)")
    parser.add_argument("--dist", type=Path, default=Path("dist"),
                         help="Carpeta generada por flet publish (por defecto: dist)")
    parser.add_argument("--bg-color", type=str, default=DEFAULT_BG_COLOR,
                         help=f"Color de fondo (hex, sin #) para los iconos maskable "
                              f"(por defecto: {DEFAULT_BG_COLOR}, el índigo del tema de la app)")
    parser.add_argument("--main", type=Path, default=Path("main.py"),
                         help="Ruta a main.py, para leer VERSION automáticamente (por defecto: main.py)")
    parser.add_argument("--version", type=str, default=None,
                         help="Fija la versión a mano en vez de leerla de VERSION en main.py")
    args = parser.parse_args()
    fix_icons(args.icon, args.dist, hex_a_rgb(args.bg_color), args.main, args.version)
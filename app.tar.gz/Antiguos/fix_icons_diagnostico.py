"""
VERSIÓN DE DIAGNÓSTICO -- NO ES LA VERSIÓN DEFINITIVA
========================================================
Genera cada icono candidato con un color de esquina distinto y muy
llamativo, para identificar sin ninguna duda cuál usa Windows/Chrome de
verdad para el acceso directo del escritorio:

  - icon-192.png / icon-512.png ("any")........... esquinas ROJAS
  - icon-maskable-192.png / -512.png (maskable).... esquinas VERDES
  - apple-touch-icon-192.png....................... esquinas AMARILLAS

Instala la app con este dist/ en el MISMO perfil nuevo de Chrome donde ya
confirmó que el icono sale limpio (sin residuos de las pruebas
anteriores), y mira de qué color salen las esquinas del icono del
escritorio. Con eso sabremos con certeza cuál arreglar de verdad.
"""
import json
import sys
from pathlib import Path
from PIL import Image

ICON_TARGETS = [
    ("icons/icon-192.png", 192, (220, 30, 30)),      # rojo = "any"
    ("icons/icon-512.png", 512, (220, 30, 30)),
    ("icons/icon-maskable-192.png", 192, (30, 160, 60)),   # verde = maskable
    ("icons/icon-maskable-512.png", 512, (30, 160, 60)),
    ("icons/apple-touch-icon-192.png", 192, (230, 190, 20)),  # amarillo = apple-touch
]


def _premultiply(im):
    im = im.convert("RGBA")
    out = Image.new("RGBA", im.size)
    out.putdata([(r * a // 255, g * a // 255, b * a // 255, a) for r, g, b, a in im.getdata()])
    return out


def _unpremultiply(im):
    out = Image.new("RGBA", im.size)
    pixels = []
    for r, g, b, a in im.getdata():
        if a == 0:
            pixels.append((0, 0, 0, 0))
        else:
            pixels.append((min(255, r * 255 // a), min(255, g * 255 // a), min(255, b * 255 // a), a))
    out.putdata(pixels)
    return out


def resize_sin_halo(im, size):
    return _unpremultiply(_premultiply(im).resize((size, size), Image.LANCZOS))


def limpiar_ruido_alfa(im, umbral=16):
    im = im.convert("RGBA")
    out = Image.new("RGBA", im.size)
    out.putdata([(0, 0, 0, 0) if a <= umbral else (r, g, b, a) for r, g, b, a in im.getdata()])
    return out


def make_opaque(im, size, bg_rgb, fill_fraction=0.94):
    canvas = Image.new("RGBA", (size, size), bg_rgb + (255,))
    logo_size = max(1, int(size * fill_fraction))
    logo = resize_sin_halo(im, logo_size)
    offset = ((size - logo_size) // 2, (size - logo_size) // 2)
    logo_layer = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    logo_layer.paste(logo, offset)
    return Image.alpha_composite(canvas, logo_layer)


def main():
    icon_path = Path(sys.argv[sys.argv.index("--icon") + 1]) if "--icon" in sys.argv else Path("assets/icon.png")
    dist_dir = Path(sys.argv[sys.argv.index("--dist") + 1]) if "--dist" in sys.argv else Path("dist")

    with Image.open(icon_path) as im:
        im = limpiar_ruido_alfa(im)
        for rel_path, size, color in ICON_TARGETS:
            target = dist_dir / rel_path
            resized = make_opaque(im, size, color, fill_fraction=0.70 if "maskable" in rel_path else 0.94)
            resized.save(target, "PNG")
            print(f"  Escrito {target} ({size}x{size}) esquinas color {color}")

    manifest_path = dist_dir / "manifest.json"
    if manifest_path.exists():
        import hashlib
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for entry in manifest.get("icons", []):
            src = entry.get("src", "")
            base = src.split("?", 1)[0]
            target = dist_dir / base
            if target.exists():
                h = hashlib.sha1(target.read_bytes()).hexdigest()[:10]
                entry["src"] = f"{base}?diag={h}"
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        print(f"  Actualizado {manifest_path}")


if __name__ == "__main__":
    main()
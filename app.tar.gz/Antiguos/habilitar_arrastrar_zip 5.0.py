"""
Habilitar "elegir carpeta"/"arrastrar y soltar" el ZIP — la única forma de
importar en esta app, tras quitar el selector nativo de Flet
====================================================================

VERSIÓN 5.0

El selector de archivos normal de Flet ("Importar ZIP", ya eliminado de
`main.py`) nunca consiguió abrir el diálogo nativo de "elegir archivo" en
Safari/iPadOS. No era un fallo de `main.py`: es un fallo conocido y
documentado del propio framework Flet, sin arreglo todavía (reproducido
incluso en la demo oficial de Flet, ver el LEEME.md para los enlaces).
Ocurre porque, en el build web de Flet, Python corre dentro de un Web
Worker separado del hilo principal del navegador — abrir el selector
nativo requiere ir y volver entre ese Worker y el hilo principal por
mensajes, y Safari exige que ese diálogo se abra como reacción directa e
inmediata al toque del usuario, sin ningún salto de por medio. Ese salto
es inevitable con la arquitectura actual de Flet, así que no había ningún
cambio posible en `main.py` que lo arreglase — por eso, confirmado que las
vías de este script (carpeta y arrastrar-y-soltar) funcionan de forma
fiable en los tres tipos de dispositivo de la familia, se quitó el botón
"Importar ZIP" y todo el `FilePicker` de importación que lo respaldaba en
`main.py`: ya no hace falta mantener dos caminos.

"Arrastrar y soltar" no tiene este problema: cuando sueltas uno o varios
archivos sobre una página, el navegador te los da directamente, sin pasar
por ningún diálogo del sistema — así que esta vía no depende en absoluto
del selector que falla. Y esto no es solo para iPad: en Windows/Mac
también puedes seleccionar varios .zip a la vez en el Explorador/Finder
(clic + Ctrl o Mayús) y arrastrarlos juntos hasta la pestaña del
navegador donde tengas la PWA abierta — es exactamente el mismo mecanismo
del navegador (HTML5 drag & drop), nada específico de iPad. Es, de hecho,
una forma de importar varias partes SIN tener que confirmar cada una por
separado: reabrir un selector solo, sin más clics, no es posible porque
los navegadores exigen un gesto real del usuario para cada apertura.
Soltar varios archivos SÍ es un único gesto real que cubre los seis de una vez,
así que aquí no hace falta ningún diálogo intermedio: se procesan todos
solos, uno detrás de otro. Además, desde iPadOS 11 la app Archivos
permite seleccionar VARIOS archivos a la vez (tocando y manteniendo uno,
luego tocando los demás con otro dedo) y arrastrarlos todos juntos en un
mismo gesto — así que este script recoge TODOS los .zip soltados de golpe
(por ejemplo, las partes que genera
`exportar_zip_familia.py --max-zip-mb`).

NUEVO — botón "Elegir carpeta con las partes ZIP": probado antes en una
página de diagnóstico aislada, `webkitdirectory` (el atributo que deja
elegir una carpeta ENTERA de golpe, en vez de marcar archivo por archivo)
tiene fama de no funcionar en ningún navegador móvil -- así lo documenta
un hilo abierto en el repositorio de compatibilidad de MDN
(github.com/mdn/browser-compat-data, issue #24357), donde una corrección
que lo daba por soportado en Chrome Android se revirtió tras comprobar
que, en un móvil real, "no había forma de elegir una carpeta para subir".
Pero se comprobó de verdad en el Huawei P30 Pro (EMUI 12) real de Mario
-- pidió permiso de acceso la primera vez (normal, es Android protegiendo
el almacenamiento), y tras concederlo SÍ dejó elegir la carpeta entera y
leer todos sus archivos. Es decir: la fama de "no soportado en móvil" no
se cumple, al menos, en este dispositivo. Comparte con arrastrar-y-soltar
la misma función `procesarZips()`: filtra a solo .zip, ordena por número
de parte, y los manda al worker de Python SIN LEER, que es quien los
procesa de uno en uno.

(Hubo también un botón "Elegir varias partes a la vez", con un
<input type="file" multiple> normal como red de seguridad para cuando el
selector de carpeta no estuviera disponible -- se quitó una vez
confirmado que el selector de carpeta funciona bien en el dispositivo
real de la familia, para no duplicar botones sin necesidad.)

NUEVO (2) — el botón de carpeta solo se ve en la pestaña Ajustes, anclado
ABAJO, con el aspecto de un `ElevatedButton` normal de Flet: al principio
el botón quedaba fijo en pantalla en TODAS las pestañas de la app, lo
cual estorbaba en la Galería (arreglado mostrándolo solo en Ajustes). En
una segunda vuelta, ya solo en Ajustes, se probó anclarlo justo debajo de
la barra superior (con un hueco fijo calculado a ojo para no tapar el
AppBar) -- pero en algunos móviles ese hueco se quedaba corto y la barra
tapaba la etiqueta "Estadísticas". Se ancló entonces ABAJO en vez de
arriba: `env(safe-area-inset-bottom)` (el hueco de la barra de
gestos/home) es un valor estándar y fiable en cualquier dispositivo, a
diferencia de intentar adivinar cuánto mide el AppBar que dibuja Flet (que
varía con el notch/cámara en agujero de cada móvil y no se puede leer
desde este HTML aparte) -- así se evita el problema de raíz, y de paso la
barra cae, en la mayoría de pantallas, cerca de donde estaba el antiguo
botón "Importar ZIP" (justo encima del texto de copyright, debajo de
"Descargar manual"). Como Flet dibuja toda la interfaz en un único
<canvas> con CanvasKit (no hay un nodo del DOM por cada control), este
botón HTML -- que vive FUERA del árbol de Flet -- sigue sin poder
"meterse dentro" de `settings_page` como si fuera un control más, así
que sigue siendo una barra superpuesta, no insertada de verdad en la
columna. Se le dio también el aspecto por defecto de Material 3 que ya
usan los `ElevatedButton` de la app SIN estilo propio (como "Descargar
manual"): fondo claro (`#EEF0F7`, no un azul sólido de marca), texto e
icono en el `PRIMARY` de la cabecera (`#283593`), esquinas muy
redondeadas, sombra sutil -- para que no se note el salto entre un
control HTML y uno de Flet. Para saber qué pestaña está activa, `main.py`
(concretamente `_notificar_pagina_activa()`, llamada desde
`_select_nav()`) manda un mensaje por `postMessage` DESDE el Worker de
Python HACIA el hilo principal -- la dirección contraria a la ya usada
por `recibir_zip_arrastrado()` -- que `python.js` (parcheado más abajo)
reenvía como un evento `album-page-change` de JavaScript normal, que el
HTML inyectado escucha para mostrar/ocultar la barra. Es solo un aviso de
estado: no abre ningún diálogo ni depende de gesto de usuario, así que no
choca con la restricción de "gesto directo" explicada abajo -- esa
restricción solo afecta al MOMENTO EN QUE SE ABRE el selector (el click
del botón sigue siendo un listener nativo, sin pasar por Python).

NUEVO (3) — arrastrar y soltar la CARPETA contenedora de los ZIP (no solo
los .zip sueltos), para equiparar "soltar" con el botón "Elegir carpeta"
EN WINDOWS (confirmado que en Android e iPad este gesto de carpeta no
está disponible -- ahí se sigue arrastrando los .zip sueltos, ver el
aviso "CONFIRMADO en dispositivos reales" más abajo):
el listener de `drop` original leía directamente `e.dataTransfer.files`,
que es la lista "plana" de archivos soltados -- si sueltas una carpeta
ahí dentro, el navegador NO baja a mirar qué hay dentro, así que
`procesarZips()` no encontraba ningún .zip (o, según navegador, ni
siquiera aparecía la carpeta en la lista). Para que soltar la carpeta
funcione igual que elegirla con el botón hace falta la otra API de
arrastrar-y-soltar de HTML5: `e.dataTransfer.items` +
`item.webkitGetAsEntry()`, que (a pesar del prefijo "webkit") está
soportada en Chrome, Edge, Firefox y Safari de escritorio desde hace
años -- es la misma API que usan librerías conocidas de subida de
carpetas por arrastre (p. ej. Dropzone.js). Cada entrada puede ser un
`FileSystemFileEntry` (un archivo) o un `FileSystemDirectoryEntry` (una
carpeta); para una carpeta hace falta pedir un "lector"
(`createReader()`) y llamar a `readEntries()` -- posiblemente varias
veces, porque la propia especificación permite que cada llamada devuelva
como mucho un lote (100 en Chrome) y hay que seguir pidiendo hasta que
llegue un lote vacío -- y esto se repite de forma recursiva por cada
subcarpeta que aparezca, igual que hace `webkitdirectory` con el botón,
que también baja a subcarpetas. El resultado final (una lista de objetos
`File`, vengan de una carpeta, de varias, o de archivos sueltos
mezclados) se pasa exactamente a la misma `procesarZips()` de siempre, sin
tocarla: sigue filtrando a solo .zip, ordenando por número de parte y
mandando la lista SIN LEER al worker, que la procesa de uno en uno (ver
más abajo). Si el navegador NO tiene `dataTransfer.items` o
`webkitGetAsEntry` (algún navegador antiguo), se cae automáticamente al
comportamiento de siempre -- tratar `dataTransfer.files` tal cual, que
solo trae archivos sueltos --, así que esto es puramente aditivo: soltar
.zip individuales sigue funcionando exactamente igual que antes.

CONFIRMADO en dispositivos reales de la familia (Mario, tras probarlo):
arrastrar la CARPETA ENTERA como una unidad -- el gesto que añade esta
sección -- solo está disponible en Windows (arrastrando la carpeta desde
el Explorador hasta la pestaña del navegador; mecanismo estándar,
`dataTransfer.items` + `webkitGetAsEntry()`, igual que se comprobó en el
Chromium de este entorno). En Android y en iPad, el sistema NO deja
arrastrar el icono de una carpeta como unidad hacia el navegador -- ahí
hay que seguir arrastrando los .zip SUELTOS (uno o varios a la vez, con
multi-touch en el caso de iPadOS -- ver más arriba), que es justo el
camino que ya funcionaba ANTES de este cambio y que sigue funcionando
exactamente igual: `extraerArchivosDeDrop()` cae automáticamente al
comportamiento de siempre en cuanto no hay una carpeta de por medio, así
que no hace falta ningún ajuste distinto según el dispositivo, el usuario
simplemente usa el gesto que su sistema permite. En Android e iPad, para
importar sin ir soltando archivo a archivo, la vía pensada para eso sigue
siendo el botón "Elegir carpeta con las partes ZIP" (confirmado por
separado en el Huawei P30 Pro y en el iPad, ver el aviso de más abajo):
arrastrar la carpeta soltándola es, en la práctica, una mejora que solo
aplica a Windows, no un reemplazo del botón en el resto de dispositivos.

IMPORTANTE — por qué se procesan de UNO EN UNO y no todos a la vez: una
primera versión de este script leía en memoria TODOS los .zip soltados
antes de mandárselos a Python, y en un iPad real eso agotaba la memoria
de la pestaña ("Out of Memory") en cuanto se soltaban varias partes
juntas — con partes de ~60 MB cada una, seis de golpe son ~360 MB solo de
datos, antes de contar la sobrecarga de copiarlos entre JavaScript y
Python. Es exactamente el problema que `exportar_zip_familia.py
--max-zip-mb` reparte en partes pequeñas para evitar, pero solo si esas
partes se procesan de una en una. Por eso ahora el propio worker de
Python (`python-worker.js`) lee y procesa los archivos soltados (o
elegidos con el botón nuevo) EN UN BUCLE SECUENCIAL: lee los bytes de
uno, espera (`await`) a que Python termine de importarlo del todo
(incluida la escritura a IndexedDB), y solo entonces lee el siguiente —
nunca hay más de un ZIP entero en memoria a la vez. Esto no cambia con
el botón nuevo ni con soltar una carpeta entera: las tres vías acaban
mandando la misma lista de archivos SIN LEER al worker, que es quien de
verdad los procesa uno a uno (ver `procesarZips()` en el HTML inyectado).
Recorrer una carpeta con `webkitGetAsEntry`/`readEntries()` tampoco lee
los ZIP: solo lista nombres y construye referencias `File` sin tocar su
contenido, así que no añade ninguna presión de memoria nueva antes de
llegar a ese bucle secuencial.

Este script añade esa vía alternativa parcheando 3 archivos que genera
`flet publish` en `dist/`:

- `python.js` — expone el "worker" donde corre Python (`window.__fletPyWorker`)
  para que el script de abajo pueda enviarle mensajes, Y añade un listener
  en sentido contrario (worker → hilo principal): cuando `main.py` avisa
  por `postMessage` qué pestaña está activa (`_notificar_pagina_activa()`),
  lo reenvía como un evento `album-page-change` de JavaScript normal, que
  el HTML inyectado escucha para mostrar/ocultar el botón de carpeta.
- `python-worker.js` — reconoce un tipo de mensaje nuevo ("aquí tienes uno
  o varios ZIP arrastrados o elegidos", como referencias a archivo SIN LEER)
  y, por cada uno, en orden, lee sus bytes y llama a la función de Python
  `recibir_zip_arrastrado` (definida en `main.py`), esperando a que
  termine antes de pasar al siguiente.
- `index.html` — añade el propio detector de "arrastrar y soltar" (que
  ahora también recorre carpetas soltadas, no solo archivos sueltos — ver
  "NUEVO (3)" arriba) y el botón de "elegir carpeta con las partes ZIP"
  (visible solo en Ajustes): en ambos casos, se queda solo con los
  archivos que terminan en .zip, los ordena por nombre (primero el que
  sigue la convención "..._parte1_de_N..." de exportar_zip_familia.py,
  que es el que trae Fotos.db) y se los pasa AL WORKER SIN LEERLOS —eso
  lo hace el worker, uno a uno, ver arriba—. Incluye un aviso visual
  (fondo azul con el texto "Suelta aquí...") que aparece mientras
  arrastras archivos (o carpetas) sobre la página, para que sea evidente
  que la zona de soltar está activa.

Como `flet publish` regenera `dist/` entero cada vez, hay que volver a
ejecutar este script (igual que `fix_icons.py`) después de cada
`flet publish`:

    python habilitar_arrastrar_zip.py
    python fix_icons.py

(el orden entre los dos no importa, cada uno toca archivos distintos).

Por defecto asume que `dist/` está en la carpeta actual; si usas otra
ruta:

    python habilitar_arrastrar_zip.py --dist "ruta\\a\\dist"

Nota importante: la mayor parte de esto SOLO he podido probarlo con
Chromium en este entorno (arrastrar y soltar SÍ funciona igual ahí, y lo
comprobé de principio a fin: se sueltan varios ZIP a la vez, se importan
uno detrás de otro, la Galería se actualiza con todos; y también soltando
una carpeta entera, ver "NUEVO (3)"). El MECANISMO del botón de "elegir
carpeta" -- que se abra el selector nativo y que la carpeta elegida se
importe -- es la pieza de este script confirmada en dispositivos reales
por el usuario: funciona en su Huawei P30 Pro (EMUI 12, pide permiso de
acceso la primera vez, normal) y, además, en su iPad -- donde de paso
permite abrir un pendrive completo y cargar los ZIP directamente, algo
que no era posible en versiones anteriores de esta app (solo
arrastrar-y-soltar). Ese mecanismo no cambia con este ajuste de hoy
(mismo `<input webkitdirectory>`, mismo listener de clic, misma
`procesarZips()`) -- lo que SÍ es nuevo hoy y no se ha confirmado todavía
en un dispositivo real es la posición del botón (anclada abajo en vez de
arriba) y el aspecto (fondo claro tipo `ElevatedButton` en vez de píldora
azul sólida), pensados para no tapar "Estadísticas" y para igualar el
aspecto de "Descargar manual". Sobre soltar una carpeta ENTERA (ver
"NUEVO (3)"): CONFIRMADO por el usuario en dispositivos reales de la
familia que este gesto solo está disponible en Windows -- en Android y en
iPad el sistema no deja arrastrar una carpeta como unidad hacia el
navegador, así que ahí se sigue arrastrando los .zip sueltos (como ya
funcionaba antes de este cambio) o usando el botón "Elegir carpeta". Lo
que sigue sin poder comprobarse desde este entorno es si el botón de
"elegir carpeta" funciona igual en otros dispositivos de la familia
(iPhone, otros Android) — son mecanismos estándar del navegador (HTML5
drag & drop, <input type="file" webkitdirectory>), pero la confirmación
real en cada dispositivo solo la puede hacer quien lo tenga en la mano.
"""
import argparse
import sys
from pathlib import Path

MARKER = "[Album-dnd]"


def patch_python_js(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    if MARKER in text:
        print(f"  {path.name}: ya estaba parcheado, no toco nada")
        return True

    anchor = (
        '    app.worker = new Worker(\n'
        '        (flet.entrypointBaseUrl.endsWith("/") ?\n'
        '            flet.entrypointBaseUrl.slice(0, -1) : flet.entrypointBaseUrl) + "/python-worker.js",\n'
        '        { type: "module" });\n'
    )
    if anchor not in text:
        print(f"  ERROR: no encontré el punto esperado en {path.name} — "
              f"¿esta versión de Flet genera un python.js distinto? "
              f"Aviso a Claude con el mensaje de error si ves esto.")
        return False

    injected = anchor + (
        f'    // {MARKER} Expone el worker de Python para que el detector de\n'
        f'    // "arrastrar y soltar" y el botón "elegir carpeta"\n'
        f'    // (inyectados en index.html) puedan mandarle directamente los\n'
        f'    // bytes de los ZIP soltados/elegidos sobre la página — atajo\n'
        f'    // para iPad, donde el selector de archivos no abre el diálogo\n'
        f'    // nativo de iOS (ver habilitar_arrastrar_zip.py).\n'
        f'    window.__fletPyWorker = app.worker;\n'
        f'    // {MARKER} Dirección contraria: mensajes del worker (Python)\n'
        f'    // hacia el hilo principal. Se usa para que main.py avise, con\n'
        f'    // _notificar_pagina_activa(), qué pestaña está activa ahora\n'
        f'    // ("galeria" o "ajustes") — el botón "elegir carpeta" solo debe\n'
        f'    // verse en Ajustes, y como vive fuera del árbol de controles de\n'
        f'    // Flet (todo se dibuja en un único <canvas>, sin DOM por\n'
        f'    // control) necesita que se le avise por fuera. Se usa\n'
        f'    // addEventListener, no una reasignación de app.worker.onmessage,\n'
        f'    // para no interferir con la comunicación normal de Flet.\n'
        f'    app.worker.addEventListener("message", function (event) {{\n'
        f'        if (event.data && event.data.__albumPage) {{\n'
        f'            window.dispatchEvent(new CustomEvent("album-page-change",\n'
        f'                {{ detail: event.data.__albumPage }}));\n'
        f'        }}\n'
        f'    }});\n'
    )
    text = text.replace(anchor, injected, 1)
    path.write_text(text, encoding="utf-8")
    print(f"  {path.name}: parcheado (worker expuesto en window.__fletPyWorker)")
    return True


def patch_python_worker_js(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    if MARKER in text:
        print(f"  {path.name}: ya estaba parcheado, no toco nada")
        return True

    anchor = (
        "        await self.initPyodide();\n"
        "    } else {\n"
        "        // message\n"
        "        flet_js.send(event.data);\n"
        "    }\n"
        "};\n"
    )
    if anchor not in text:
        print(f"  ERROR: no encontré el punto esperado en {path.name} — "
              f"¿esta versión de Flet genera un python-worker.js distinto? "
              f"Aviso a Claude con el mensaje de error si ves esto.")
        return False

    replacement = (
        "        await self.initPyodide();\n"
        f"    }} else if (event.data && event.data.__albumZipDrop) {{\n"
        f"        // {MARKER} Uno o varios ZIP soltados o elegidos con el\n"
        f"        // botón nuevo directamente sobre la página (atajo de\n"
        f"        // importación para iPad y Android — ver\n"
        f"        // habilitar_arrastrar_zip.py y el LEEME.md). `event.data.files`\n"
        f"        // son referencias a archivo SIN LEER (File/Blob, clonados tal\n"
        f"        // cual por postMessage, ya ordenados por index.html) — se leen\n"
        f"        // y procesan AQUÍ, de uno en uno, esperando (`await`) a que\n"
        f"        // Python termine cada uno (incluida la escritura a IndexedDB)\n"
        f"        // antes de leer el siguiente. Así nunca hay más de un ZIP\n"
        f"        // entero en memoria a la vez — con varios soltados de golpe,\n"
        f"        // leerlos TODOS por adelantado agotó la memoria en un iPad\n"
        f"        // real ('Out of Memory'; ver el docstring del script).\n"
        "        try {\n"
        '            const fn = self.pyodide.globals.get("recibir_zip_arrastrado");\n'
        "            if (!fn) {\n"
        f'                console.error("{MARKER} recibir_zip_arrastrado no existe '
        'todavía en Python (¿la app sigue arrancando?)");\n'
        "            } else {\n"
        "                const archivos = event.data.files || [];\n"
        "                const total = archivos.length;\n"
        "                for (let i = 0; i < total; i++) {\n"
        "                    const archivo = archivos[i];\n"
        "                    let bytes;\n"
        "                    try {\n"
        "                        const buf = await archivo.arrayBuffer();\n"
        "                        bytes = new Uint8Array(buf);\n"
        "                    } catch (errLectura) {\n"
        f'                        console.error("{MARKER} Error leyendo " + '
        'archivo.name + ":", errLectura);\n'
        "                        break;\n"
        "                    }\n"
        "                    const ok = await fn(bytes, archivo.name || \"\", i + 1, total);\n"
        "                    // Sin más referencias a `bytes`/`buf` antes de leer el\n"
        "                    // siguiente archivo, para que quede libre para el GC.\n"
        "                    bytes = null;\n"
        "                    if (ok !== true) break;\n"
        "                }\n"
        "            }\n"
        "        } catch (err) {\n"
        f'            console.error("{MARKER} Error procesando los ZIP arrastrados:", err);\n'
        "        }\n"
        "    } else {\n"
        "        // message\n"
        "        flet_js.send(event.data);\n"
        "    }\n"
        "};\n"
    )
    text = text.replace(anchor, replacement, 1)
    path.write_text(text, encoding="utf-8")
    print(f"  {path.name}: parcheado (reconoce ZIP(s) arrastrados/elegidos y los procesa uno a uno)")
    return True


DROP_ZONE_HTML = """
<!-- [Album-dnd] Zona de "arrastrar y soltar" + botón "elegir carpeta"
     (webkitdirectory), para importar el/los ZIP sin pasar por el
     selector normal de Flet (que no abre el diálogo nativo en iPad — ver
     LEEME.md). Las tres vías (soltar archivo(s) suelto(s), soltar una
     CARPETA con los .zip dentro, o el botón de carpeta) aceptan uno o
     varios .zip a la vez (p. ej. las partes de
     `exportar_zip_familia.py --max-zip-mb`) y los procesan uno detrás de
     otro, nunca todos en memoria a la vez. El botón de carpeta está
     OCULTO por defecto y solo se muestra en la pestaña Ajustes de la
     app: main.py avisa qué pestaña está activa mandando un mensaje por
     postMessage desde el Worker de Python (_notificar_pagina_activa, en
     _select_nav), que python.js reenvía como el evento de JavaScript
     'album-page-change' que este script escucha más abajo. Inyectado por
     habilitar_arrastrar_zip.py tras cada `flet publish`; no toca nada de
     la interfaz normal de la app salvo por este botón y el aviso de
     "soltar", que solo aparece mientras arrastras archivos sobre la
     página. -->
<div id="album-drop-overlay" style="
  display:none; position:fixed; inset:0; z-index:999999;
  background:rgba(20,35,85,0.90); color:#fff;
  align-items:center; justify-content:center; text-align:center;
  font: 500 5vw/1.4 system-ui, -apple-system, sans-serif; padding:24px;
  pointer-events:none;">
  Suelta aquí el/los archivo(s) o la carpeta ZIP del álbum<br>para importarlo(s)
</div>

<input type="file" id="album-folder-zip-input" webkitdirectory directory multiple
  style="position:fixed; width:1px; height:1px; opacity:0; pointer-events:none; left:-9999px;">
<!-- Barra oculta por defecto (display:none, JS la pone a "flex" para
     mostrarla): solo se muestra en Ajustes, ver el listener de
     'album-page-change' más abajo. Ocupa (aproximadamente) el lugar de
     "Importar ZIP" (ya eliminado de main.py): no se puede "meter"
     literalmente dentro de settings_page ni alinear pixel a pixel con un
     punto exacto de una columna con scroll (Flet dibuja en un único
     <canvas>, no hay DOM por control).

     Anclada ABAJO, no arriba: la primera versión la anclaba justo debajo
     de la barra superior con un hueco fijo calculado a ojo
     (`calc(64px + safe-area-inset-top)`), pero esa altura no es fiable
     de verdad -- el AppBar lo dibuja Flet/Flutter con su propia lógica de
     zona segura, que varía según el dispositivo (notch, cámara en
     agujero, etc.) y no hay forma de leerla desde este HTML aparte. En
     algunos móviles el hueco se quedaba corto y la barra tapaba
     "Estadísticas". Anclarla abajo evita el problema de raíz en vez de
     intentar adivinar mejor: `env(safe-area-inset-bottom)` (el hueco de
     la barra de gestos/home) sí es un valor estándar y fiable en
     cualquier dispositivo, así que la barra queda bien colocada sin
     depender de ninguna suposición sobre el alto del AppBar -- y de
     paso, en la mayoría de pantallas, cae cerca de donde pediste
     (justo encima del texto de copyright, debajo de "Descargar
     manual"). `settings_page`, en main.py, reserva un hueco al final de
     su columna (un Container vacío) para que ese texto de copyright no
     quede tapado si Ajustes tiene contenido de sobra para hacer scroll.

     Aspecto: antes era una píldora sólida del azul de la cabecera con
     texto blanco -- pero el `ElevatedButton` real de Flet (como
     "Descargar manual", sin ningún `style=` propio) usa el aspecto por
     defecto de Material 3: fondo claro (un gris muy suave, no el azul
     de marca) con el texto e icono en el color primario, más una sombra
     sutil -- NO un botón "relleno" de color sólido. Cambiado para
     igualarlo: fondo `#EEF0F7`, texto/icono `#283593` (el mismo
     `PRIMARY` de la cabecera), sombra ligera. -->
<div id="album-folder-zip-bar" style="
  display:none; position:fixed; left:0; right:0; bottom:0; z-index:999997;
  justify-content:center;
  padding:8px 16px calc(16px + env(safe-area-inset-bottom, 0px));
  pointer-events:none;">
  <button type="button" id="album-folder-zip-button" style="
    pointer-events:auto; display:inline-flex; align-items:center; gap:8px;
    background:#EEF0F7; color:#283593; border:none; border-radius:24px;
    padding:12px 24px; font:600 15px/1.2 system-ui, -apple-system, sans-serif;
    box-shadow:0 1px 4px rgba(0,0,0,0.25); cursor:pointer;">
    <span style="font-size:18px; line-height:1;">📁</span>
    Elegir carpeta con las partes ZIP
  </button>
</div>

<script>
(function () {
  var overlay = document.getElementById('album-drop-overlay');
  var folderInput = document.getElementById('album-folder-zip-input');
  var folderBar = document.getElementById('album-folder-zip-bar');
  var folderButton = document.getElementById('album-folder-zip-button');
  var dragDepth = 0;

  // Solo visible en la pestaña Ajustes -- ver _notificar_pagina_activa()
  // en main.py y el listener de mensajes del worker en python.js.
  window.addEventListener('album-page-change', function (e) {
    folderBar.style.display = (e.detail === 'ajustes') ? 'flex' : 'none';
  });

  function showOverlay() { overlay.style.display = 'flex'; }
  function hideOverlay() { overlay.style.display = 'none'; dragDepth = 0; }

  function tieneArchivos(e) {
    return !!(e.dataTransfer && e.dataTransfer.types &&
      Array.prototype.indexOf.call(e.dataTransfer.types, 'Files') !== -1);
  }

  window.addEventListener('dragenter', function (e) {
    if (!tieneArchivos(e)) return;
    dragDepth++;
    showOverlay();
  }, true);

  window.addEventListener('dragover', function (e) {
    if (tieneArchivos(e)) e.preventDefault();
  }, true);

  window.addEventListener('dragleave', function () {
    dragDepth = Math.max(0, dragDepth - 1);
    if (dragDepth === 0) hideOverlay();
  }, true);

  // Extrae el número de parte de un nombre "..._parteN_de_M..." (el que
  // pone exportar_zip_familia.py) para poder ordenar los archivos ANTES
  // de leer ni un solo byte -- así, si se sueltan/eligen varias partes
  // juntas, la que trae Fotos.db (siempre "parte1") es la primera que
  // procesa Python. Es solo una ayuda por nombre, no abre el .zip para
  // comprobarlo; los nombres que no siguen esa convención se dejan al
  // final, en el orden en que los dio el navegador.
  function numeroDeParte(nombre) {
    var m = /_parte(\\d+)_de_\\d+/i.exec(nombre);
    return m ? parseInt(m[1], 10) : null;
  }

  // Punto único compartido por "soltar" (archivos o carpeta), "elegir
  // carpeta" y "elegir varias partes": filtra a solo .zip, ordena por
  // número de parte, y manda la lista AL WORKER SIN LEER NINGÚN BYTE
  // aquí -- es python-worker.js quien los lee y procesa, uno a uno,
  // esperando a que Python termine cada uno antes de leer el siguiente
  // (ver el docstring del script para el porqué: leerlos todos de golpe
  // aquí agotó la memoria de la pestaña en un iPad real). Acepta tanto
  // un FileList (lo que da el navegador para archivos sueltos o para el
  // <input webkitdirectory>) como un array normal de File (lo que arma
  // extraerArchivosDeDrop() al recorrer una carpeta soltada) -- el
  // filtro de abajo funciona igual con los dos gracias a
  // Array.prototype.filter.call.
  function procesarZips(archivosRaw, origen) {
    var zips = Array.prototype.filter.call(archivosRaw, function (f) {
      return /\\.zip$/i.test(f.name);
    });
    if (!zips.length) {
      console.warn('[Album-dnd] Ningún archivo de ' + origen + ' es un .zip (de ' +
        archivosRaw.length + ' recibido(s))');
      return;
    }
    if (!window.__fletPyWorker) {
      console.error('[Album-dnd] La app todavia no esta lista (worker de Python no disponible)');
      return;
    }

    zips.sort(function (a, b) {
      var na = numeroDeParte(a.name), nb = numeroDeParte(b.name);
      if (na === null && nb === null) return 0;
      if (na === null) return 1;
      if (nb === null) return -1;
      return na - nb;
    });

    // IMPORTANTE: aquí se mandan los archivos SIN LEER (los objetos File
    // se clonan tal cual por postMessage, es barato, no hace falta leer
    // su contenido para eso). Es el worker (python-worker.js) quien los
    // lee y procesa, DE UNO EN UNO, esperando a que Python termine cada
    // uno antes de leer el siguiente -- si se leyeran aquí TODOS a la
    // vez antes de mandarlos, con varias partes de golpe se podría
    // agotar la memoria de la pestaña (visto en un iPad real: "Out of
    // Memory"). Ver el porqué con más detalle en el docstring del script.
    try {
      window.__fletPyWorker.postMessage({ __albumZipDrop: true, files: zips });
    } catch (err) {
      console.error('[Album-dnd] Error enviando los archivos de ' + origen + ' al worker:', err);
    }
  }

  // --- Soporte para soltar una CARPETA ENTERA (no solo archivos sueltos) ---
  // [Album-dnd] NUEVO: `e.dataTransfer.files` (lo que usaba el listener de
  // 'drop' hasta ahora) es una lista PLANA -- si sueltas una carpeta, el
  // navegador no baja a mirar qué hay dentro. Para leer el contenido de
  // una carpeta soltada hace falta la otra API de HTML5 drag & drop:
  // `dataTransfer.items` + `item.webkitGetAsEntry()` (soportada, pese al
  // prefijo, en Chrome/Edge/Firefox/Safari de escritorio). Cada entrada
  // es un archivo (`FileSystemFileEntry`) o una carpeta
  // (`FileSystemDirectoryEntry`); para una carpeta se recorre con
  // `createReader().readEntries()` -- llamada en bucle hasta que devuelve
  // un lote vacío, porque la especificación permite que cada llamada
  // devuelva como mucho un lote parcial -- y de forma RECURSIVA por cada
  // subcarpeta, igual que hace `webkitdirectory` con el botón de carpeta.

  // Lee TODAS las entradas de una carpeta, no solo el primer lote.
  function leerEntradasDirectorio(dirEntry) {
    return new Promise(function (resolve, reject) {
      var reader = dirEntry.createReader();
      var todas = [];
      function leerLote() {
        reader.readEntries(function (entradas) {
          if (!entradas.length) { resolve(todas); return; }
          todas = todas.concat(entradas);
          leerLote();
        }, reject);
      }
      leerLote();
    });
  }

  function entradaAFile(fileEntry) {
    return new Promise(function (resolve, reject) {
      fileEntry.file(resolve, reject);
    });
  }

  // Recorre recursivamente una carpeta (y las subcarpetas que contenga) y
  // devuelve la lista completa de File encontrados en todo el árbol --
  // así, si sueltas la carpeta entera del pendrive (en vez de cada .zip
  // suelto), esta vía encuentra las partes igual que el <input
  // webkitdirectory> del botón, que también baja a subcarpetas.
  async function recorrerDirectorio(dirEntry) {
    var entradas = await leerEntradasDirectorio(dirEntry);
    var archivos = [];
    for (var i = 0; i < entradas.length; i++) {
      var entrada = entradas[i];
      if (entrada.isFile) {
        archivos.push(await entradaAFile(entrada));
      } else if (entrada.isDirectory) {
        archivos = archivos.concat(await recorrerDirectorio(entrada));
      }
    }
    return archivos;
  }

  // A partir del DataTransfer de un evento 'drop', arma la lista de File
  // a procesar. IMPORTANTE: `webkitGetAsEntry()` se llama de forma
  // SÍNCRONA aquí abajo, dentro del propio manejador del evento -- no
  // después de ningún `await` -- porque `dataTransfer.items` deja de ser
  // válido en cuanto el navegador termina de despachar el evento 'drop';
  // una vez obtenidas las "entradas" (FileSystemEntry), esas sí se
  // pueden usar de forma asíncrona sin problema (leer una carpeta puede
  // tardar). Si el navegador no soporta esta API (algún navegador
  // antiguo, o `dataTransfer.items` vacío), se cae al comportamiento de
  // siempre: `dataTransfer.files` tal cual, que solo trae archivos
  // sueltos -- soltar una carpeta en ese caso simplemente no encuentra
  // ningún .zip dentro (procesarZips avisa por consola), igual que antes
  // de este cambio.
  function extraerArchivosDeDrop(dataTransfer) {
    var items = dataTransfer.items;
    if (!items || !items.length || typeof items[0].webkitGetAsEntry !== 'function') {
      return Promise.resolve(dataTransfer.files);
    }
    var promesas = [];
    var archivos = [];
    for (var i = 0; i < items.length; i++) {
      var entry = items[i].webkitGetAsEntry && items[i].webkitGetAsEntry();
      if (!entry) continue;
      if (entry.isFile) {
        promesas.push(entradaAFile(entry).then(function (f) { archivos.push(f); }));
      } else if (entry.isDirectory) {
        promesas.push(recorrerDirectorio(entry).then(function (fs) {
          archivos = archivos.concat(fs);
        }));
      }
    }
    return Promise.all(promesas).then(function () { return archivos; });
  }

  window.addEventListener('drop', function (e) {
    if (!tieneArchivos(e)) return;
    e.preventDefault();
    hideOverlay();

    var dt = e.dataTransfer;
    extraerArchivosDeDrop(dt).then(function (archivos) {
      if (!archivos || !archivos.length) return;
      procesarZips(archivos, 'soltar');
    }).catch(function (err) {
      // Red de seguridad: si algo falla leyendo carpetas/entradas (poco
      // probable, pero por si acaso), se intenta con los archivos
      // sueltos tal cual -- por si entre lo soltado había alguno directo.
      console.error('[Album-dnd] Error leyendo lo soltado (¿carpeta?):', err);
      if (dt.files && dt.files.length) procesarZips(dt.files, 'soltar');
    });
  }, true);

  // Botón "Elegir carpeta con las partes ZIP": abre el selector NATIVO
  // de carpeta (<input type="file" webkitdirectory>, HTML puro, no el
  // control FilePicker de Flet) -- el click sigue siendo un listener
  // nativo sin pasar por Python, así que abre el diálogo como reacción
  // DIRECTA al toque (nada rompe la restricción de "gesto real" de los
  // navegadores). Tiene fama de no funcionar en móvil, pero confirmado en
  // un Huawei P30 Pro/EMUI 12 real que SÍ funciona (pide permiso de
  // acceso la primera vez -- normal, es Android protegiendo el
  // almacenamiento -- y tras concederlo entrega todos los archivos de la
  // carpeta elegida). Si el dispositivo no lo soporta, el <input>
  // simplemente se comporta como un selector de archivos normal (no se
  // rompe -- ver MDN).
  folderButton.addEventListener('click', function () {
    folderInput.value = '';
    folderInput.click();
  });

  folderInput.addEventListener('change', function () {
    if (!folderInput.files || !folderInput.files.length) return;
    procesarZips(folderInput.files, 'la carpeta elegida');
    folderInput.value = '';
  });
})();
</script>
"""


def patch_index_html(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    if MARKER in text:
        print(f"  {path.name}: ya estaba parcheado, no toco nada")
        return True

    if "</body>" not in text:
        print(f"  ERROR: no encontré </body> en {path.name} — "
              f"¿este archivo cambió de formato? Aviso a Claude si ves esto.")
        return False

    text = text.replace("</body>", DROP_ZONE_HTML + "</body>", 1)
    path.write_text(text, encoding="utf-8")
    print(f"  {path.name}: parcheado (zona de arrastrar-y-soltar -- incluida carpeta -- + "
          f"botón de carpeta, visible solo en Ajustes, añadidos)")
    return True


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dist", default="dist", help="Carpeta dist/ generada por flet publish")
    args = ap.parse_args()

    dist = Path(args.dist)
    if not dist.exists():
        print(f"No encuentro la carpeta '{dist}'. Ejecuta primero `flet publish` "
              f"o indica la ruta correcta con --dist.")
        sys.exit(1)

    ok = True
    print("Parcheando para habilitar arrastrar-y-soltar (archivos o carpeta) y elegir carpeta "
          "con las partes del ZIP...")
    ok &= patch_python_js(dist / "python.js")
    ok &= patch_python_worker_js(dist / "python-worker.js")
    ok &= patch_index_html(dist / "index.html")

    if ok:
        print("Listo. La app ya no tiene un botón 'Importar ZIP' de Flet -- se importa de tres "
              "formas, ninguna de ellas confirma cada parte por separado: en la pestaña "
              "Ajustes, tocar '📁 Elegir carpeta con las partes ZIP' (fijo abajo, con el "
              "aspecto de 'Descargar manual') y elegir de golpe la carpeta del pendrive donde "
              "están todas las partes; soltar uno o varios .zip directamente sobre la página, "
              "en cualquier pestaña; o soltar la carpeta entera que los contiene (NUEVO). En "
              "todos los casos, si son varias partes, se importan una detrás de otra, nunca "
              "todas a la vez en memoria.")
    else:
        print("\nAlgo no encajó (ver los ERROR de arriba) — probablemente Flet cambió "
              "el formato de estos archivos en una actualización. Avisa a Claude con "
              "el mensaje de error para adaptar el script.")
        sys.exit(1)


if __name__ == "__main__":
    main()
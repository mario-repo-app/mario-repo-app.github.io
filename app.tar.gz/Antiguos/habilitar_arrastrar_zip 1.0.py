"""
Habilitar "arrastrar y soltar" el ZIP — atajo para importar en iPad
====================================================================

El selector de archivos normal de Flet ("Importar ZIP") no consigue abrir
el diálogo nativo de "elegir archivo" en Safari/iPadOS. No es un fallo de
`main.py`: es un fallo conocido y documentado del propio framework Flet,
sin arreglo todavía (reproducido incluso en la demo oficial de Flet, ver
el LEEME.md para los enlaces). Ocurre porque, en el build web de Flet,
Python corre dentro de un Web Worker separado del hilo principal del
navegador — abrir el selector nativo requiere ir y volver entre ese
Worker y el hilo principal por mensajes, y Safari exige que ese diálogo
se abra como reacción directa e inmediata al toque del usuario, sin
ningún salto de por medio. Ese salto es inevitable con la arquitectura
actual de Flet, así que no hay ningún cambio en `main.py` que lo arregle.

"Arrastrar y soltar" no tiene este problema: cuando sueltas un archivo
sobre una página, el navegador te da el archivo directamente, sin pasar
por ningún diálogo del sistema — así que esta vía no depende en absoluto
del selector que falla.

Este script añade esa vía alternativa parcheando 3 archivos que genera
`flet publish` en `dist/`:

- `python.js` — expone el "worker" donde corre Python (`window.__fletPyWorker`)
  para que el script de abajo pueda enviarle mensajes.
- `python-worker.js` — reconoce un tipo de mensaje nuevo ("aquí tienes un
  ZIP arrastrado") y llama directamente a la función de Python
  `recibir_zip_arrastrado` (definida en `main.py`) con sus bytes.
- `index.html` — añade el propio detector de "arrastrar y soltar": al
  soltar un archivo sobre la página, si es un .zip, lo lee y se lo manda
  al worker de Python. Incluye un aviso visual (fondo azul con el texto
  "Suelta aquí...") que aparece mientras arrastras un archivo sobre la
  página, para que sea evidente que la zona de soltar está activa.

Como `flet publish` regenera `dist/` entero cada vez, hay que volver a
ejecutar este script (igual que `fix_icons.py`) después de cada
`flet publish`:

    python habilitar_arrastrar_zip.py
    python fix_icons.py

(el orden entre los dos no importa, cada uno toca archivos distintos).

Por defecto asume que `dist/` está en la carpeta actual; si usas otra
ruta:

    python habilitar_arrastrar_zip.py --dist "ruta\\a\\dist"

Nota importante: esto SOLO he podido probarlo con Chromium (arrastrar y
soltar SÍ funciona igual ahí, y lo comprobé de principio a fin: se suelta
el ZIP, la Galería se actualiza). Lo que no he podido comprobar desde
este entorno es el gesto físico concreto de arrastrar un archivo desde la
app Archivos de un iPad hasta Safari — es una función que Apple documenta
como soportada desde iPadOS 11, pero la confirmación real en tu iPad
solo la puedes hacer tú.
"""
import argparse
import sys
from pathlib import Path

MARKER = "[Album-dnd]"


def patch_python_js(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    if MARKER in text:
        print(f"  {path.name}: ya estaba parcheado, no toco nada")
        return True

    anchor = (
        '    app.worker = new Worker(\n'
        '        (flet.entrypointBaseUrl.endsWith("/") ?\n'
        '            flet.entrypointBaseUrl.slice(0, -1) : flet.entrypointBaseUrl) + "/python-worker.js",\n'
        '        { type: "module" });\n'
    )
    if anchor not in text:
        print(f"  ERROR: no encontré el punto esperado en {path.name} — "
              f"¿esta versión de Flet genera un python.js distinto? "
              f"Aviso a Claude con el mensaje de error si ves esto.")
        return False

    injected = anchor + (
        f'    // {MARKER} Expone el worker de Python para que el detector de\n'
        f'    // "arrastrar y soltar" (inyectado en index.html) pueda mandarle\n'
        f'    // directamente los bytes de un ZIP soltado sobre la página —\n'
        f'    // atajo para iPad, donde el selector de archivos no abre el\n'
        f'    // diálogo nativo de iOS (ver habilitar_arrastrar_zip.py).\n'
        f'    window.__fletPyWorker = app.worker;\n'
    )
    text = text.replace(anchor, injected, 1)
    path.write_text(text, encoding="utf-8")
    print(f"  {path.name}: parcheado (worker expuesto en window.__fletPyWorker)")
    return True


def patch_python_worker_js(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    if MARKER in text:
        print(f"  {path.name}: ya estaba parcheado, no toco nada")
        return True

    anchor = (
        "        await self.initPyodide();\n"
        "    } else {\n"
        "        // message\n"
        "        flet_js.send(event.data);\n"
        "    }\n"
        "};\n"
    )
    if anchor not in text:
        print(f"  ERROR: no encontré el punto esperado en {path.name} — "
              f"¿esta versión de Flet genera un python-worker.js distinto? "
              f"Aviso a Claude con el mensaje de error si ves esto.")
        return False

    replacement = (
        "        await self.initPyodide();\n"
        f"    }} else if (event.data && event.data.__albumZipDrop) {{\n"
        f"        // {MARKER} Bytes de un ZIP soltado directamente sobre la\n"
        f"        // página (atajo de importación para iPad — ver\n"
        f"        // habilitar_arrastrar_zip.py y el LEEME.md).\n"
        "        try {\n"
        '            const fn = self.pyodide.globals.get("recibir_zip_arrastrado");\n'
        "            if (fn) {\n"
        "                await fn(event.data.bytes, event.data.name || \"\");\n"
        "            } else {\n"
        f'                console.error("{MARKER} recibir_zip_arrastrado no existe '
        'todavía en Python (¿la app sigue arrancando?)");\n'
        "            }\n"
        "        } catch (err) {\n"
        f'            console.error("{MARKER} Error procesando el ZIP arrastrado:", err);\n'
        "        }\n"
        "    } else {\n"
        "        // message\n"
        "        flet_js.send(event.data);\n"
        "    }\n"
        "};\n"
    )
    text = text.replace(anchor, replacement, 1)
    path.write_text(text, encoding="utf-8")
    print(f"  {path.name}: parcheado (reconoce ZIP arrastrado y llama a Python)")
    return True


DROP_ZONE_HTML = """
<!-- [Album-dnd] Zona de "arrastrar y soltar" para importar el ZIP,
     pensada sobre todo para iPad (donde el selector de archivos normal
     de Flet no funciona — ver LEEME.md). Inyectado por
     habilitar_arrastrar_zip.py tras cada `flet publish`; no toca nada
     de la interfaz normal de la app salvo por este aviso, que solo
     aparece mientras arrastras un archivo sobre la página. -->
<div id="album-drop-overlay" style="
  display:none; position:fixed; inset:0; z-index:999999;
  background:rgba(20,35,85,0.90); color:#fff;
  align-items:center; justify-content:center; text-align:center;
  font: 500 5vw/1.4 system-ui, -apple-system, sans-serif; padding:24px;
  pointer-events:none;">
  Suelta aquí el archivo ZIP del álbum<br>para importarlo
</div>
<script>
(function () {
  var overlay = document.getElementById('album-drop-overlay');
  var dragDepth = 0;

  function showOverlay() { overlay.style.display = 'flex'; }
  function hideOverlay() { overlay.style.display = 'none'; dragDepth = 0; }

  function tieneArchivos(e) {
    return !!(e.dataTransfer && e.dataTransfer.types &&
      Array.prototype.indexOf.call(e.dataTransfer.types, 'Files') !== -1);
  }

  window.addEventListener('dragenter', function (e) {
    if (!tieneArchivos(e)) return;
    dragDepth++;
    showOverlay();
  }, true);

  window.addEventListener('dragover', function (e) {
    if (tieneArchivos(e)) e.preventDefault();
  }, true);

  window.addEventListener('dragleave', function () {
    dragDepth = Math.max(0, dragDepth - 1);
    if (dragDepth === 0) hideOverlay();
  }, true);

  window.addEventListener('drop', async function (e) {
    if (!tieneArchivos(e)) return;
    e.preventDefault();
    hideOverlay();
    var files = e.dataTransfer.files;
    if (!files || !files.length) return;
    var file = files[0];
    if (!/\\.zip$/i.test(file.name)) {
      console.warn('[Album-dnd] El archivo soltado no es un .zip:', file.name);
      return;
    }
    if (!window.__fletPyWorker) {
      console.error('[Album-dnd] La app todavia no esta lista (worker de Python no disponible)');
      return;
    }
    try {
      var buf = await file.arrayBuffer();
      var bytes = new Uint8Array(buf);
      window.__fletPyWorker.postMessage(
        { __albumZipDrop: true, bytes: bytes, name: file.name },
        [bytes.buffer]
      );
    } catch (err) {
      console.error('[Album-dnd] Error leyendo el archivo soltado:', err);
    }
  }, true);
})();
</script>
"""


def patch_index_html(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    if MARKER in text:
        print(f"  {path.name}: ya estaba parcheado, no toco nada")
        return True

    if "</body>" not in text:
        print(f"  ERROR: no encontré </body> en {path.name} — "
              f"¿este archivo cambió de formato? Aviso a Claude si ves esto.")
        return False

    text = text.replace("</body>", DROP_ZONE_HTML + "</body>", 1)
    path.write_text(text, encoding="utf-8")
    print(f"  {path.name}: parcheado (zona de arrastrar-y-soltar añadida)")
    return True


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dist", default="dist", help="Carpeta dist/ generada por flet publish")
    args = ap.parse_args()

    dist = Path(args.dist)
    if not dist.exists():
        print(f"No encuentro la carpeta '{dist}'. Ejecuta primero `flet publish` "
              f"o indica la ruta correcta con --dist.")
        sys.exit(1)

    ok = True
    print("Parcheando para habilitar arrastrar-y-soltar del ZIP (atajo para iPad)...")
    ok &= patch_python_js(dist / "python.js")
    ok &= patch_python_worker_js(dist / "python-worker.js")
    ok &= patch_index_html(dist / "index.html")

    if ok:
        print("Listo. Ahora, además del botón 'Importar ZIP', también se puede soltar "
              "el archivo .zip directamente sobre la página.")
    else:
        print("\nAlgo no encajó (ver los ERROR de arriba) — probablemente Flet cambió "
              "el formato de estos archivos en una actualización. Avisa a Claude con "
              "el mensaje de error para adaptar el script.")
        sys.exit(1)


if __name__ == "__main__":
    main()
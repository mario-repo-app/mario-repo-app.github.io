"""
Arreglar los iconos (y la versión) tras `flet publish`
========================================

`flet publish` (a diferencia de `flet build web`) NO usa `assets/icon.png`
para generar los iconos de la PWA: deja los iconos genéricos de Flet tal
cual en la carpeta `dist/icons/` y en `dist/favicon.png`. Lo comprobé
leyendo el código de `flet_cli`: la función que rellena `manifest.json`
solo toca el nombre/descripción/colores, nunca los iconos.

Este script sustituye esos iconos por defecto por los tuyos, a partir de
un icono cuadrado (`assets/icon.png`), generando cada tamaño que pide
`manifest.json`.

Iconos "maskable" (v2): los iconos `icon-maskable-*.png` no se generan
igual que los demás. La especificación de manifest de PWA permite que el
sistema operativo recorte estos iconos con su propia forma (círculo,
superelipse...) y solo garantiza visible el 80% central ("zona segura").
Si se les deja el fondo transparente del icono normal, el sistema rellena
esa transparencia con su propio color de repuesto al aplicar la máscara
-en Windows, normalmente blanco- y eso se ve como un borde/orla blanca
alrededor del icono, aunque el PNG tenga el canal alfa "correcto". Por
eso, para los maskable, este script compone el logo (reducido, para que
quede dentro de la zona segura) sobre un fondo sólido opaco -el color de
marca del álbum, `--bg-color`- en vez de dejarlo transparente.

De paso, todos los redimensionados (maskable o no) se hacen premultiplicando
el canal alfa antes de aplicar el filtro de reescalado (Lanczos) y
deshaciendo la premultiplicación después. Sin esto, Pillow interpola los
canales de color y el alfa por separado, y si los píxeles totalmente
transparentes del icono original tienen un RGB "de fondo" claro (blanco es
lo más habitual al exportar desde muchos editores), ese blanco se filtra
hacia los píxeles opacos vecinos al reescalar, dejando un halo blanquecino
en los bordes del logo -sutil, pero visible en tamaños pequeños.

Versionado de iconos en manifest.json (v3): Chrome (y navegadores similares)
solo vuelven a descargar un icono de un PWA ya instalado cuando detectan que
`manifest.json` "cambió" -y ese chequeo se basa en el propio texto del
manifest (URLs, tamaños...), no en si el contenido del PNG referenciado es
distinto byte a byte. Como cada `flet publish` + `fix_icons.py` reescribe
los PNG pero con el mismo nombre de archivo de siempre (`icon-maskable-512.
png`...), Chrome puede seguir dando por bueno el icono que descargó la
primera vez que instalaste la app, aunque el archivo en el servidor ya sea
el correcto -esto explica por ejemplo que, tras aplicar el fondo sólido de
los maskable, el archivo se vea bien al abrirlo directamente pero la app
recién reinstalada lo siga mostrando con bordes blancos. Para evitarlo,
este script añade `?v=<hash>` (un hash corto del contenido del PNG) a la
URL de cada icono dentro de `manifest.json`; así, cada vez que el
contenido cambia de verdad, la URL también cambia, y ningún navegador
puede confundir "mismo nombre" con "mismo contenido".

Sin transparencia real en ningún icono "de sistema" (v4): con una imagen de
origen real se vio que, incluso ya con fondo sólido en los maskable, el
icono del escritorio en Windows seguía saliendo con las esquinas blancas.
La causa que se manejó en ese momento: Chrome usa el icono normal
(`icon-512.png`/`icon-192.png`), no el maskable, para generar el `.ico` del
acceso directo de escritorio -y ese icono normal sí seguía teniendo
transparencia real en las esquinas (aunque "limpia"), que Chrome aplanaría
sobre blanco al convertir a `.ico`. Arreglo de entonces: todos los iconos
"de sistema" (normal, maskable y apple-touch-icon) compuestos sobre fondo
sólido opaco, sin dejar ni un píxel transparente.

Vuelta atrás parcial, con las esquinas redondeadas del icono normal (v5):
tras seguir viendo esquinas blancas incluso con la v4, se probó a instalar
en un perfil de Chrome totalmente nuevo (sin ningún residuo de las muchas
rondas de prueba anteriores) -y ahí el icono ya salió bien, con fondo
sólido en vez de blanco. Eso reveló que buena parte (quizás toda) de las
esquinas blancas que se seguían viendo eran restos acumulados en el perfil
de pruebas, no un fallo real del icono normal con transparencia. Con eso
sobre la mesa, y para recuperar el aspecto redondeado que sí se ve en
Android (donde el sistema aplica su propia máscara sobre el icono
maskable), `icon-192.png`/`icon-512.png` vuelven a generarse con
transparencia real -en vez de fondo sólido-, pero esta vez limpiando a
fondo el origen: cualquier píxel con alfa por debajo de un umbral
(`ALPHA_LIMPIEZA`) se fuerza a (0,0,0,0) del todo, en vez de solo atenuarlo
con la premultiplicación del apartado anterior. Es la manera de curarse en
salud frente al ruido de color que puede llevar el `assets/icon.png` de
origen (ver más abajo) sin perder la forma redondeada. El maskable y el
apple-touch-icon SIGUEN con fondo sólido -es lo correcto para ambos por
diseño de sus respectivas plataformas, no una solución de compromiso.

Campo "version" en manifest.json (v6): igual que con los iconos, comprobé
leyendo `flet_cli`/`flet_web` que `flet publish` NUNCA escribe un campo
"version" en `manifest.json` -ni hay ninguna opción de línea de comandos
ni de `pyproject.toml` para ello (eso solo existe para `flet build`, que
sigue un camino totalmente distinto, vía Flutter/pubspec.yaml, y no es lo
que usa este proyecto). El propio manifest.json de fábrica de Flet no trae
ese campo. "version" SÍ es un campo estándar del manifest de aplicación
web (no todos los navegadores lo usan igual, pero Windows con Edge/Chrome
lo lee para mostrar la versión de una PWA instalada, por ejemplo al
desinstalarla desde Configuración > Aplicaciones) -por eso, sin este
script, quedaba vacío y el sistema mostraba algún valor de repuesto ("1.0")
en vez de la versión real de la app. Este script añade/actualiza ese campo
leyéndolo automáticamente de `VERSION = '...'` en `main.py`, para no tener
que mantenerlo por duplicado en dos sitios -si alguna vez se quiere fijar
a mano (o `main.py` no está en la ruta por defecto), se puede pasar con
`--version`/`--main`.

Campo "orientation" en manifest.json (v7): investigando por qué la app no
gira de vertical a horizontal en Android (aunque sí lo hace en iOS con el
mismo `main.py`), leyendo `flet_web/web/manifest.json` -la plantilla que
copia `flet publish` antes de generar la app- encontré que trae de fábrica
"orientation": "natural". Ese campo, cuando la PWA está instalada
(display: standalone), bloquea la orientación al valor natural del
dispositivo -en un móvil, vertical- e impide rotar a horizontal. Revisando
`flet_web/patch_index.py` confirmé que `patch_manifest_json()` (la función
que `flet publish` usa para tocar el manifest.json) nunca toca ni
"orientation" ni "version": solo escribe name/short_name/description/
background_color/theme_color. Chrome/Android hace cumplir ese bloqueo de
forma estricta en una PWA instalada; Safari/iOS es históricamente mucho
más laxo con el manifest y en la práctica lo ignora -de ahí que el mismo
main.py y el mismo manifest.json solo den problema en Android. Este script
cambia "orientation" a "any" (sin restricción) para que la app y el visor
de imágenes puedan rotar libremente en cualquier plataforma; no hace falta
ninguna opción nueva porque no hay ambigüedad que resolver (a diferencia
del icono o la versión, aquí el valor correcto es siempre el mismo).

Ruido de color en las esquinas, más allá de "casi transparente" (v8): con
un `assets/icon.png` real (una insignia ya redondeada, del tipo generado o
retocado con herramientas de IA) se vio en Android el icono instalado con
las esquinas -justo la parte que lo redondea- de un color visiblemente más
oscuro que el resto, no el halo sutil del apartado de la premultiplicación.
Mirando el PNG de origen a tamaño completo, las zonas de las esquinas que
deberían quedar transparentes tenían motas de ruido de color bastante
visibles (rojo, magenta, cian...), con un alfa bastante por encima del
umbral de `ALPHA_LIMPIEZA` (16) que ya limpia `limpiar_ruido_alfa` -por eso
sobrevivían a esa limpieza-. Subir ese umbral a lo bruto para barrerlas de
un plumazo arriesga limpiar de más el degradado real del borde redondeado
del propio icono, que también vive en esa franja de alfa intermedio. Este
script añade una segunda pasada, `limpiar_islas_alfa`, que ya no se fija en
el valor de alfa de cada píxel suelto sino en si está conectado al icono:
busca el mayor grupo contiguo de píxeles no transparentes (el icono real) y
borra a transparente total cualquier otro grupo aislado -por definición,
las motas de ruido de las esquinas quedan sueltas, separadas del icono por
una franja de transparencia limpia-, sea cual sea su alfa. Al reescalar
después, esas motas ya no están ahí para mezclarse (Lanczos) con el borde
y oscurecerlo.

Dos formas redondeadas anidadas en los iconos con fondo sólido (v9): con
las esquinas ya limpias (v8), el icono maskable seguía viéndose con un
"marco" de un color más oscuro alrededor. La causa: `make_opaque` encogía
el logo al 70% (maskable) o al 94% (apple-touch-icon) y lo recentraba sobre
un lienzo de `--bg-color` -pensado para un logo pequeño sobre lienzo vacío,
que necesita ese margen añadido a mano-. Pero `assets/icon.png` no es eso:
ya es una insignia completa, con su propio degradado y su propio margen de
seguridad respecto al borde del lienzo. Encogerla otra vez encima componía
dos formas redondeadas -la insignia, de nuevo más pequeña, sobre el
cuadrado de `--bg-color`, más grande- con colores que no encajan entre sí
(el degradado propio de la insignia frente al plano de `--bg-color`),
visible como ese marco más oscuro. Con `fill_fraction = 1.0` en
`ICON_TARGETS` ya no se añade ningún encogimiento extra: el margen que se
ve es solo el que trae de fábrica `assets/icon.png`, y `make_opaque` se
limita a rellenar de `--bg-color` los píxeles que sigan transparentes en
ese margen -ya sin ruido- en vez de dejarlos transparentes.

Fracción fija vs. medida (v10): con `fill_fraction = 1.0` (v9) el marco
anidado desapareció, pero apareció el problema contrario -la máscara
circular que aplica Android al instalar la PWA recortaba una esquina del
propio glifo del logo (el marco blanco), porque a sangre completa ese
glifo llega más allá del 80% central que la especificación de iconos
maskable garantiza siempre visible. Ni 1.0 (recorta) ni el 0.70 original
(deja un margen de sobra que vuelve a verse como el marco anidado de la
v9) son correctos en general: el encogido que hace falta depende de cuánto
ocupe el glifo dentro de su propio `assets/icon.png` en cada caso, y eso
solo se puede saber midiendo esa imagen concreta, no adivinando una
constante. Este script ya no fija `fill_fraction` a mano para los iconos
maskable: `calcular_fill_fraction_segura` mide, sobre la imagen ya limpia
de ruido, a qué fracción del radio del lienzo llega el punto no
transparente más alejado del centro, y encoge el logo justo lo necesario
para que ese punto quede dentro del 80% garantizado -ni más (margen de
sobra) ni menos (recorte)-. El apple-touch-icon, al no llevar ninguna
máscara en iOS, se queda fijo en 1.0 sin necesidad de medir nada.

Fondo a juego con el propio icono (v11): con la zona segura ya bien
calculada (v10), volvió a verse un margen más oscuro alrededor del icono
-en este caso correcto por tamaño (dentro del 80% garantizado), pero
seguía sin pasar desapercibido porque `--bg-color` rellenaba ese margen
con el índigo de tema fijo (`283593`), que no es exactamente el mismo azul
que el degradado propio de la insignia. Ajustar el tamaño del margen nunca
iba a arreglar esto del todo: el problema de fondo (nunca mejor dicho) es
que el color de relleno no coincidía con el color del propio icono, por
poco margen que quedara. Este script ya no usa un color de tema fijo por
defecto: `color_borde_icono` promedia el color de los píxeles del propio
`assets/icon.png` en el anillo justo antes de su borde -la franja que va a
quedar pegada al margen-, y usa ese color medido para rellenar tanto el
maskable como el apple-touch-icon, de forma que el margen se funde con el
borde real del icono en vez de notarse como un color distinto. `--bg-color`
se mantiene por si se quiere forzar un color a mano -por ejemplo, si
`assets/icon.png` cambia a un diseño donde el borde no sea representativo
del resto de la insignia-.

Uso (después de `flet publish`, con la carpeta `dist/` ya generada):

    pip install pillow          # si no lo tienes ya
    python fix_icons.py

Por defecto asume `assets/icon.png` como origen, `dist/` como destino, el
color de fondo de los iconos con fondo sólido calculado del propio borde
del icono (ver v11 más abajo), y `main.py` (junto a este script) para leer
la versión; si usas otras rutas, quieres forzar el color de fondo a mano
en vez de calcularlo, o fijar la versión a mano:

    python fix_icons.py --icon "ruta\\a\\tu\\icono.png" --dist "ruta\\a\\dist" --bg-color 283593 --version 2.1
"""
import argparse
import hashlib
import json
import re
import sys
from collections import deque
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    print("Este script necesita Pillow: pip install pillow")
    sys.exit(1)

# (ruta relativa dentro de dist/, tamaño en píxeles, fracción del lienzo que
# ocupa el logo -None significa "deja transparencia real y forma redondeada,
# no compongas sobre fondo sólido"; "auto" significa "calcúlalo tú, ver
# `calcular_fill_fraction_segura`"-)
#
# apple-touch-icon usa 1.0 (a sangre) a propósito: iOS no aplica ninguna
# máscara/recorte a este icono, así que no hay "zona segura" que respetar
# -el único límite es no dejar transparencia, de ahí `make_opaque`-.
#
# icon-maskable-* usa "auto" (v10) en vez de un número fijo -ver "Fracción
# fija vs. medida (v10)" en el historial de versiones al principio del
# archivo- porque el encogido correcto depende de CADA `assets/icon.png`
# -de cuánto ocupe ya el logo dentro de su propio lienzo-, y un valor fijo
# adivinado o deja demasiado margen (se ve como una insignia anidada dentro
# de un cuadrado más grande) o se queda corto y la máscara circular de
# Android recorta el propio icono.
ICON_TARGETS = [
    ("icons/icon-192.png", 192, None),
    ("icons/icon-512.png", 512, None),
    ("icons/icon-maskable-192.png", 192, "auto_glifo"),
    ("icons/icon-maskable-512.png", 512, "auto_glifo"),
    ("icons/apple-touch-icon-192.png", 192, 1.0),
    ("favicon.png", 32, None),
]

# Maskable a (casi) sangre completa, con margen medido sobre el glifo, no
# sobre toda la insignia (v13): "auto" (v10, ver más abajo) daba por hecho
# que assets/icon.png es un LOGO pequeño centrado sobre lienzo vacío, al que
# hay que encoger para que quepa en la "zona segura" del 80% que garantiza la
# especificación -con este icono real calculaba un encogido de ~65%-. Pero el
# diseño real de este icono es distinto: ya es una INSIGNIA a sangre completa
# (un cuadrado con las esquinas redondeadas, del mismo estilo que un
# "adaptive icon" de Android), pensada para llenar todo el lienzo -con "auto"
# se veía, tras recortar en círculo, un cuadrado redondeado más pequeño
# flotando dentro del círculo: el defecto de "formas anidadas" de la v9,
# vuelto a colar por esta vía-. Fijar fill_fraction a 1.0 (v12, sangre
# completa total, igual que apple-touch-icon) arregló eso, pero descubrió un
# problema distinto: a 1.0 el glifo blanco (el dibujo de fotos/personas, no
# el fondo de la insignia) SÍ llega a cortarse por la esquina inferior
# derecha del recuadro blanco -confirmado por el usuario contra un icono
# Android real, con capturas de referencia de cómo se ve "bien" y "mal".
#
# La diferencia clave frente a "auto": no hace falta proteger toda la
# insignia (su fondo de color plano se puede recortar sin que se note, ya que
# el color de fondo del lienzo -v11- coincide con el suyo), solo hace falta
# proteger el GLIFO -el dibujo blanco de encima-, que si se recorta sí se
# nota. `medir_radio_glifo` mide, igual que `medir_radio_maximo`, la
# distancia del centro al punto más lejano, pero solo entre los píxeles
# blancos (el glifo), no entre todos los píxeles opacos (que incluirían el
# fondo de la insignia). Y en vez de apuntar al 80% "garantizado" de la
# especificación (pensado para máscaras más agresivas que las que de verdad
# usan los lanzadores comunes), `calcular_fill_fraction_glifo` apunta a que
# el glifo llegue casi hasta el borde real del recorte -el mismo círculo
# inscrito en el lienzo que ya se usaba para simular y confirmar el
# resultado, radio = mitad del lienzo, no el 80%-, dejando solo un pequeño
# margen (`MARGEN_GLIFO_SANGRE`) de seguridad frente al antialiasing del
# propio recorte. Con el icono real de este proyecto, esto da un encogido de
# ~79%, mucho más cercano a sangre completa que el ~65% de "auto" -y ya sin
# cortar el glifo-.
#
# `calcular_fill_fraction_segura`/`medir_radio_maximo` (v10) no se han
# quitado -pueden seguir haciendo falta si `assets/icon.png` cambia el día de
# mañana a un logo pequeño centrado sobre lienzo vacío, en vez de una
# insignia a sangre completa-, pero ya no son los que deciden el encogido de
# los iconos maskable por defecto.

# Color de fondo de reserva para los iconos con fondo sólido (maskable y
# apple-touch-icon): el índigo 800 que usa la app (PRIMARY =
# ft.Colors.INDIGO_800 en main_pwa_v1.py). Desde v11 solo se usa si
# `color_borde_icono` no consigue medir un color del propio icono (imagen
# totalmente transparente) o si el usuario fuerza --bg-color sin valor.
DEFAULT_BG_COLOR = "283593"

# Cualquier píxel con un alfa igual o por debajo de este umbral se limpia a
# (0,0,0,0) del todo -ver "Vuelta atrás parcial..." al principio del
# archivo-. 16 sobre 255 (~6% de opacidad) es generoso: sin esto, un
# `assets/icon.png` con ruido de color en su zona "transparente" (frecuente
# en imágenes con el fondo quitado por IA) puede dejar un resto visible en
# los iconos con transparencia real, aunque la premultiplicación ya reduzca
# mucho ese ruido al reescalar.
ALPHA_LIMPIEZA = 16

# Fracción del diámetro del icono que la especificación de iconos maskable
# garantiza visible bajo cualquier máscara conforme (círculo, superelipse,
# lo que use cada launcher): el 80% central. `calcular_fill_fraction_segura`
# encoge el logo justo lo necesario para que quepa ahí dentro -ni más
# (dejaría un margen de sobra) ni menos (la máscara lo recortaría)-. Ya no es
# lo que decide el encogido por defecto de los iconos maskable (ver v13, más
# abajo), pero se deja disponible por si algún día hace falta.
SAFE_ZONE_OBJETIVO = 0.8

# Umbral de "blancura" para considerar un píxel parte del GLIFO (el dibujo de
# encima de la insignia -fotos, personas-) en vez de su fondo de color. Con
# un icono de un solo color de fondo bien diferenciado del blanco del glifo
# (como este), un umbral generoso basta y evita falsos positivos por
# antialiasing en el borde del propio glifo.
UMBRAL_BLANCO_GLIFO = 200

# A qué fracción del radio REAL de recorte (la mitad del lienzo -círculo
# inscrito-, no el 80% "garantizado" de la especificación) debe llegar como
# mucho el punto del glifo más alejado del centro. 0.97 deja un margen del 3%
# frente al antialiasing del propio recorte del lanzador -suficiente para que
# no se pierda ni un píxel del glifo, sin encoger de más-. Ver "Maskable a
# (casi) sangre completa..." (v13) más arriba.
MARGEN_GLIFO_SANGRE = 0.97


def limpiar_ruido_alfa(im: "Image.Image", umbral: int = ALPHA_LIMPIEZA) -> "Image.Image":
    """Fuerza a (0,0,0,0) cualquier píxel con alfa <= `umbral`, eliminando
    del todo el ruido de color que pueda quedar en la zona "transparente"
    del icono de origen -en vez de solo atenuarlo, como hace la
    premultiplicación por sí sola-."""
    im = im.convert("RGBA")
    out = Image.new("RGBA", im.size)
    out.putdata([(0, 0, 0, 0) if a <= umbral else (r, g, b, a) for r, g, b, a in im.getdata()])
    return out


def limpiar_islas_alfa(im: "Image.Image", umbral: int = ALPHA_LIMPIEZA) -> "Image.Image":
    """Segunda pasada de limpieza, por conectividad en vez de por umbral -ver
    "Ruido de color en las esquinas..." (v8) al principio del archivo-.

    `limpiar_ruido_alfa` ya fuerza a transparente cualquier píxel con alfa
    <= `umbral`, pero solo mira cada píxel por separado: si el ruido de la
    imagen de origen tiene un alfa bastante más alto que ese umbral -algo
    habitual en imágenes generadas o retocadas con IA-, sobrevive intacto.

    Esta función en cambio busca el mayor grupo contiguo (4-conectado) de
    píxeles no transparentes -el icono real, siempre la zona más grande de
    la imagen- y borra a (0, 0, 0, 0) cualquier otro grupo no transparente
    que quede suelto, sin importar lo opaco que sea. Las motas de ruido en
    las esquinas, al no estar pegadas al icono, caen siempre en el segundo
    caso.
    """
    im = im.convert("RGBA")
    w, h = im.size
    px = im.load()
    etiquetas = [0] * (w * h)
    tam_por_etiqueta = {}
    siguiente_etiqueta = 0

    def vecinos(x, y):
        if x > 0:
            yield x - 1, y
        if x < w - 1:
            yield x + 1, y
        if y > 0:
            yield x, y - 1
        if y < h - 1:
            yield x, y + 1

    for y0 in range(h):
        for x0 in range(w):
            idx0 = y0 * w + x0
            if etiquetas[idx0] or px[x0, y0][3] <= umbral:
                continue
            siguiente_etiqueta += 1
            etiqueta = siguiente_etiqueta
            etiquetas[idx0] = etiqueta
            tam = 1
            cola = deque([(x0, y0)])
            while cola:
                x, y = cola.popleft()
                for nx, ny in vecinos(x, y):
                    nidx = ny * w + nx
                    if not etiquetas[nidx] and px[nx, ny][3] > umbral:
                        etiquetas[nidx] = etiqueta
                        cola.append((nx, ny))
                        tam += 1
            tam_por_etiqueta[etiqueta] = tam

    if not tam_por_etiqueta:
        return im  # imagen totalmente transparente, nada que limpiar

    etiqueta_principal = max(tam_por_etiqueta, key=tam_por_etiqueta.get)
    if len(tam_por_etiqueta) == 1:
        return im  # un solo grupo -el icono-, nada suelto que borrar

    out = im.copy()
    out_px = out.load()
    for y in range(h):
        fila = y * w
        for x in range(w):
            etiqueta = etiquetas[fila + x]
            if etiqueta and etiqueta != etiqueta_principal:
                out_px[x, y] = (0, 0, 0, 0)
    return out


def medir_radio_maximo(im: "Image.Image", umbral: int = ALPHA_LIMPIEZA) -> float:
    """Distancia (en píxeles) del centro del lienzo al punto no transparente
    más alejado -la esquina del logo más próxima al borde-. Se mide una sola
    vez sobre la imagen ya limpia de ruido y la reutilizan tanto
    `calcular_fill_fraction_segura` como `color_borde_icono`, para no
    recorrer la imagen entera dos veces."""
    im = im.convert("RGBA")
    w, h = im.size
    cx, cy = (w - 1) / 2, (h - 1) / 2
    px = im.load()
    max_radio = 0.0
    for y in range(h):
        for x in range(w):
            if px[x, y][3] > umbral:
                d = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
                if d > max_radio:
                    max_radio = d
    return max_radio


def calcular_fill_fraction_segura(im: "Image.Image", max_radio: float,
                                   objetivo: float = SAFE_ZONE_OBJETIVO) -> float:
    """A partir de `max_radio` (ver `medir_radio_maximo`), devuelve el
    encogido justo necesario para que el punto no transparente más alejado
    del centro quede a `objetivo` (por defecto, el 80% central que
    garantiza visible la especificación de iconos maskable). Ver "Fracción
    fija vs. medida (v10)" en el historial de versiones al principio del
    archivo.
    """
    w, h = im.size
    radio_lienzo = min(w, h) / 2
    if max_radio <= 0:
        return 1.0  # imagen totalmente transparente; no hay nada que encoger
    fraccion_actual = max_radio / radio_lienzo
    # Nunca por debajo de 0.3 (evita un logo ridículamente diminuto si algo
    # raro se coló hasta el borde mismo del lienzo) ni por encima de 1.0
    # (no tiene sentido "agrandar" el logo más allá de su propio lienzo).
    return max(0.3, min(1.0, objetivo / fraccion_actual))


def medir_radio_glifo(im: "Image.Image", umbral_alfa: int = ALPHA_LIMPIEZA,
                       umbral_blanco: int = UMBRAL_BLANCO_GLIFO) -> float:
    """Como `medir_radio_maximo`, pero solo entre los píxeles del GLIFO -el
    dibujo blanco de encima de la insignia-, no entre todos los píxeles
    opacos. El fondo de color de la insignia se puede recortar sin que se
    note (coincide con el color de relleno del lienzo, v11); el glifo, si se
    recorta, sí se nota -ver "Maskable a (casi) sangre completa..." (v13) en
    el historial de versiones al principio del archivo."""
    im = im.convert("RGBA")
    w, h = im.size
    cx, cy = (w - 1) / 2, (h - 1) / 2
    px = im.load()
    max_radio = 0.0
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if a > umbral_alfa and r > umbral_blanco and g > umbral_blanco and b > umbral_blanco:
                d = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
                if d > max_radio:
                    max_radio = d
    return max_radio


def calcular_fill_fraction_glifo(im: "Image.Image", max_radio_glifo: float,
                                  objetivo: float = MARGEN_GLIFO_SANGRE) -> float:
    """A partir de `max_radio_glifo` (ver `medir_radio_glifo`), devuelve el
    encogido justo necesario para que el punto del GLIFO más alejado del
    centro quede a `objetivo` del radio real de recorte -la mitad del
    lienzo, no el 80% "garantizado" de la especificación que usa
    `calcular_fill_fraction_segura`-. Ver "Maskable a (casi) sangre
    completa..." (v13) en el historial de versiones al principio del
    archivo.
    """
    w, h = im.size
    radio_lienzo = min(w, h) / 2
    if max_radio_glifo <= 0:
        return 1.0  # no se detectó glifo blanco; no hay nada que proteger
    fraccion_actual = max_radio_glifo / radio_lienzo
    return max(0.3, min(1.0, objetivo / fraccion_actual))


def color_borde_icono(im: "Image.Image", max_radio: float, umbral: int = ALPHA_LIMPIEZA,
                       banda: float = 0.15) -> "tuple[int, int, int] | None":
    """Promedia el color de los píxeles opacos del anillo exterior del icono
    -entre `(1 - banda)` y 1.0 de `max_radio`, ver `medir_radio_maximo`- para
    usarlo como color de fondo en los iconos con fondo sólido, en vez de un
    color de tema fijo (ver "Fondo a juego con el propio icono (v11)" en el
    historial de versiones).

    Se limita a ese anillo exterior, y no promedia toda la imagen, porque el
    centro suele contener el glifo en blanco (u otro color muy distinto del
    fondo de la insignia) -promediarlo todo mezclaría ambos y el resultado
    no se parecería al color real del borde-. Devuelve `None` si no hay
    ningún píxel opaco en ese anillo (imagen totalmente transparente, o
    `banda` demasiado estrecha para el tamaño de la imagen).
    """
    im = im.convert("RGBA")
    w, h = im.size
    cx, cy = (w - 1) / 2, (h - 1) / 2
    px = im.load()
    radio_interior = max_radio * (1 - banda)
    suma_r = suma_g = suma_b = 0
    n = 0
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if a <= umbral:
                continue
            d = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
            if radio_interior <= d <= max_radio:
                suma_r += r
                suma_g += g
                suma_b += b
                n += 1
    if n == 0:
        return None
    return (suma_r // n, suma_g // n, suma_b // n)


def _premultiply(im: "Image.Image") -> "Image.Image":
    """Multiplica RGB por el alfa (0-255) para evitar halos de color al reescalar."""
    im = im.convert("RGBA")
    out = Image.new("RGBA", im.size)
    out.putdata([(r * a // 255, g * a // 255, b * a // 255, a) for r, g, b, a in im.getdata()])
    return out


def _unpremultiply(im: "Image.Image") -> "Image.Image":
    """Deshace `_premultiply` tras el reescalado."""
    out = Image.new("RGBA", im.size)
    pixels = []
    for r, g, b, a in im.getdata():
        if a == 0:
            pixels.append((0, 0, 0, 0))
        else:
            pixels.append((min(255, r * 255 // a), min(255, g * 255 // a), min(255, b * 255 // a), a))
    out.putdata(pixels)
    return out


def resize_sin_halo(im: "Image.Image", size: int) -> "Image.Image":
    """Reescala una imagen RGBA a (size, size) sin dejar halo de color en los bordes."""
    return _unpremultiply(_premultiply(im).resize((size, size), Image.LANCZOS))


def hex_a_rgb(hex_color: str):
    hex_color = hex_color.strip().lstrip("#")
    if len(hex_color) != 6:
        print(f"Color de fondo inválido: {hex_color!r}. Usa un hex de 6 dígitos, ej. 283593.")
        sys.exit(1)
    return tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))


def make_opaque(im: "Image.Image", size: int, bg_rgb, fill_fraction: float) -> "Image.Image":
    """Compone el logo, reducido a `fill_fraction` del lienzo, sobre un fondo sólido
    opaco -sin dejar ni un píxel transparente en el resultado final-.

    Usa `Image.alpha_composite` (composición "over" correcta) en vez de
    `Image.paste(..., mask=...)`: paste con máscara mezcla el canal alfa con
    la misma fórmula que los de color, así que un píxel del logo a medio
    camino (borde antialiaseado, alfa≈128) deja el resultado en alfa≈191 en
    vez de 255 -casi opaco, pero no del todo-. `alpha_composite` sí
    garantiza opacidad total en cada píxel cuando el fondo ya lo es.
    """
    canvas = Image.new("RGBA", (size, size), bg_rgb + (255,))
    logo_size = max(1, int(size * fill_fraction))
    logo = resize_sin_halo(im, logo_size)
    offset = ((size - logo_size) // 2, (size - logo_size) // 2)
    logo_layer = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    logo_layer.paste(logo, offset)  # sin máscara: coloca el logo tal cual, con su propio alfa
    return Image.alpha_composite(canvas, logo_layer)


def leer_version(main_path: Path) -> "str | None":
    """Extrae el valor de `VERSION = '...'` de main.py, sin importarlo (no
    hace falta ejecutar la app para saber su versión, y main.py tiene
    dependencias -flet, etc.- que igual ni están instaladas aquí)."""
    if not main_path.exists():
        return None
    texto = main_path.read_text(encoding="utf-8")
    m = re.search(r"""^VERSION\s*=\s*['"]([^'"]+)['"]""", texto, re.MULTILINE)
    return m.group(1) if m else None


def fix_icons(icon_path: Path, dist_dir: Path, bg_rgb: "tuple[int, int, int] | None",
              main_path: Path, version_override: "str | None"):
    """`bg_rgb=None` significa "calcúlalo del propio icono" (ver
    "Fondo a juego con el propio icono (v11)" en el historial de versiones);
    pásalo solo cuando quieras forzarlo a mano con --bg-color."""
    if not icon_path.exists():
        print(f"No encuentro {icon_path}. Pásame la ruta correcta con --icon.")
        sys.exit(1)
    if not dist_dir.exists():
        print(f"No encuentro la carpeta {dist_dir}. Ejecuta antes `flet publish` "
              f"o pásame la ruta correcta con --dist.")
        sys.exit(1)

    file_hashes = {}  # rel_path (con "/") -> hash corto del contenido ya escrito

    with Image.open(icon_path) as im:
        if im.width != im.height:
            print(f"Aviso: {icon_path} no es cuadrado ({im.width}x{im.height}); "
                  f"los iconos pueden verse deformados. Lo ideal es una imagen cuadrada.")
        im = limpiar_ruido_alfa(im)
        im = limpiar_islas_alfa(im)

        max_radio = medir_radio_maximo(im)
        fraccion_segura = calcular_fill_fraction_segura(im, max_radio)

        max_radio_glifo = medir_radio_glifo(im)
        fraccion_glifo = calcular_fill_fraction_glifo(im, max_radio_glifo)
        if max_radio_glifo > 0:
            print(f"  Sangre calculada para iconos maskable: logo al {fraccion_glifo * 100:.0f}% "
                  f"(para que el glifo blanco no se corte al recortar en círculo, con un {(1 - MARGEN_GLIFO_SANGRE) * 100:.0f}% "
                  f"de margen)")
        else:
            print("  Aviso: no se detectó ningún glifo blanco en el icono; uso la zona segura "
                  f"del {SAFE_ZONE_OBJETIVO * 100:.0f}% como reserva ({fraccion_segura * 100:.0f}%).")

        if bg_rgb is not None:
            bg_rgb_final = bg_rgb
            origen_color = "fijado con --bg-color"
        else:
            color_auto = color_borde_icono(im, max_radio)
            if color_auto is not None:
                bg_rgb_final = color_auto
                origen_color = "calculado del propio borde del icono"
            else:
                bg_rgb_final = hex_a_rgb(DEFAULT_BG_COLOR)
                origen_color = "por defecto (tema de la app; no se pudo medir el borde)"
        print(f"  Color de fondo para iconos con fondo sólido: "
              f"#{bg_rgb_final[0]:02x}{bg_rgb_final[1]:02x}{bg_rgb_final[2]:02x} ({origen_color})")

        for rel_path, size, fill_fraction in ICON_TARGETS:
            target = dist_dir / rel_path
            if not target.parent.exists():
                print(f"Aviso: no existe la carpeta {target.parent}, me la salto.")
                continue
            if fill_fraction is None:
                resized = resize_sin_halo(im, size)
                etiqueta = " (con transparencia)"
            else:
                if fill_fraction == "auto_glifo":
                    frac = fraccion_glifo if max_radio_glifo > 0 else fraccion_segura
                elif fill_fraction == "auto":
                    frac = fraccion_segura
                else:
                    frac = fill_fraction
                resized = make_opaque(im, size, bg_rgb_final, frac)
                etiqueta = f" (fondo sólido, logo al {frac * 100:.0f}%)"
            resized.save(target, "PNG")
            file_hashes[rel_path] = hashlib.sha1(target.read_bytes()).hexdigest()[:10]
            print(f"  Escrito {target} ({size}x{size}){etiqueta}")

    manifest_path = dist_dir / "manifest.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        cambiado = False

        # Detalle cosmético: el manifest.json trae de fábrica una descripción
        # genérica de Flet ("Flet - the fastest way to build Flutter apps in
        # Python"); la cambiamos por algo propio del álbum si sigue así.
        if "Flet" in (manifest.get("description") or ""):
            manifest["description"] = "Álbum de fotos familiar"
            cambiado = True

        # Versionado: añade "?v=<hash>" a cada icono del manifest cuyo
        # contenido acabamos de regenerar, para forzar a los navegadores a
        # detectar el cambio (ver nota "Versionado de iconos" al principio).
        for entry in manifest.get("icons", []):
            src = entry.get("src", "")
            base = src.split("?", 1)[0]
            file_hash = file_hashes.get(base)
            if file_hash is None:
                continue
            new_src = f"{base}?v={file_hash}"
            if entry.get("src") != new_src:
                entry["src"] = new_src
                cambiado = True

        # Campo "version" (v6): flet publish nunca lo escribe -ver el
        # docstring-. Se toma de --version si se indicó; si no, se lee
        # automáticamente de VERSION en main.py.
        version = version_override or leer_version(main_path)
        if version:
            if manifest.get("version") != version:
                manifest["version"] = version
                cambiado = True
            print(f"  Versión: {version}"
                  + (" (de --version)" if version_override else f" (leída de {main_path})"))
        else:
            print(f"Aviso: no he podido determinar la versión (ni --version ni "
                  f"VERSION en {main_path}); dejo manifest.json sin ese campo.")

        # Campo "orientation" (v7): el manifest.json de fábrica de Flet trae
        # "orientation": "natural", que BLOQUEA la PWA instalada a la
        # orientación natural del dispositivo -en un móvil, vertical- sin
        # dejar rotar a horizontal. Chrome/Android sí hace cumplir ese
        # bloqueo en una PWA instalada (display: standalone); Safari/iOS es
        # bastante más laxo con el manifest y, en la práctica, lo ignora -de
        # ahí que solo se note en Android, nunca en iOS, con el mismo
        # main.py y el mismo manifest.json. Se cambia a "any" (sin
        # restricción) para que gire libremente en cualquier plataforma; la
        # propia app ya adapta su layout al ancho real (ver ORDER_BY /
        # _CARD_W / _dialog_width en main.py), así que no hay motivo para
        # bloquear la orientación.
        if manifest.get("orientation") != "any":
            manifest["orientation"] = "any"
            cambiado = True
        print(f"  Orientación: any (sin bloqueo)")

        if cambiado:
            manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
            print(f"  Actualizado {manifest_path} (descripción, versión de iconos, versión de la app y/o orientación)")
        else:
            print(f"  {manifest_path}: sin cambios necesarios")
    else:
        print(f"Aviso: no encuentro {manifest_path}, no he podido versionar los iconos ni la versión ahí.")

    print("\nListo. Vuelve a subir el contenido de dist/ a GitHub (los archivos de "
          "icons/, favicon.png y manifest.json habrán cambiado).")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--icon", type=Path, default=Path("assets/icon.png"),
                         help="Icono cuadrado de origen (por defecto: assets/icon.png)")
    parser.add_argument("--dist", type=Path, default=Path("dist"),
                         help="Carpeta generada por flet publish (por defecto: dist)")
    parser.add_argument("--bg-color", type=str, default=None,
                         help=f"Color de fondo (hex, sin #) para los iconos con fondo sólido "
                              f"-maskable y apple-touch-icon-. Por defecto se calcula del propio "
                              f"borde de assets/icon.png (ver v11 en el historial); usa esto para "
                              f"forzarlo a mano, p. ej. al índigo del tema de la app ({DEFAULT_BG_COLOR})")
    parser.add_argument("--main", type=Path, default=Path("main.py"),
                         help="Ruta a main.py, para leer VERSION automáticamente (por defecto: main.py)")
    parser.add_argument("--version", type=str, default=None,
                         help="Fija la versión a mano en vez de leerla de VERSION en main.py")
    args = parser.parse_args()
    bg_rgb = hex_a_rgb(args.bg_color) if args.bg_color else None
    fix_icons(args.icon, args.dist, bg_rgb, args.main, args.version)
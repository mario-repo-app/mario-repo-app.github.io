"""
Habilitar "arrastrar y soltar" el ZIP — atajo para iPad, Y la forma más
automática de importar varias partes a la vez en CUALQUIER dispositivo
====================================================================

El selector de archivos normal de Flet ("Importar ZIP") no consigue abrir
el diálogo nativo de "elegir archivo" en Safari/iPadOS. No es un fallo de
`main.py`: es un fallo conocido y documentado del propio framework Flet,
sin arreglo todavía (reproducido incluso en la demo oficial de Flet, ver
el LEEME.md para los enlaces). Ocurre porque, en el build web de Flet,
Python corre dentro de un Web Worker separado del hilo principal del
navegador — abrir el selector nativo requiere ir y volver entre ese
Worker y el hilo principal por mensajes, y Safari exige que ese diálogo
se abra como reacción directa e inmediata al toque del usuario, sin
ningún salto de por medio. Ese salto es inevitable con la arquitectura
actual de Flet, así que no hay ningún cambio en `main.py` que lo arregle.

"Arrastrar y soltar" no tiene este problema: cuando sueltas uno o varios
archivos sobre una página, el navegador te los da directamente, sin pasar
por ningún diálogo del sistema — así que esta vía no depende en absoluto
del selector que falla. Y esto no es solo para iPad: en Windows/Mac
también puedes seleccionar varios .zip a la vez en el Explorador/Finder
(clic + Ctrl o Mayús) y arrastrarlos juntos hasta la pestaña del
navegador donde tengas la PWA abierta — es exactamente el mismo mecanismo
del navegador (HTML5 drag & drop), nada específico de iPad. Es, de hecho,
la única forma de importar varias partes SIN tener que confirmar cada una
por separado: el botón "Importar ZIP" no puede hacerlo (con varios
archivos elegidos a la vez se agota la memoria del navegador al cargarlos
todos de golpe -- ver _pick_zip_con_reintento() en main.py --, y
reabrir el selector solo, sin más clics, tampoco es posible porque los
navegadores exigen un gesto real del usuario para cada apertura). Soltar
varios archivos SÍ es un único gesto real que cubre los seis de una vez,
así que aquí no hace falta ningún diálogo intermedio: se procesan todos
solos, uno detrás de otro. Además, desde iPadOS 11 la app Archivos
permite seleccionar VARIOS archivos a la vez (tocando y manteniendo uno,
luego tocando los demás con otro dedo) y arrastrarlos todos juntos en un
mismo gesto — así que este script recoge TODOS los .zip soltados de golpe
(por ejemplo, las partes que genera
`exportar_zip_familia.py --max-zip-mb`).

IMPORTANTE — por qué se procesan de UNO EN UNO y no todos a la vez: una
primera versión de este script leía en memoria TODOS los .zip soltados
antes de mandárselos a Python, y en un iPad real eso agotaba la memoria
de la pestaña ("Out of Memory") en cuanto se soltaban varias partes
juntas — con partes de ~60 MB cada una, seis de golpe son ~360 MB solo de
datos, antes de contar la sobrecarga de copiarlos entre JavaScript y
Python. Es exactamente el problema que `exportar_zip_familia.py
--max-zip-mb` reparte en partes pequeñas para evitar, pero solo si esas
partes se procesan de una en una. Por eso ahora el propio worker de
Python (`python-worker.js`) lee y procesa los archivos soltados EN UN
BUCLE SECUENCIAL: lee los bytes de uno, espera (`await`) a que Python
termine de importarlo del todo (incluida la escritura a IndexedDB), y
solo entonces lee el siguiente — nunca hay más de un ZIP entero en
memoria a la vez.

Este script añade esa vía alternativa parcheando 3 archivos que genera
`flet publish` en `dist/`:

- `python.js` — expone el "worker" donde corre Python (`window.__fletPyWorker`)
  para que el script de abajo pueda enviarle mensajes.
- `python-worker.js` — reconoce un tipo de mensaje nuevo ("aquí tienes uno
  o varios ZIP arrastrados", como referencias a archivo SIN LEER) y, por
  cada uno, en orden, lee sus bytes y llama a la función de Python
  `recibir_zip_arrastrado` (definida en `main.py`), esperando a que
  termine antes de pasar al siguiente.
- `index.html` — añade el propio detector de "arrastrar y soltar": al
  soltar archivos sobre la página, se queda solo con los que terminan en
  .zip, los ordena por nombre (primero el que sigue la convención
  "..._parte1_de_N..." de exportar_zip_familia.py, que es el que trae
  Fotos.db) y se los pasa AL WORKER SIN LEERLOS —eso lo hace el worker,
  uno a uno, ver arriba—. Incluye un aviso visual (fondo azul con el
  texto "Suelta aquí...") que aparece mientras arrastras archivos sobre
  la página, para que sea evidente que la zona de soltar está activa.

Como `flet publish` regenera `dist/` entero cada vez, hay que volver a
ejecutar este script (igual que `fix_icons.py`) después de cada
`flet publish`:

    python habilitar_arrastrar_zip.py
    python fix_icons.py

(el orden entre los dos no importa, cada uno toca archivos distintos).

Por defecto asume que `dist/` está en la carpeta actual; si usas otra
ruta:

    python habilitar_arrastrar_zip.py --dist "ruta\\a\\dist"

Nota importante: esto SOLO he podido probarlo con Chromium (arrastrar y
soltar SÍ funciona igual ahí, y lo comprobé de principio a fin: se sueltan
varios ZIP a la vez, se importan uno detrás de otro, la Galería se
actualiza con todos). Lo que no he podido comprobar desde este entorno es
el gesto físico concreto de arrastrar varios archivos a la vez desde la
app Archivos de un iPad hasta Safari, ni el consumo real de memoria en un
iPad de verdad — es una función que Apple documenta como soportada desde
iPadOS 11, pero la confirmación real en tu iPad solo la puedes hacer tú.
"""
import argparse
import sys
from pathlib import Path

MARKER = "[Album-dnd]"


def patch_python_js(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    if MARKER in text:
        print(f"  {path.name}: ya estaba parcheado, no toco nada")
        return True

    anchor = (
        '    app.worker = new Worker(\n'
        '        (flet.entrypointBaseUrl.endsWith("/") ?\n'
        '            flet.entrypointBaseUrl.slice(0, -1) : flet.entrypointBaseUrl) + "/python-worker.js",\n'
        '        { type: "module" });\n'
    )
    if anchor not in text:
        print(f"  ERROR: no encontré el punto esperado en {path.name} — "
              f"¿esta versión de Flet genera un python.js distinto? "
              f"Aviso a Claude con el mensaje de error si ves esto.")
        return False

    injected = anchor + (
        f'    // {MARKER} Expone el worker de Python para que el detector de\n'
        f'    // "arrastrar y soltar" (inyectado en index.html) pueda mandarle\n'
        f'    // directamente los bytes de los ZIP soltados sobre la página —\n'
        f'    // atajo para iPad, donde el selector de archivos no abre el\n'
        f'    // diálogo nativo de iOS (ver habilitar_arrastrar_zip.py).\n'
        f'    window.__fletPyWorker = app.worker;\n'
    )
    text = text.replace(anchor, injected, 1)
    path.write_text(text, encoding="utf-8")
    print(f"  {path.name}: parcheado (worker expuesto en window.__fletPyWorker)")
    return True


def patch_python_worker_js(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    if MARKER in text:
        print(f"  {path.name}: ya estaba parcheado, no toco nada")
        return True

    anchor = (
        "        await self.initPyodide();\n"
        "    } else {\n"
        "        // message\n"
        "        flet_js.send(event.data);\n"
        "    }\n"
        "};\n"
    )
    if anchor not in text:
        print(f"  ERROR: no encontré el punto esperado en {path.name} — "
              f"¿esta versión de Flet genera un python-worker.js distinto? "
              f"Aviso a Claude con el mensaje de error si ves esto.")
        return False

    replacement = (
        "        await self.initPyodide();\n"
        f"    }} else if (event.data && event.data.__albumZipDrop) {{\n"
        f"        // {MARKER} Uno o varios ZIP soltados directamente sobre la\n"
        f"        // página (atajo de importación para iPad — ver\n"
        f"        // habilitar_arrastrar_zip.py y el LEEME.md). `event.data.files`\n"
        f"        // son referencias a archivo SIN LEER (File/Blob, clonados tal\n"
        f"        // cual por postMessage, ya ordenados por index.html) — se leen\n"
        f"        // y procesan AQUÍ, de uno en uno, esperando (`await`) a que\n"
        f"        // Python termine cada uno (incluida la escritura a IndexedDB)\n"
        f"        // antes de leer el siguiente. Así nunca hay más de un ZIP\n"
        f"        // entero en memoria a la vez — con varios soltados de golpe,\n"
        f"        // leerlos TODOS por adelantado agotó la memoria en un iPad\n"
        f"        // real ('Out of Memory'; ver el docstring del script).\n"
        "        try {\n"
        '            const fn = self.pyodide.globals.get("recibir_zip_arrastrado");\n'
        "            if (!fn) {\n"
        f'                console.error("{MARKER} recibir_zip_arrastrado no existe '
        'todavía en Python (¿la app sigue arrancando?)");\n'
        "            } else {\n"
        "                const archivos = event.data.files || [];\n"
        "                const total = archivos.length;\n"
        "                for (let i = 0; i < total; i++) {\n"
        "                    const archivo = archivos[i];\n"
        "                    let bytes;\n"
        "                    try {\n"
        "                        const buf = await archivo.arrayBuffer();\n"
        "                        bytes = new Uint8Array(buf);\n"
        "                    } catch (errLectura) {\n"
        f'                        console.error("{MARKER} Error leyendo " + '
        'archivo.name + ":", errLectura);\n'
        "                        break;\n"
        "                    }\n"
        "                    const ok = await fn(bytes, archivo.name || \"\", i + 1, total);\n"
        "                    // Sin más referencias a `bytes`/`buf` antes de leer el\n"
        "                    // siguiente archivo, para que quede libre para el GC.\n"
        "                    bytes = null;\n"
        "                    if (ok !== true) break;\n"
        "                }\n"
        "            }\n"
        "        } catch (err) {\n"
        f'            console.error("{MARKER} Error procesando los ZIP arrastrados:", err);\n'
        "        }\n"
        "    } else {\n"
        "        // message\n"
        "        flet_js.send(event.data);\n"
        "    }\n"
        "};\n"
    )
    text = text.replace(anchor, replacement, 1)
    path.write_text(text, encoding="utf-8")
    print(f"  {path.name}: parcheado (reconoce ZIP(s) arrastrados y los procesa uno a uno)")
    return True


DROP_ZONE_HTML = """
<!-- [Album-dnd] Zona de "arrastrar y soltar" para importar el/los ZIP,
     pensada sobre todo para iPad (donde el selector de archivos normal
     de Flet no funciona — ver LEEME.md). Acepta soltar varios .zip a la
     vez (p. ej. las partes de `exportar_zip_familia.py --max-zip-mb`).
     Inyectado por habilitar_arrastrar_zip.py tras cada `flet publish`;
     no toca nada de la interfaz normal de la app salvo por este aviso,
     que solo aparece mientras arrastras archivos sobre la página. -->
<div id="album-drop-overlay" style="
  display:none; position:fixed; inset:0; z-index:999999;
  background:rgba(20,35,85,0.90); color:#fff;
  align-items:center; justify-content:center; text-align:center;
  font: 500 5vw/1.4 system-ui, -apple-system, sans-serif; padding:24px;
  pointer-events:none;">
  Suelta aquí el/los archivo(s) ZIP del álbum<br>para importarlo(s)
</div>
<script>
(function () {
  var overlay = document.getElementById('album-drop-overlay');
  var dragDepth = 0;

  function showOverlay() { overlay.style.display = 'flex'; }
  function hideOverlay() { overlay.style.display = 'none'; dragDepth = 0; }

  function tieneArchivos(e) {
    return !!(e.dataTransfer && e.dataTransfer.types &&
      Array.prototype.indexOf.call(e.dataTransfer.types, 'Files') !== -1);
  }

  window.addEventListener('dragenter', function (e) {
    if (!tieneArchivos(e)) return;
    dragDepth++;
    showOverlay();
  }, true);

  window.addEventListener('dragover', function (e) {
    if (tieneArchivos(e)) e.preventDefault();
  }, true);

  window.addEventListener('dragleave', function () {
    dragDepth = Math.max(0, dragDepth - 1);
    if (dragDepth === 0) hideOverlay();
  }, true);

  // Extrae el número de parte de un nombre "..._parteN_de_M..." (el que
  // pone exportar_zip_familia.py) para poder ordenar los archivos ANTES
  // de leer ni un solo byte -- así, si se sueltan varias partes juntas,
  // la que trae Fotos.db (siempre "parte1") es la primera que procesa
  // Python. Es solo una ayuda por nombre, no abre el .zip para
  // comprobarlo; los nombres que no siguen esa convención se dejan al
  // final, en el orden en que los dio el navegador.
  function numeroDeParte(nombre) {
    var m = /_parte(\d+)_de_\d+/i.exec(nombre);
    return m ? parseInt(m[1], 10) : null;
  }

  window.addEventListener('drop', async function (e) {
    if (!tieneArchivos(e)) return;
    e.preventDefault();
    hideOverlay();

    var fileList = e.dataTransfer.files;
    if (!fileList || !fileList.length) return;

    // Se admite soltar varios archivos a la vez (p. ej. las partes que
    // genera exportar_zip_familia.py --max-zip-mb) — se descarta
    // silenciosamente cualquiera que no termine en .zip, igual que antes
    // se hacía con el único archivo soltado.
    var zips = Array.prototype.filter.call(fileList, function (f) {
      return /\\.zip$/i.test(f.name);
    });
    if (!zips.length) {
      console.warn('[Album-dnd] Ningún archivo soltado es un .zip (de ' + fileList.length + ' soltado(s))');
      return;
    }
    if (!window.__fletPyWorker) {
      console.error('[Album-dnd] La app todavia no esta lista (worker de Python no disponible)');
      return;
    }

    zips.sort(function (a, b) {
      var na = numeroDeParte(a.name), nb = numeroDeParte(b.name);
      if (na === null && nb === null) return 0;
      if (na === null) return 1;
      if (nb === null) return -1;
      return na - nb;
    });

    // IMPORTANTE: aquí se mandan los archivos SIN LEER (los objetos File
    // se clonan tal cual por postMessage, es barato, no hace falta leer
    // su contenido para eso). Es el worker (python-worker.js) quien los
    // lee y procesa, DE UNO EN UNO, esperando a que Python termine cada
    // uno antes de leer el siguiente -- si se leyeran aquí TODOS a la
    // vez antes de mandarlos, con varias partes de golpe se podría
    // agotar la memoria de la pestaña (visto en un iPad real: "Out of
    // Memory"). Ver el porqué con más detalle en el docstring del script.
    try {
      window.__fletPyWorker.postMessage({ __albumZipDrop: true, files: zips });
    } catch (err) {
      console.error('[Album-dnd] Error enviando los archivos soltados al worker:', err);
    }
  }, true);
})();
</script>
"""


def patch_index_html(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    if MARKER in text:
        print(f"  {path.name}: ya estaba parcheado, no toco nada")
        return True

    if "</body>" not in text:
        print(f"  ERROR: no encontré </body> en {path.name} — "
              f"¿este archivo cambió de formato? Aviso a Claude si ves esto.")
        return False

    text = text.replace("</body>", DROP_ZONE_HTML + "</body>", 1)
    path.write_text(text, encoding="utf-8")
    print(f"  {path.name}: parcheado (zona de arrastrar-y-soltar añadida)")
    return True


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dist", default="dist", help="Carpeta dist/ generada por flet publish")
    args = ap.parse_args()

    dist = Path(args.dist)
    if not dist.exists():
        print(f"No encuentro la carpeta '{dist}'. Ejecuta primero `flet publish` "
              f"o indica la ruta correcta con --dist.")
        sys.exit(1)

    ok = True
    print("Parcheando para habilitar arrastrar-y-soltar del ZIP (atajo para iPad)...")
    ok &= patch_python_js(dist / "python.js")
    ok &= patch_python_worker_js(dist / "python-worker.js")
    ok &= patch_index_html(dist / "index.html")

    if ok:
        print("Listo. Ahora, además del botón 'Importar ZIP', también se puede soltar "
              "uno o varios archivos .zip directamente sobre la página — si son varios, "
              "se importan uno detrás de otro, nunca todos a la vez en memoria.")
    else:
        print("\nAlgo no encajó (ver los ERROR de arriba) — probablemente Flet cambió "
              "el formato de estos archivos en una actualización. Avisa a Claude con "
              "el mensaje de error para adaptar el script.")
        sys.exit(1)


if __name__ == "__main__":
    main()
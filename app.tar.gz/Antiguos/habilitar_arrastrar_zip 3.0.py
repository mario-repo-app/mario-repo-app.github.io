"""
Habilitar "arrastrar y soltar" el ZIP — atajo para iPad, Y la forma más
automática de importar varias partes a la vez en CUALQUIER dispositivo
====================================================================

El selector de archivos normal de Flet ("Importar ZIP") no consigue abrir
el diálogo nativo de "elegir archivo" en Safari/iPadOS. No es un fallo de
`main.py`: es un fallo conocido y documentado del propio framework Flet,
sin arreglo todavía (reproducido incluso en la demo oficial de Flet, ver
el LEEME.md para los enlaces). Ocurre porque, en el build web de Flet,
Python corre dentro de un Web Worker separado del hilo principal del
navegador — abrir el selector nativo requiere ir y volver entre ese
Worker y el hilo principal por mensajes, y Safari exige que ese diálogo
se abra como reacción directa e inmediata al toque del usuario, sin
ningún salto de por medio. Ese salto es inevitable con la arquitectura
actual de Flet, así que no hay ningún cambio en `main.py` que lo arregle.

"Arrastrar y soltar" no tiene este problema: cuando sueltas uno o varios
archivos sobre una página, el navegador te los da directamente, sin pasar
por ningún diálogo del sistema — así que esta vía no depende en absoluto
del selector que falla. Y esto no es solo para iPad: en Windows/Mac
también puedes seleccionar varios .zip a la vez en el Explorador/Finder
(clic + Ctrl o Mayús) y arrastrarlos juntos hasta la pestaña del
navegador donde tengas la PWA abierta — es exactamente el mismo mecanismo
del navegador (HTML5 drag & drop), nada específico de iPad. Es, de hecho,
la única forma de importar varias partes SIN tener que confirmar cada una
por separado: el botón "Importar ZIP" no puede hacerlo (con varios
archivos elegidos a la vez se agota la memoria del navegador al cargarlos
todos de golpe -- ver _pick_zip_con_reintento() en main.py --, y
reabrir el selector solo, sin más clics, tampoco es posible porque los
navegadores exigen un gesto real del usuario para cada apertura). Soltar
varios archivos SÍ es un único gesto real que cubre los seis de una vez,
así que aquí no hace falta ningún diálogo intermedio: se procesan todos
solos, uno detrás de otro. Además, desde iPadOS 11 la app Archivos
permite seleccionar VARIOS archivos a la vez (tocando y manteniendo uno,
luego tocando los demás con otro dedo) y arrastrarlos todos juntos en un
mismo gesto — así que este script recoge TODOS los .zip soltados de golpe
(por ejemplo, las partes que genera
`exportar_zip_familia.py --max-zip-mb`).

NUEVO — botón "Elegir varias partes a la vez", para cuando arrastrar no
es cómodo (típicamente Android/Huawei, donde el gesto de arrastrar un
archivo entre dos apps a la vez no es tan natural ni conocido como en
iPad con Split View): además de la zona de soltar, se añade un botón fijo
en pantalla que abre el selector NATIVO de "elegir archivos" del propio
navegador (un <input type="file" multiple>, HTML puro, sin pasar por el
control FilePicker de Flet). Al tocarlo se puede marcar TODAS las partes
del ZIP de golpe (en Android, manteniendo pulsado un archivo y tocando
los demás, igual que ya se hace en iPad) y se procesan exactamente igual
que si se hubieran soltado: una a una, en orden, sin acumular más de una
en memoria a la vez. Como es un <input> nativo, no un control de Flet, no
le afecta el fallo de Safari/iPadOS descrito arriba -- de hecho también
sirve como alternativa al botón "Importar ZIP" en iPad para una sola
parte, aunque el foco de este cambio es agilizar las importaciones de
varias partes en Android, que es donde se pidió.

NUEVO (2) — botón "Elegir carpeta con las partes ZIP": probado antes en
una página de diagnóstico aislada, `webkitdirectory` (el atributo que
deja elegir una carpeta ENTERA de golpe, en vez de marcar archivo por
archivo) tiene fama de no funcionar en ningún navegador móvil -- así lo
documenta un hilo abierto en el repositorio de compatibilidad de MDN
(github.com/mdn/browser-compat-data, issue #24357), donde una corrección
que lo daba por soportado en Chrome Android se revirtió tras comprobar
que, en un móvil real, "no había forma de elegir una carpeta para subir".
Pero se comprobó de verdad en el Huawei P30 Pro (EMUI 12) real de Mario
-- pidió permiso de acceso la primera vez (normal, es Android protegiendo
el almacenamiento), y tras concederlo SÍ dejó elegir la carpeta entera y
leer todos sus archivos. Es decir: la fama de "no soportado en móvil" no
se cumple, al menos, en este dispositivo -- por eso se añade como
alternativa PRINCIPAL (aparece primero, más arriba) sin quitar el botón
de selección múltiple, que se mantiene como red de seguridad para
cualquier otro dispositivo de la familia donde el selector de carpeta no
esté disponible (en ese caso el <input> simplemente se comporta como uno
normal de elegir archivos, sin romperse -- ver MDN). Comparte con el
botón de selección múltiple y con arrastrar-y-soltar la misma función
`procesarZips()`: filtra a solo .zip, ordena por número de parte, y los
manda al worker de Python SIN LEER, que es quien los procesa de uno en
uno.

IMPORTANTE — por qué se procesan de UNO EN UNO y no todos a la vez: una
primera versión de este script leía en memoria TODOS los .zip soltados
antes de mandárselos a Python, y en un iPad real eso agotaba la memoria
de la pestaña ("Out of Memory") en cuanto se soltaban varias partes
juntas — con partes de ~60 MB cada una, seis de golpe son ~360 MB solo de
datos, antes de contar la sobrecarga de copiarlos entre JavaScript y
Python. Es exactamente el problema que `exportar_zip_familia.py
--max-zip-mb` reparte en partes pequeñas para evitar, pero solo si esas
partes se procesan de una en una. Por eso ahora el propio worker de
Python (`python-worker.js`) lee y procesa los archivos soltados (o
elegidos con el botón nuevo) EN UN BUCLE SECUENCIAL: lee los bytes de
uno, espera (`await`) a que Python termine de importarlo del todo
(incluida la escritura a IndexedDB), y solo entonces lee el siguiente —
nunca hay más de un ZIP entero en memoria a la vez. Esto no cambia con
el botón nuevo: tanto soltar como elegir con el botón acaban mandando la
misma lista de archivos SIN LEER al worker, que es quien de verdad los
procesa uno a uno (ver `procesarZips()` en el HTML inyectado).

Este script añade esa vía alternativa parcheando 3 archivos que genera
`flet publish` en `dist/`:

- `python.js` — expone el "worker" donde corre Python (`window.__fletPyWorker`)
  para que el script de abajo pueda enviarle mensajes.
- `python-worker.js` — reconoce un tipo de mensaje nuevo ("aquí tienes uno
  o varios ZIP arrastrados o elegidos", como referencias a archivo SIN LEER)
  y, por cada uno, en orden, lee sus bytes y llama a la función de Python
  `recibir_zip_arrastrado` (definida en `main.py`), esperando a que
  termine antes de pasar al siguiente.
- `index.html` — añade el propio detector de "arrastrar y soltar", el
  botón de "elegir carpeta con las partes ZIP" y el de "elegir varias
  partes a la vez": en los tres casos, se queda solo con los archivos que
  terminan en .zip, los ordena por nombre (primero el que sigue la
  convención "..._parte1_de_N..." de exportar_zip_familia.py, que es el
  que trae Fotos.db) y se los pasa AL WORKER SIN LEERLOS —eso lo hace el
  worker, uno a uno, ver arriba—. Incluye un aviso visual (fondo azul con
  el texto "Suelta aquí...") que aparece mientras arrastras archivos
  sobre la página, para que sea evidente que la zona de soltar está
  activa.

Como `flet publish` regenera `dist/` entero cada vez, hay que volver a
ejecutar este script (igual que `fix_icons.py`) después de cada
`flet publish`:

    python habilitar_arrastrar_zip.py
    python fix_icons.py

(el orden entre los dos no importa, cada uno toca archivos distintos).

Por defecto asume que `dist/` está en la carpeta actual; si usas otra
ruta:

    python habilitar_arrastrar_zip.py --dist "ruta\\a\\dist"

Nota importante: la mayor parte de esto SOLO he podido probarlo con
Chromium en este entorno (arrastrar y soltar SÍ funciona igual ahí, y lo
comprobé de principio a fin: se sueltan varios ZIP a la vez, se importan
uno detrás de otro, la Galería se actualiza con todos; el botón de
"elegir varias partes" también lo comprobé ahí simulando la selección de
varios archivos a la vez). El botón de "elegir carpeta" es la única pieza
de este script confirmada en un dispositivo real por el usuario: probado
antes en una página de diagnóstico aislada, y confirmado que en su Huawei
P30 Pro (EMUI 12) sí deja elegir la carpeta entera y leer todos sus
archivos (pide permiso la primera vez, luego funciona). Lo que sigue sin
poder comprobarse desde este entorno es el gesto físico de arrastrar
varios archivos a la vez desde la app Archivos de un iPad hasta Safari, y
si el botón de "elegir carpeta"/"elegir varias partes" funciona igual en
otros dispositivos de la familia (iPhone, otros Android) — son mecanismos
estándar del navegador (HTML5 drag & drop, <input type="file" multiple>,
<input type="file" webkitdirectory>), pero la confirmación real en cada
dispositivo solo la puede hacer quien lo tenga en la mano.
"""
import argparse
import sys
from pathlib import Path

MARKER = "[Album-dnd]"


def patch_python_js(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    if MARKER in text:
        print(f"  {path.name}: ya estaba parcheado, no toco nada")
        return True

    anchor = (
        '    app.worker = new Worker(\n'
        '        (flet.entrypointBaseUrl.endsWith("/") ?\n'
        '            flet.entrypointBaseUrl.slice(0, -1) : flet.entrypointBaseUrl) + "/python-worker.js",\n'
        '        { type: "module" });\n'
    )
    if anchor not in text:
        print(f"  ERROR: no encontré el punto esperado en {path.name} — "
              f"¿esta versión de Flet genera un python.js distinto? "
              f"Aviso a Claude con el mensaje de error si ves esto.")
        return False

    injected = anchor + (
        f'    // {MARKER} Expone el worker de Python para que el detector de\n'
        f'    // "arrastrar y soltar" y el botón "elegir varias partes"\n'
        f'    // (inyectados en index.html) puedan mandarle directamente los\n'
        f'    // bytes de los ZIP soltados/elegidos sobre la página — atajo\n'
        f'    // para iPad, donde el selector de archivos no abre el diálogo\n'
        f'    // nativo de iOS (ver habilitar_arrastrar_zip.py).\n'
        f'    window.__fletPyWorker = app.worker;\n'
    )
    text = text.replace(anchor, injected, 1)
    path.write_text(text, encoding="utf-8")
    print(f"  {path.name}: parcheado (worker expuesto en window.__fletPyWorker)")
    return True


def patch_python_worker_js(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    if MARKER in text:
        print(f"  {path.name}: ya estaba parcheado, no toco nada")
        return True

    anchor = (
        "        await self.initPyodide();\n"
        "    } else {\n"
        "        // message\n"
        "        flet_js.send(event.data);\n"
        "    }\n"
        "};\n"
    )
    if anchor not in text:
        print(f"  ERROR: no encontré el punto esperado en {path.name} — "
              f"¿esta versión de Flet genera un python-worker.js distinto? "
              f"Aviso a Claude con el mensaje de error si ves esto.")
        return False

    replacement = (
        "        await self.initPyodide();\n"
        f"    }} else if (event.data && event.data.__albumZipDrop) {{\n"
        f"        // {MARKER} Uno o varios ZIP soltados o elegidos con el\n"
        f"        // botón nuevo directamente sobre la página (atajo de\n"
        f"        // importación para iPad y Android — ver\n"
        f"        // habilitar_arrastrar_zip.py y el LEEME.md). `event.data.files`\n"
        f"        // son referencias a archivo SIN LEER (File/Blob, clonados tal\n"
        f"        // cual por postMessage, ya ordenados por index.html) — se leen\n"
        f"        // y procesan AQUÍ, de uno en uno, esperando (`await`) a que\n"
        f"        // Python termine cada uno (incluida la escritura a IndexedDB)\n"
        f"        // antes de leer el siguiente. Así nunca hay más de un ZIP\n"
        f"        // entero en memoria a la vez — con varios soltados de golpe,\n"
        f"        // leerlos TODOS por adelantado agotó la memoria en un iPad\n"
        f"        // real ('Out of Memory'; ver el docstring del script).\n"
        "        try {\n"
        '            const fn = self.pyodide.globals.get("recibir_zip_arrastrado");\n'
        "            if (!fn) {\n"
        f'                console.error("{MARKER} recibir_zip_arrastrado no existe '
        'todavía en Python (¿la app sigue arrancando?)");\n'
        "            } else {\n"
        "                const archivos = event.data.files || [];\n"
        "                const total = archivos.length;\n"
        "                for (let i = 0; i < total; i++) {\n"
        "                    const archivo = archivos[i];\n"
        "                    let bytes;\n"
        "                    try {\n"
        "                        const buf = await archivo.arrayBuffer();\n"
        "                        bytes = new Uint8Array(buf);\n"
        "                    } catch (errLectura) {\n"
        f'                        console.error("{MARKER} Error leyendo " + '
        'archivo.name + ":", errLectura);\n'
        "                        break;\n"
        "                    }\n"
        "                    const ok = await fn(bytes, archivo.name || \"\", i + 1, total);\n"
        "                    // Sin más referencias a `bytes`/`buf` antes de leer el\n"
        "                    // siguiente archivo, para que quede libre para el GC.\n"
        "                    bytes = null;\n"
        "                    if (ok !== true) break;\n"
        "                }\n"
        "            }\n"
        "        } catch (err) {\n"
        f'            console.error("{MARKER} Error procesando los ZIP arrastrados:", err);\n'
        "        }\n"
        "    } else {\n"
        "        // message\n"
        "        flet_js.send(event.data);\n"
        "    }\n"
        "};\n"
    )
    text = text.replace(anchor, replacement, 1)
    path.write_text(text, encoding="utf-8")
    print(f"  {path.name}: parcheado (reconoce ZIP(s) arrastrados/elegidos y los procesa uno a uno)")
    return True


DROP_ZONE_HTML = """
<!-- [Album-dnd] Zona de "arrastrar y soltar" + botón "elegir carpeta"
     (webkitdirectory) + botón "elegir varias partes a la vez", para
     importar el/los ZIP sin pasar por el selector normal de Flet (que no
     abre el diálogo nativo en iPad — ver LEEME.md — y que, aunque abre
     bien en Android/Windows, no deja elegir varias partes de golpe sin
     agotar la memoria del navegador). Las tres vías aceptan uno o varios
     .zip a la vez (p. ej. las partes de
     `exportar_zip_familia.py --max-zip-mb`) y los procesan uno detrás de
     otro, nunca todos en memoria a la vez. El botón de carpeta va
     primero (arriba) por ser la vía más cómoda cuando el dispositivo la
     soporta (confirmado en un Huawei P30 Pro/EMUI 12 real, pese a la
     fama de que webkitdirectory no funciona en móvil — ver docstring del
     script); el de selección múltiple queda como red de seguridad para
     cuando el selector de carpeta no esté disponible. Inyectado por
     habilitar_arrastrar_zip.py tras cada `flet publish`; no toca nada de
     la interfaz normal de la app salvo por estos botones y el aviso, que
     solo aparece mientras arrastras archivos sobre la página. -->
<div id="album-drop-overlay" style="
  display:none; position:fixed; inset:0; z-index:999999;
  background:rgba(20,35,85,0.90); color:#fff;
  align-items:center; justify-content:center; text-align:center;
  font: 500 5vw/1.4 system-ui, -apple-system, sans-serif; padding:24px;
  pointer-events:none;">
  Suelta aquí el/los archivo(s) ZIP del álbum<br>para importarlo(s)
</div>

<input type="file" id="album-folder-zip-input" webkitdirectory directory multiple
  style="position:fixed; width:1px; height:1px; opacity:0; pointer-events:none; left:-9999px;">
<button type="button" id="album-folder-zip-button" style="
  position:fixed; right:16px; bottom:64px; z-index:999998;
  background:#0440a2; color:#fff; border:none; border-radius:999px;
  padding:12px 18px; font:500 14px/1.3 system-ui, -apple-system, sans-serif;
  box-shadow:0 2px 8px rgba(0,0,0,0.35); cursor:pointer;">
  📁 Elegir carpeta con las partes ZIP
</button>

<input type="file" id="album-multi-zip-input" accept=".zip,application/zip" multiple
  style="position:fixed; width:1px; height:1px; opacity:0; pointer-events:none; left:-9999px;">
<button type="button" id="album-multi-zip-button" style="
  position:fixed; right:16px; bottom:16px; z-index:999998;
  background:#555; color:#fff; border:none; border-radius:999px;
  padding:12px 18px; font:500 14px/1.3 system-ui, -apple-system, sans-serif;
  box-shadow:0 2px 8px rgba(0,0,0,0.35); cursor:pointer;">
  📥 O elegir varias partes ZIP a la vez
</button>

<script>
(function () {
  var overlay = document.getElementById('album-drop-overlay');
  var folderInput = document.getElementById('album-folder-zip-input');
  var folderButton = document.getElementById('album-folder-zip-button');
  var multiInput = document.getElementById('album-multi-zip-input');
  var multiButton = document.getElementById('album-multi-zip-button');
  var dragDepth = 0;

  function showOverlay() { overlay.style.display = 'flex'; }
  function hideOverlay() { overlay.style.display = 'none'; dragDepth = 0; }

  function tieneArchivos(e) {
    return !!(e.dataTransfer && e.dataTransfer.types &&
      Array.prototype.indexOf.call(e.dataTransfer.types, 'Files') !== -1);
  }

  window.addEventListener('dragenter', function (e) {
    if (!tieneArchivos(e)) return;
    dragDepth++;
    showOverlay();
  }, true);

  window.addEventListener('dragover', function (e) {
    if (tieneArchivos(e)) e.preventDefault();
  }, true);

  window.addEventListener('dragleave', function () {
    dragDepth = Math.max(0, dragDepth - 1);
    if (dragDepth === 0) hideOverlay();
  }, true);

  // Extrae el número de parte de un nombre "..._parteN_de_M..." (el que
  // pone exportar_zip_familia.py) para poder ordenar los archivos ANTES
  // de leer ni un solo byte -- así, si se sueltan/eligen varias partes
  // juntas, la que trae Fotos.db (siempre "parte1") es la primera que
  // procesa Python. Es solo una ayuda por nombre, no abre el .zip para
  // comprobarlo; los nombres que no siguen esa convención se dejan al
  // final, en el orden en que los dio el navegador.
  function numeroDeParte(nombre) {
    var m = /_parte(\\d+)_de_\\d+/i.exec(nombre);
    return m ? parseInt(m[1], 10) : null;
  }

  // Punto único compartido por "soltar" (drop) y por el botón "elegir
  // varias partes": filtra a solo .zip, ordena por número de parte, y
  // manda la lista AL WORKER SIN LEER NINGÚN BYTE aquí -- es
  // python-worker.js quien los lee y procesa, uno a uno, esperando a
  // que Python termine cada uno antes de leer el siguiente (ver el
  // docstring del script para el porqué: leerlos todos de golpe aquí
  // agotó la memoria de la pestaña en un iPad real).
  function procesarZips(archivosRaw, origen) {
    var zips = Array.prototype.filter.call(archivosRaw, function (f) {
      return /\\.zip$/i.test(f.name);
    });
    if (!zips.length) {
      console.warn('[Album-dnd] Ningún archivo de ' + origen + ' es un .zip (de ' +
        archivosRaw.length + ' recibido(s))');
      return;
    }
    if (!window.__fletPyWorker) {
      console.error('[Album-dnd] La app todavia no esta lista (worker de Python no disponible)');
      return;
    }

    zips.sort(function (a, b) {
      var na = numeroDeParte(a.name), nb = numeroDeParte(b.name);
      if (na === null && nb === null) return 0;
      if (na === null) return 1;
      if (nb === null) return -1;
      return na - nb;
    });

    // IMPORTANTE: aquí se mandan los archivos SIN LEER (los objetos File
    // se clonan tal cual por postMessage, es barato, no hace falta leer
    // su contenido para eso). Es el worker (python-worker.js) quien los
    // lee y procesa, DE UNO EN UNO, esperando a que Python termine cada
    // uno antes de leer el siguiente -- si se leyeran aquí TODOS a la
    // vez antes de mandarlos, con varias partes de golpe se podría
    // agotar la memoria de la pestaña (visto en un iPad real: "Out of
    // Memory"). Ver el porqué con más detalle en el docstring del script.
    try {
      window.__fletPyWorker.postMessage({ __albumZipDrop: true, files: zips });
    } catch (err) {
      console.error('[Album-dnd] Error enviando los archivos de ' + origen + ' al worker:', err);
    }
  }

  window.addEventListener('drop', function (e) {
    if (!tieneArchivos(e)) return;
    e.preventDefault();
    hideOverlay();

    var fileList = e.dataTransfer.files;
    if (!fileList || !fileList.length) return;
    procesarZips(fileList, 'soltar');
  }, true);

  // Botón "Elegir carpeta con las partes ZIP": abre el selector NATIVO
  // de carpeta (<input type="file" webkitdirectory>, HTML puro, no el
  // control FilePicker de Flet). Tiene fama de no funcionar en móvil,
  // pero confirmado en un Huawei P30 Pro/EMUI 12 real que SÍ funciona
  // (pide permiso de acceso la primera vez -- normal, es Android
  // protegiendo el almacenamiento -- y tras concederlo entrega todos los
  // archivos de la carpeta elegida). Si el dispositivo no lo soporta, el
  // <input> simplemente se comporta como un selector de archivos normal
  // (no se rompe) y queda el botón de abajo como alternativa segura.
  folderButton.addEventListener('click', function () {
    folderInput.value = '';
    folderInput.click();
  });

  folderInput.addEventListener('change', function () {
    if (!folderInput.files || !folderInput.files.length) return;
    procesarZips(folderInput.files, 'la carpeta elegida');
    folderInput.value = '';
  });

  // Botón "O elegir varias partes ZIP a la vez": abre el selector NATIVO
  // de archivos múltiples (<input type="file" multiple>, HTML puro, no
  // el control FilePicker de Flet) -- así no le afecta el fallo de Flet
  // en Safari/iPadOS (la apertura del diálogo es una reacción directa al
  // toque, sin pasar por ningún Web Worker). Queda como alternativa para
  // cuando el selector de carpeta de arriba no esté disponible.
  multiButton.addEventListener('click', function () {
    multiInput.value = '';
    multiInput.click();
  });

  multiInput.addEventListener('change', function () {
    if (!multiInput.files || !multiInput.files.length) return;
    procesarZips(multiInput.files, 'el selector de archivos');
    multiInput.value = '';
  });
})();
</script>
"""


def patch_index_html(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    if MARKER in text:
        print(f"  {path.name}: ya estaba parcheado, no toco nada")
        return True

    if "</body>" not in text:
        print(f"  ERROR: no encontré </body> en {path.name} — "
              f"¿este archivo cambió de formato? Aviso a Claude si ves esto.")
        return False

    text = text.replace("</body>", DROP_ZONE_HTML + "</body>", 1)
    path.write_text(text, encoding="utf-8")
    print(f"  {path.name}: parcheado (zona de arrastrar-y-soltar + botón de carpeta + "
          f"botón de selección múltiple añadidos)")
    return True


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dist", default="dist", help="Carpeta dist/ generada por flet publish")
    args = ap.parse_args()

    dist = Path(args.dist)
    if not dist.exists():
        print(f"No encuentro la carpeta '{dist}'. Ejecuta primero `flet publish` "
              f"o indica la ruta correcta con --dist.")
        sys.exit(1)

    ok = True
    print("Parcheando para habilitar arrastrar-y-soltar, elegir carpeta y elegir varias partes "
          "del ZIP a la vez...")
    ok &= patch_python_js(dist / "python.js")
    ok &= patch_python_worker_js(dist / "python-worker.js")
    ok &= patch_index_html(dist / "index.html")

    if ok:
        print("Listo. Ahora, además del botón 'Importar ZIP' de la app, hay tres formas más de "
              "importar sin confirmar cada parte por separado: tocar '📁 Elegir carpeta con las "
              "partes ZIP' (arriba a la derecha) y elegir de golpe la carpeta del pendrive donde "
              "están todas las partes; tocar '📥 O elegir varias partes ZIP a la vez' (debajo) y "
              "marcarlas todas de golpe en el selector de archivos; o soltar uno o varios .zip "
              "directamente sobre la página. En los tres casos, si son varias, se importan uno "
              "detrás de otro, nunca todas a la vez en memoria.")
    else:
        print("\nAlgo no encajó (ver los ERROR de arriba) — probablemente Flet cambió "
              "el formato de estos archivos en una actualización. Avisa a Claude con "
              "el mensaje de error para adaptar el script.")
        sys.exit(1)


if __name__ == "__main__":
    main()